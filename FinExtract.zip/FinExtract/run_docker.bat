@echo off
echo ========================================================
echo Starting FinExtract in Docker (Full OCR + MongoDB Stack)
echo ========================================================
docker compose up -d
echo.
echo Containers are starting up.
echo Streamlit UI: http://localhost:8501
echo MongoDB:      mongodb://finextract_user:finextract_secret_pass@localhost:27017/finextract_db
echo.
pause

