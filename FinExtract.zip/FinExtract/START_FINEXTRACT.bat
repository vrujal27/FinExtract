@echo off
setlocal enabledelayedexpansion
title FinExtract - Intelligent Bank Statement Processing Platform
cd /d "%~dp0"

echo ====================================================================
echo.
echo           FINEXTRACT - INTELLIGENT BANK STATEMENT PLATFORM         
echo           Befree AI and Automation Assessment Prototype            
echo.
echo ====================================================================
echo.

:: 1. Check if Docker is installed
where docker >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Docker command was not found in your system PATH.
    echo Please make sure Docker Desktop is installed.
    echo.
    echo Fallback: You can also launch locally using:
    echo   START_LOCAL_NO_DOCKER.bat
    echo.
    pause
    exit /b 1
)

:: 2. Check if Docker daemon is running
echo [1/3] Checking Docker daemon status...
docker info >nul 2>&1
if %ERRORLEVEL% equ 0 goto DOCKER_RUNNING

echo [INFO] Docker Desktop is offline. Attempting to start Docker Desktop...
if exist "C:\Program Files\Docker\Docker\Docker Desktop.exe" (
    start "" "C:\Program Files\Docker\Docker\Docker Desktop.exe"
    echo Waiting for Docker engine to initialize...
    goto WAIT_DOCKER_LOOP
) else (
    echo [ERROR] Docker Desktop executable not found at default location.
    echo Please start Docker Desktop manually, then run this file again.
    echo.
    pause
    exit /b 1
)

:WAIT_DOCKER_LOOP
set /a d_wait=0
:WAIT_DOCKER_STEP
timeout /t 5 /nobreak >nul
docker info >nul 2>&1
if %ERRORLEVEL% equ 0 goto DOCKER_RUNNING
set /a d_wait+=1
echo   Waiting for Docker daemon to respond [step !d_wait!/20]...
if !d_wait! lss 20 goto WAIT_DOCKER_STEP
echo [ERROR] Timed out waiting for Docker engine. Please start Docker Desktop manually.
pause
exit /b 1

:DOCKER_RUNNING
echo [OK] Docker daemon is active and responsive.

:: 3. Start FinExtract containers
echo.
echo [2/3] Starting FinExtract containers (finextract-app and finextract-mongodb)...
docker compose up -d

if %ERRORLEVEL% neq 0 (
    echo [ERROR] Docker Compose failed to bring up services.
    pause
    exit /b 1
)

:: 4. Wait for Streamlit web server to be reachable
echo.
echo [3/3] Waiting for FinExtract web interface to become ready...
set /a retries=0
:WAIT_HEALTH
powershell -Command "try { $r = Invoke-WebRequest -Uri 'http://localhost:8501/_stcore/health' -UseBasicParsing -TimeoutSec 2; if ($r.StatusCode -eq 200) { exit 0 } else { exit 1 } } catch { exit 1 }" >nul 2>&1
if %ERRORLEVEL% equ 0 goto LAUNCH_BROWSER

set /a retries+=1
if !retries! geq 25 (
    echo [WARNING] Service started, proceeding to open browser...
    goto LAUNCH_BROWSER
)
timeout /t 2 /nobreak >nul
echo   Waiting for Streamlit server [attempt !retries!/25]...
goto WAIT_HEALTH

:LAUNCH_BROWSER
echo [OK] FinExtract application is ready.
echo.
echo ====================================================================
echo   FINEXTRACT SERVICES ARE LIVE:
echo   - Web Application:       http://localhost:8501
echo   - Backend Extraction:    PyMuPDF + Tesseract OCR Active
echo   - Classification Engine: Heuristic Rules + TF-IDF (Strict Non-LLM)
echo   - Database:              MongoDB Community 8.0 Active
echo ====================================================================
echo.
echo Opening FinExtract in your default web browser...
start http://localhost:8501

echo.
echo [SUCCESS] FinExtract is running.
echo To stop all services at any time, double-click STOP_FINEXTRACT.bat.
echo.
pause
