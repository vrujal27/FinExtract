"""Re-export database connection methods for backward compatibility."""
from src.database.db import (
    get_client,
    get_database,
    get_db,
    is_connected,
    close_connection,
)

__all__ = [
    "get_client",
    "get_database",
    "get_db",
    "is_connected",
    "close_connection",
]

