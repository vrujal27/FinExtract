"""MongoDB connection management for FinExtract."""
import logging
import os
import time
from typing import Optional
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, ServerSelectionTimeoutError
from src.config import MONGODB_URI, MONGO_DATABASE, MONGO_CONNECT_RETRIES, MONGO_CONNECT_DELAY
from src.utils.security import mask_uri

logger = logging.getLogger("finextract.database")

_client: Optional[MongoClient] = None
_db = None
_last_failed_time: float = 0.0
_FAILED_COOLDOWN_SECONDS: float = 5.0  # Don't hammer failing connection on every frame


def get_client(force_retry: bool = False, max_retries: int = None) -> Optional[MongoClient]:
    """Get or create MongoDB client with retry logic and failure cooldown."""
    global _client, _last_failed_time

    # Return active client if ping succeeds
    if _client is not None:
        try:
            _client.admin.command('ping')
            return _client
        except Exception:
            _client = None

    # Check cooldown if previously failed and not forcing retry
    now = time.time()
    if not force_retry and (now - _last_failed_time) < _FAILED_COOLDOWN_SECONDS:
        return None

    retries = max_retries if max_retries is not None else int(os.getenv("MONGO_CONNECT_RETRIES", str(MONGO_CONNECT_RETRIES)))
    delay = float(os.getenv("MONGO_CONNECT_DELAY", str(MONGO_CONNECT_DELAY)))

    for attempt in range(1, retries + 1):
        try:
            client = MongoClient(
                MONGODB_URI,
                serverSelectionTimeoutMS=1500,
                connectTimeoutMS=1500,
                socketTimeoutMS=3000,
            )
            client.admin.command('ping')
            _client = client
            _last_failed_time = 0.0
            logger.info("MongoDB connected successfully.")
            return _client
        except (ConnectionFailure, ServerSelectionTimeoutError, OSError) as e:
            if attempt < retries:
                time.sleep(delay)
        except Exception as e:
            if attempt < retries:
                time.sleep(delay)

    _last_failed_time = time.time()
    return None


def get_database():
    """Get the application database."""
    global _db
    client = get_client()
    if client is None:
        return None
    _db = client[MONGO_DATABASE]
    return _db


def get_db():
    """Get (db, is_connected) tuple for convenient conditional access."""
    db = get_database()
    return db, (db is not None)


def is_connected() -> bool:
    """Check if MongoDB is reachable (fast check)."""
    try:
        client = get_client()
        return client is not None
    except Exception:
        return False


def close_connection():
    """Close the MongoDB connection."""
    global _client, _db, _last_failed_time
    if _client:
        try:
            _client.close()
        except Exception:
            pass
        _client = None
        _db = None
        _last_failed_time = 0.0
