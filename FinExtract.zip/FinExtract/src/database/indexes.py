"""MongoDB index creation for FinExtract."""
import logging
from pymongo import ASCENDING, DESCENDING, IndexModel

from src.database.db import get_database

logger = logging.getLogger("finextract.indexes")


def create_indexes():
    """Create all required indexes."""
    db = get_database()
    if db is None:
        logger.warning("Cannot create indexes: database unavailable.")
        return
    
    try:
        # processing_jobs
        db.processing_jobs.create_indexes([
            IndexModel([("job_id", ASCENDING)], unique=True),
            IndexModel([("file_hash", ASCENDING)]),
            IndexModel([("created_at", DESCENDING)]),
            IndexModel([("processing_status", ASCENDING)]),
        ])
        
        # accounts
        db.accounts.create_indexes([
            IndexModel([("account_id", ASCENDING)], unique=True),
            IndexModel([("bank_name", ASCENDING)]),
        ])
        
        # transactions
        db.transactions.create_indexes([
            IndexModel([("transaction_id", ASCENDING)], unique=True),
            IndexModel([("job_id", ASCENDING), ("row_index", ASCENDING)], unique=True),
            IndexModel([("account_id", ASCENDING)]),
            IndexModel([("transaction_date", ASCENDING)]),
            IndexModel([("category", ASCENDING)]),
            IndexModel([("review_required", ASCENDING)]),
            IndexModel([("fingerprint", ASCENDING)]),
            IndexModel([("job_id", ASCENDING)]),
        ])
        
        # user_corrections
        db.user_corrections.create_indexes([
            IndexModel([("transaction_id", ASCENDING)]),
            IndexModel([("job_id", ASCENDING)]),
            IndexModel([("timestamp", DESCENDING)]),
        ])
        
        # validation_issues
        db.validation_issues.create_indexes([
            IndexModel([("transaction_id", ASCENDING)]),
            IndexModel([("job_id", ASCENDING)]),
            IndexModel([("severity", ASCENDING)]),
        ])
        
        logger.info("All indexes created successfully.")
    except Exception as e:
        logger.error(f"Failed to create indexes: {e}")


def initialize_database():
    """Initialize database with indexes."""
    create_indexes()
