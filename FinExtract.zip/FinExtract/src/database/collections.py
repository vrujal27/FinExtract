"""MongoDB collection accessors and CRUD operations for FinExtract."""
import logging
from datetime import datetime
from typing import Any, Dict, List, Optional
from bson import ObjectId
from bson.decimal128 import Decimal128
from pymongo import UpdateOne, ASCENDING, DESCENDING
from pymongo.errors import DuplicateKeyError, BulkWriteError

from src.database.db import get_database

logger = logging.getLogger("finextract.collections")


def _db():
    return get_database()


# ─── Processing Jobs ─────────────────────────────────────────────────────────

def insert_job(job: Dict) -> Optional[str]:
    """Insert a processing job. Returns job_id or None."""
    try:
        db = _db()
        if db is None:
            return None
        job["created_at"] = datetime.utcnow()
        job["updated_at"] = datetime.utcnow()
        result = db.processing_jobs.insert_one(job)
        return job.get("job_id")
    except DuplicateKeyError:
        logger.warning(f"Job already exists: {job.get('job_id')}")
        return job.get("job_id")
    except Exception as e:
        logger.error(f"Failed to insert job: {e}")
        return None


def update_job_status(job_id: str, status: str, extra: Dict = None):
    """Update job status and optional fields."""
    try:
        db = _db()
        if db is None:
            return
        update = {"$set": {"processing_status": status, "updated_at": datetime.utcnow()}}
        if extra:
            update["$set"].update(extra)
        db.processing_jobs.update_one({"job_id": job_id}, update)
    except Exception as e:
        logger.error(f"Failed to update job status: {e}")


def get_job(job_id: str) -> Optional[Dict]:
    """Get a job by ID."""
    try:
        db = _db()
        if db is None:
            return None
        return db.processing_jobs.find_one({"job_id": job_id}, {"_id": 0})
    except Exception as e:
        logger.error(f"Failed to get job: {e}")
        return None


def get_all_jobs(limit: int = 100, skip: int = 0) -> List[Dict]:
    """Get all jobs, newest first."""
    try:
        db = _db()
        if db is None:
            return []
        return list(db.processing_jobs.find(
            {}, {"_id": 0},
            sort=[("created_at", DESCENDING)],
            limit=limit, skip=skip
        ))
    except Exception as e:
        logger.error(f"Failed to get jobs: {e}")
        return []


def delete_job(job_id: str):
    """Delete a job and all its related records."""
    try:
        db = _db()
        if db is None:
            return
        db.transactions.delete_many({"job_id": job_id})
        db.validation_issues.delete_many({"job_id": job_id})
        db.user_corrections.delete_many({"job_id": job_id})
        db.processing_jobs.delete_one({"job_id": job_id})
        logger.info(f"Deleted job and related records: {job_id}")
    except Exception as e:
        logger.error(f"Failed to delete job: {e}")


# ─── Accounts ─────────────────────────────────────────────────────────────────

def upsert_account(account: Dict) -> Optional[str]:
    """Upsert an account record. Returns account_id."""
    try:
        db = _db()
        if db is None:
            return None
        account["updated_at"] = datetime.utcnow()
        account.setdefault("created_at", datetime.utcnow())
        db.accounts.update_one(
            {"account_id": account["account_id"]},
            {"$set": account},
            upsert=True
        )
        return account["account_id"]
    except Exception as e:
        logger.error(f"Failed to upsert account: {e}")
        return None


def get_all_accounts() -> List[Dict]:
    """Get all accounts."""
    try:
        db = _db()
        if db is None:
            return []
        return list(db.accounts.find({}, {"_id": 0}))
    except Exception as e:
        logger.error(f"Failed to get accounts: {e}")
        return []


# ─── Transactions ──────────────────────────────────────────────────────────────

def insert_transactions_bulk(transactions: List[Dict]) -> int:
    """Bulk insert transactions. Returns count inserted."""
    if not transactions:
        return 0
    try:
        db = _db()
        if db is None:
            return 0
        now = datetime.utcnow()
        ops = []
        for txn in transactions:
            txn["created_at"] = now
            txn["updated_at"] = now
            ops.append(UpdateOne(
                {"transaction_id": txn["transaction_id"]},
                {"$setOnInsert": txn},
                upsert=True
            ))
        result = db.transactions.bulk_write(ops, ordered=False)
        inserted = result.upserted_count
        logger.info(f"Bulk inserted {inserted} transactions.")
        return inserted
    except BulkWriteError as e:
        logger.warning(f"Bulk write partial error: {e.details}")
        return e.details.get("nInserted", 0)
    except Exception as e:
        logger.error(f"Failed to bulk insert transactions: {e}")
        return 0


def get_transactions(
    job_id: str = None, account_id: str = None,
    category: str = None, review_required: bool = None,
    skip: int = 0, limit: int = 100,
    sort_by: str = "transaction_date", sort_dir: int = ASCENDING,
    filters: Dict = None
) -> List[Dict]:
    """Query transactions with filtering and pagination."""
    try:
        db = _db()
        if db is None:
            return []
        query = {}
        if job_id:
            query["job_id"] = job_id
        if account_id:
            query["account_id"] = account_id
        if category:
            query["category"] = category
        if review_required is not None:
            query["review_required"] = review_required
        if filters:
            query.update(filters)
        return list(db.transactions.find(
            query, {"_id": 0},
            sort=[(sort_by, sort_dir)],
            skip=skip, limit=limit
        ))
    except Exception as e:
        logger.error(f"Failed to get transactions: {e}")
        return []


def count_transactions(query: Dict = None) -> int:
    """Count transactions matching query."""
    try:
        db = _db()
        if db is None:
            return 0
        return db.transactions.count_documents(query or {})
    except Exception as e:
        logger.error(f"Failed to count transactions: {e}")
        return 0


def update_transaction_category(transaction_id: str, category: str, method: str = "MANUAL") -> bool:
    """Update category for a transaction."""
    try:
        db = _db()
        if db is None:
            return False
        result = db.transactions.update_one(
            {"transaction_id": transaction_id},
            {"$set": {
                "category": category,
                "classification_method": method,
                "review_required": False,
                "updated_at": datetime.utcnow()
            }}
        )
        return result.modified_count > 0
    except Exception as e:
        logger.error(f"Failed to update category: {e}")
        return False


def get_transaction(transaction_id: str) -> Optional[Dict]:
    """Get a single transaction by ID."""
    try:
        db = _db()
        if db is None:
            return None
        return db.transactions.find_one({"transaction_id": transaction_id}, {"_id": 0})
    except Exception as e:
        logger.error(f"Failed to get transaction: {e}")
        return None


# ─── User Corrections ──────────────────────────────────────────────────────────

def insert_correction(correction: Dict) -> bool:
    """Store a user correction."""
    try:
        db = _db()
        if db is None:
            return False
        correction["timestamp"] = datetime.utcnow()
        db.user_corrections.insert_one(correction)
        return True
    except Exception as e:
        logger.error(f"Failed to insert correction: {e}")
        return False


def get_corrections(job_id: str = None) -> List[Dict]:
    """Get user corrections, optionally filtered by job."""
    try:
        db = _db()
        if db is None:
            return []
        query = {"job_id": job_id} if job_id else {}
        return list(db.user_corrections.find(query, {"_id": 0}))
    except Exception as e:
        logger.error(f"Failed to get corrections: {e}")
        return []


# ─── Validation Issues ─────────────────────────────────────────────────────────

def insert_validation_issues(issues: List[Dict]) -> int:
    """Insert validation issues."""
    if not issues:
        return 0
    try:
        db = _db()
        if db is None:
            return 0
        now = datetime.utcnow()
        for issue in issues:
            issue["created_at"] = now
        db.validation_issues.insert_many(issues, ordered=False)
        return len(issues)
    except Exception as e:
        logger.error(f"Failed to insert validation issues: {e}")
        return 0


def get_validation_issues(job_id: str = None, transaction_id: str = None) -> List[Dict]:
    """Get validation issues."""
    try:
        db = _db()
        if db is None:
            return []
        query = {}
        if job_id:
            query["job_id"] = job_id
        if transaction_id:
            query["transaction_id"] = transaction_id
        return list(db.validation_issues.find(query, {"_id": 0}))
    except Exception as e:
        logger.error(f"Failed to get validation issues: {e}")
        return []


# ─── Analytics Aggregations ────────────────────────────────────────────────────

def get_summary_stats() -> Dict:
    """Get overall summary statistics."""
    try:
        db = _db()
        if db is None:
            return {}
        total_jobs = db.processing_jobs.count_documents({})
        total_transactions = db.transactions.count_documents({})
        review_required = db.transactions.count_documents({"review_required": True})
        unclassified = db.transactions.count_documents({"category": "Unclassified"})
        
        # Income/expense totals (using aggregation on decimal fields)
        pipeline_debit = [{"$group": {"_id": None, "total": {"$sum": "$debit"}}}]
        pipeline_credit = [{"$group": {"_id": None, "total": {"$sum": "$credit"}}}]
        
        debit_result = list(db.transactions.aggregate(pipeline_debit))
        credit_result = list(db.transactions.aggregate(pipeline_credit))
        
        total_debit = float(debit_result[0]["total"]) if debit_result else 0.0
        total_credit = float(credit_result[0]["total"]) if credit_result else 0.0
        
        return {
            "total_jobs": total_jobs,
            "total_transactions": total_transactions,
            "review_required": review_required,
            "unclassified": unclassified,
            "total_income": total_credit,
            "total_expenses": total_debit,
            "net_cash_flow": total_credit - total_debit,
        }
    except Exception as e:
        logger.error(f"Failed to get summary stats: {e}")
        return {}


def get_category_breakdown(job_id: str = None) -> List[Dict]:
    """Get category-wise transaction breakdown."""
    try:
        db = _db()
        if db is None:
            return []
        match = {}
        if job_id:
            match["job_id"] = job_id
        pipeline = [
            {"$match": match} if match else {"$match": {}},
            {"$group": {
                "_id": "$category",
                "count": {"$sum": 1},
                "total_debit": {"$sum": "$debit"},
                "total_credit": {"$sum": "$credit"},
            }},
            {"$sort": {"total_debit": -1}}
        ]
        return list(db.transactions.aggregate(pipeline))
    except Exception as e:
        logger.error(f"Failed to get category breakdown: {e}")
        return []


delete_job_data = delete_job
