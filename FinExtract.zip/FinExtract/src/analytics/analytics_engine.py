"""Analytics computation for FinExtract dashboard and reports."""
import logging
from collections import defaultdict
from datetime import datetime
from typing import Dict, List, Optional

logger = logging.getLogger("finextract.analytics")


def compute_analytics(transactions: List[Dict], exclude_transfers: bool = True) -> Dict:
    """
    Compute financial and operational analytics from a transaction list.
    Handles transfer exclusion, merchant aggregation, category totals, and monthly trends.
    """
    if not transactions:
        return _empty_analytics()

    total_income = 0.0
    total_expenses = 0.0
    category_totals: Dict[str, Dict] = defaultdict(lambda: {"count": 0, "debit": 0.0, "credit": 0.0})
    monthly_data: Dict[str, Dict] = defaultdict(lambda: {"income": 0.0, "expenses": 0.0, "count": 0})
    method_counts = defaultdict(int)
    merchant_counts = defaultdict(float)

    income_cats = {"Salary", "Income"}
    transfer_cats = {"Transfers"}

    for txn in transactions:
        cat = txn.get("category", "Unclassified")
        debit = float(txn.get("debit") or 0.0)
        credit = float(txn.get("credit") or 0.0)
        method = txn.get("classification_method") or "UNCLASSIFIED"

        # Categorization record
        category_totals[cat]["count"] += 1
        category_totals[cat]["debit"] += debit
        category_totals[cat]["credit"] += credit

        # Handle transfers exclusion
        is_transfer = (cat in transfer_cats)
        if not (exclude_transfers and is_transfer):
            if cat in income_cats or credit > 0:
                total_income += credit
            if debit > 0:
                total_expenses += debit

        # Monthly breakdown
        tx_date = txn.get("transaction_date")
        if tx_date:
            if isinstance(tx_date, str):
                try:
                    tx_date = datetime.fromisoformat(tx_date)
                except Exception:
                    pass
            if isinstance(tx_date, datetime):
                month_key = tx_date.strftime("%Y-%m")
                if not (exclude_transfers and is_transfer):
                    monthly_data[month_key]["income"] += credit
                    monthly_data[month_key]["expenses"] += debit
                monthly_data[month_key]["count"] += 1

        method_counts[method] += 1

        # Merchant identification (proxy: first two words of description if debit > 0)
        desc = (txn.get("description") or "").strip()
        if desc and debit > 0:
            words = desc.upper().split()
            if words:
                merchant = " ".join(words[:2])[:35]
                merchant_counts[merchant] += debit

    top_merchants = sorted(merchant_counts.items(), key=lambda x: x[1], reverse=True)[:10]

    return {
        "total_income": round(total_income, 2),
        "total_expenses": round(total_expenses, 2),
        "net_cash_flow": round(total_income - total_expenses, 2),
        "category_totals": {
            k: {
                "count": v["count"],
                "debit": round(v["debit"], 2),
                "credit": round(v["credit"], 2),
            }
            for k, v in category_totals.items()
        },
        "monthly_data": {
            k: {
                "income": round(v["income"], 2),
                "expenses": round(v["expenses"], 2),
                "count": v["count"],
            }
            for k, v in sorted(monthly_data.items())
        },
        "method_counts": dict(method_counts),
        "top_merchants": [{"merchant": m, "total_debit": round(a, 2)} for m, a in top_merchants],
        "total_transactions": len(transactions),
        "transfer_note": "Transfers excluded from income and expense aggregates to prevent distortion." if exclude_transfers else "",
    }


def _empty_analytics() -> Dict:
    return {
        "total_income": 0.0,
        "total_expenses": 0.0,
        "net_cash_flow": 0.0,
        "category_totals": {},
        "monthly_data": {},
        "method_counts": {},
        "top_merchants": [],
        "total_transactions": 0,
        "transfer_note": "",
    }

