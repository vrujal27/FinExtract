"""Analytics module for FinExtract."""
from src.analytics.analytics_engine import compute_analytics

__all__ = ["compute_analytics"]
