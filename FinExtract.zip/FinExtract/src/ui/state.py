"""Centralized state and data-scoping layer for FinExtract UI."""
import math
from datetime import datetime, date
import pandas as pd
import streamlit as st
from typing import Dict, List, Optional, Tuple, Any
from src.ui.formatters import to_float


def init_session_state():
    """Initialize global session state variables safely with defaults."""
    if "processed_jobs" not in st.session_state:
        st.session_state.processed_jobs = {}
    if "active_job_id" not in st.session_state:
        st.session_state.active_job_id = None
    if "selected_scope" not in st.session_state:
        st.session_state.selected_scope = "Current statement"
    if "selected_account_id" not in st.session_state:
        st.session_state.selected_account_id = None
    if "processed_file_hashes" not in st.session_state:
        st.session_state.processed_file_hashes = {}  # sha256 -> job_id
    if "nav" not in st.session_state:
        st.session_state.nav = "Dashboard"


def get_all_jobs() -> List[Dict[str, Any]]:
    """Retrieve all jobs in session and database."""
    init_session_state()
    session_jobs = list(st.session_state.processed_jobs.values())
    seen_ids = {j.get("job_id") for j in session_jobs if j.get("job_id")}
    
    # Read from database (db.processing_jobs)
    try:
        from src.database.collections import get_all_jobs as db_get_all_jobs
        db_jobs = db_get_all_jobs(limit=100)
        for dj in db_jobs:
            jid = dj.get("job_id")
            if jid and jid not in seen_ids:
                session_jobs.append(dj)
                seen_ids.add(jid)
    except Exception:
        pass

    return session_jobs


def get_active_job_id() -> Optional[str]:
    """Retrieve the ID of the active statement job, defaulting to the newest database or session job."""
    init_session_state()
    active_id = st.session_state.active_job_id
    all_jobs = get_all_jobs()
    if not all_jobs:
        return None

    valid_ids = [j.get("job_id") for j in all_jobs if j.get("job_id")]
    if active_id and active_id in valid_ids:
        return active_id

    # Default to the most recent job
    latest_id = valid_ids[0]
    st.session_state.active_job_id = latest_id
    return latest_id


def get_active_job() -> Optional[Dict[str, Any]]:
    """Get the full dictionary for the active job, hydrating from MongoDB if needed."""
    job_id = get_active_job_id()
    if not job_id:
        return None

    # Check in-memory cache first
    cached = st.session_state.processed_jobs.get(job_id)
    if cached and cached.get("transactions"):
        return cached

    # Hydrate from MongoDB
    try:
        from src.database.collections import get_job, get_transactions, get_validation_issues
        from src.database.db import get_database
        from src.processing.balance_reconciliation import reconcile_balances

        job_doc = get_job(job_id)
        if job_doc:
            txns = get_transactions(job_id=job_id, limit=10000)
            issues = get_validation_issues(job_id=job_id)
            db = get_database()
            account_doc = None
            if db is not None and job_doc.get("account_id"):
                account_doc = db.accounts.find_one({"account_id": job_doc.get("account_id")}, {"_id": 0})

            recon = reconcile_balances(txns)

            job_doc["transactions"] = txns
            job_doc["validation_issues"] = issues
            job_doc["reconciliation"] = recon
            job_doc["account_info"] = account_doc or {"bank_name": job_doc.get("bank_name", "Unknown Bank")}
            job_doc.setdefault("stats", {
                "bank_name": job_doc.get("bank_name", "Unknown Bank"),
                "parser": "generic",
                "transaction_count": len(txns)
            })
            st.session_state.processed_jobs[job_id] = job_doc
            return job_doc
    except Exception:
        pass

    return cached


def get_all_accounts() -> List[Dict[str, Any]]:
    """Retrieve unique accounts from all processed statements and database."""
    accounts_dict = {}

    # 1. Database accounts
    try:
        from src.database.collections import get_all_accounts as db_get_accounts
        for a in db_get_accounts():
            aid = a.get("account_id")
            if aid:
                accounts_dict[aid] = a
    except Exception:
        pass

    # 2. Session jobs
    jobs = get_all_jobs()
    for j in jobs:
        acct = j.get("account_info", {})
        aid = j.get("account_id") or acct.get("account_id")
        if aid and aid not in accounts_dict:
            accounts_dict[aid] = {
                "account_id": aid,
                "bank_name": j.get("bank_name") or acct.get("bank_name", "Unknown Bank"),
                "account_holder": acct.get("account_holder", "Account Holder"),
                "account_number_masked": acct.get("account_number_masked", ""),
                "currency": acct.get("currency", "INR"),
            }
    return list(accounts_dict.values())


def get_scoped_dataframe(
    scope: str = "Current statement",
    account_id: Optional[str] = None
) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """
    Build a single normalized pandas DataFrame for the requested scope.
    
    Returns:
        (df, metadata_dict)
    """
    init_session_state()
    active_id = get_active_job_id()
    
    raw_txns: List[Dict[str, Any]] = []
    meta = {
        "scope": scope,
        "total_raw": 0,
        "duplicates_excluded": 0,
        "active_job_id": active_id,
        "account_id": account_id,
        "bank_name": "All Banks",
    }

    if scope == "Current statement":
        active_job = get_active_job()
        if active_job:
            raw_txns = list(active_job.get("transactions", []))
            meta["bank_name"] = active_job.get("stats", {}).get("bank_name") or active_job.get("bank_name", "Unknown Bank")
    elif "account" in scope.lower() and account_id:
        # Collect from session jobs
        for j in st.session_state.processed_jobs.values():
            if j.get("account_id") == account_id or j.get("account_info", {}).get("account_id") == account_id:
                raw_txns.extend(j.get("transactions", []))
                meta["bank_name"] = j.get("bank_name", "Selected Account")
        # Collect from database
        try:
            from src.database.collections import get_transactions
            db_txns = get_transactions(account_id=account_id, limit=10000)
            seen_ids = {t.get("transaction_id") for t in raw_txns if t.get("transaction_id")}
            for t in db_txns:
                if t.get("transaction_id") not in seen_ids:
                    raw_txns.append(t)
                    seen_ids.add(t.get("transaction_id"))
        except Exception:
            pass
    else:  # All statements combined
        seen_tx_ids = set()
        seen_fingerprints = set()
        
        all_candidate_txns = []
        for j in st.session_state.processed_jobs.values():
            all_candidate_txns.extend(j.get("transactions", []))
            
        try:
            from src.database.collections import get_transactions
            all_candidate_txns.extend(get_transactions(limit=10000))
        except Exception:
            pass

        meta["total_raw"] = len(all_candidate_txns)
        
        # De-duplicate
        for t in all_candidate_txns:
            tid = t.get("transaction_id")
            fp = t.get("fingerprint")
            aid = t.get("account_id", "")
            
            if tid and tid in seen_tx_ids:
                meta["duplicates_excluded"] += 1
                continue
                
            combined_fp = f"{aid}_{fp}" if (aid and fp) else None
            if combined_fp and combined_fp in seen_fingerprints:
                meta["duplicates_excluded"] += 1
                continue

            if tid:
                seen_tx_ids.add(tid)
            if combined_fp:
                seen_fingerprints.add(combined_fp)
                
            raw_txns.append(t)

    if not raw_txns:
        empty_df = pd.DataFrame(columns=[
            "transaction_id", "transaction_date", "description", "raw_description",
            "debit", "credit", "balance", "net_amount", "category", "classification_method",
            "ml_confidence", "rule_id", "review_required", "validation_status",
            "extraction_method", "source_page", "account_id", "job_id", "is_expense"
        ])
        return empty_df, meta

    # Normalize into DataFrame
    records = []
    for r in raw_txns:
        deb = to_float(r.get("debit"), default=0.0)
        cred = to_float(r.get("credit"), default=0.0)
        bal = to_float(r.get("balance"), default=float("nan"))
        conf = to_float(r.get("ml_confidence"), default=float("nan"))
        conf_val = None if math.isnan(conf) else conf

        raw_dt = r.get("transaction_date") or r.get("raw_date")
        if hasattr(raw_dt, "strftime"):
            dt_str = raw_dt.strftime("%Y-%m-%d")
        else:
            dt_str = str(raw_dt or "")

        records.append({
            "transaction_id": str(r.get("transaction_id", "")),
            "transaction_date": dt_str,
            "description": str(r.get("description", "")),
            "raw_description": str(r.get("raw_description", r.get("description", ""))),
            "debit": deb if deb > 0 else 0.0,
            "credit": cred if cred > 0 else 0.0,
            "balance": None if math.isnan(bal) else bal,
            "net_amount": cred - deb,
            "category": str(r.get("category") or "Unclassified"),
            "classification_method": str(r.get("classification_method") or "UNKNOWN"),
            "ml_confidence": conf_val,
            "rule_id": str(r.get("rule_id") or ""),
            "review_required": bool(r.get("review_required", False)),
            "validation_status": str(r.get("validation_status") or "VALID"),
            "extraction_method": str(r.get("extraction_method") or "text"),
            "source_page": int(r.get("source_page") or 1),
            "account_id": str(r.get("account_id") or ""),
            "job_id": str(r.get("job_id") or ""),
            "reference": str(r.get("reference") or ""),
            "is_expense": deb > 0,
        })

    df = pd.DataFrame(records)
    df["date_dt"] = pd.to_datetime(df["transaction_date"], errors="coerce")
    df = df.sort_values(by=["date_dt", "source_page", "transaction_id"], ascending=[True, True, True]).reset_index(drop=True)

    return df, meta
