"""Design system tokens and CSS injection for FinExtract Operations Console."""
import streamlit as st

# Color Palette Tokens
PRIMARY = "#4F46E5"
PRIMARY_HOVER = "#4338CA"
ACCENT_CYAN = "#06B6D4"
BG_MAIN = "#F4F6FB"
SURFACE_CARD = "#FFFFFF"
BORDER_COLOR = "#E6EAF2"

TEXT_PRIMARY = "#0F172A"
TEXT_SECONDARY = "#475569"
TEXT_MUTED = "#94A3B8"

SUCCESS_GREEN = "#10B981"
WARNING_AMBER = "#F59E0B"
DANGER_RED = "#EF4444"
INFO_BLUE = "#3B82F6"

SIDEBAR_BG = "#0B1220"
SIDEBAR_HOVER = "#151F35"
SIDEBAR_ACTIVE = "#1D2A4A"
SIDEBAR_TEXT = "#A9B4CC"

# Standard 10-Color Qualitative Palette
CHART_PALETTE = [
    "#4F46E5", "#06B6D4", "#10B981", "#F59E0B", "#EF4444",
    "#8B5CF6", "#EC4899", "#14B8A6", "#F97316", "#64748B"
]

# Stable Category Color Dictionary
CATEGORY_COLORS = {
    "Salary": "#10B981",
    "Income": "#06B6D4",
    "Food & Dining": "#F59E0B",
    "Groceries": "#84CC16",
    "Shopping": "#EC4899",
    "Transportation": "#3B82F6",
    "Fuel": "#F97316",
    "Utilities": "#6366F1",
    "Rent": "#8B5CF6",
    "Healthcare": "#EF4444",
    "Education": "#14B8A6",
    "Entertainment": "#D946EF",
    "Travel": "#0284C7",
    "ATM/Cash Withdrawal": "#64748B",
    "Bank Charges": "#94A3B8",
    "Loan/EMI": "#DC2626",
    "Investment": "#059669",
    "Insurance": "#475569",
    "Transfers": "#A855F7",
    "Unclassified": "#9CA3AF",
}


def inject_theme():
    """Inject custom CSS matching Stripe/Ramp/Linear enterprise aesthetics."""
    css = f"""
    <style>
    /* System font stack with Inter first */
    html, body, [class*="css"], [class*="st-"] {{
        font-family: Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
        letter-spacing: -0.011em;
    }}

    /* Global page canvas */
    .stApp {{
        background-color: {BG_MAIN};
        color: {TEXT_PRIMARY};
    }}

    /* Hide default Streamlit padding */
    .block-container {{
        padding-top: 2rem !important;
        padding-bottom: 3.5rem !important;
        max-width: 1400px;
    }}

    /* Tabular numbers for finance */
    .tabular-num {{
        font-variant-numeric: tabular-nums;
        font-family: "SF Mono", Menlo, Consolas, Monaco, monospace;
    }}

    /* Sidebar container styling */
    [data-testid="stSidebar"] {{
        background-color: {SIDEBAR_BG} !important;
        border-right: 1px solid rgba(255, 255, 255, 0.08);
    }}
    [data-testid="stSidebar"] * {{
        color: {SIDEBAR_TEXT};
    }}
    [data-testid="stSidebar"] h1, [data-testid="stSidebar"] h2, [data-testid="stSidebar"] h3 {{
        color: #FFFFFF !important;
    }}

    /* Sidebar nav radio styling */
    [data-testid="stSidebar"] .stRadio > div {{
        gap: 4px;
    }}
    [data-testid="stSidebar"] .stRadio label {{
        display: flex;
        align-items: center;
        padding: 8px 12px;
        border-radius: 8px;
        transition: all 150ms ease;
        cursor: pointer;
        font-size: 0.875rem;
        font-weight: 500;
        margin-bottom: 2px;
    }}
    [data-testid="stSidebar"] .stRadio label:hover {{
        background-color: {SIDEBAR_HOVER};
        color: #FFFFFF;
    }}
    [data-testid="stSidebar"] .stRadio label[data-checked="true"] {{
        background-color: {SIDEBAR_ACTIVE};
        color: #FFFFFF !important;
        font-weight: 600;
        border-left: 3px solid {PRIMARY};
    }}

    /* Main Typography */
    .op-page-header {{
        margin-bottom: 1.5rem;
        padding-bottom: 1rem;
        border-bottom: 1px solid {BORDER_COLOR};
        display: flex;
        justify-content: space-between;
        align-items: flex-end;
    }}
    .op-page-title {{
        font-size: 1.75rem;
        font-weight: 700;
        color: {TEXT_PRIMARY};
        line-height: 1.25;
        margin: 0;
    }}
    .op-page-subtitle {{
        font-size: 0.925rem;
        color: {TEXT_SECONDARY};
        margin-top: 0.25rem;
        margin-bottom: 0;
    }}

    /* Context Scope Bar */
    .op-scope-bar {{
        background-color: #FFFFFF;
        border: 1px solid {BORDER_COLOR};
        border-radius: 12px;
        padding: 8px 16px;
        margin-bottom: 1.25rem;
        display: flex;
        align-items: center;
        gap: 12px;
        box-shadow: 0 1px 2px rgba(15, 23, 42, 0.04);
    }}
    .op-scope-pill {{
        background-color: #EEF2FF;
        color: {PRIMARY};
        font-size: 0.75rem;
        font-weight: 600;
        padding: 4px 10px;
        border-radius: 999px;
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }}

    /* Cards */
    .op-card {{
        background-color: {SURFACE_CARD};
        border: 1px solid {BORDER_COLOR};
        border-radius: 16px;
        padding: 1.25rem 1.5rem;
        box-shadow: 0 1px 3px rgba(15, 23, 42, 0.04), 0 8px 24px rgba(15, 23, 42, 0.03);
        margin-bottom: 1.25rem;
        transition: transform 150ms ease, box-shadow 150ms ease;
    }}
    .op-card:hover {{
        box-shadow: 0 4px 6px -1px rgba(15, 23, 42, 0.06), 0 12px 28px rgba(15, 23, 42, 0.06);
    }}

    /* KPI Cards */
    .op-kpi-card {{
        background-color: #FFFFFF;
        border: 1px solid {BORDER_COLOR};
        border-radius: 14px;
        padding: 1.1rem 1.25rem;
        box-shadow: 0 1px 2px rgba(15, 23, 42, 0.04);
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        min-height: 110px;
        transition: all 150ms ease;
    }}
    .op-kpi-card:hover {{
        border-color: #CBD5E1;
        transform: translateY(-1px);
    }}
    .op-kpi-label {{
        font-size: 0.75rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: {TEXT_MUTED};
        margin-bottom: 0.4rem;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }}
    .op-kpi-val {{
        font-size: 1.625rem;
        font-weight: 700;
        color: {TEXT_PRIMARY};
        line-height: 1.2;
        font-variant-numeric: tabular-nums;
    }}
    .op-kpi-sub {{
        font-size: 0.775rem;
        color: {TEXT_SECONDARY};
        margin-top: 0.35rem;
        display: flex;
        align-items: center;
        gap: 6px;
    }}

    /* Badges */
    .op-badge {{
        display: inline-flex;
        align-items: center;
        gap: 5px;
        padding: 3px 9px;
        border-radius: 6px;
        font-size: 0.725rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.03em;
        line-height: 1.4;
    }}
    .op-badge-success {{ background-color: #ECFDF5; color: #047857; border: 1px solid #A7F3D0; }}
    .op-badge-danger {{ background-color: #FEF2F2; color: #B91C1C; border: 1px solid #FECACA; }}
    .op-badge-warning {{ background-color: #FFFBEB; color: #B45309; border: 1px solid #FDE68A; }}
    .op-badge-info {{ background-color: #EFF6FF; color: #1D4ED8; border: 1px solid #BFDBFE; }}
    .op-badge-neutral {{ background-color: #F8FAFC; color: #475569; border: 1px solid #E2E8F0; }}

    /* Insights Banner */
    .op-insight-card {{
        background: linear-gradient(135deg, #F8FAFC 0%, #EEF2FF 100%);
        border: 1px solid #E0E7FF;
        border-radius: 12px;
        padding: 0.9rem 1.1rem;
        margin-bottom: 0.75rem;
        display: flex;
        gap: 12px;
        align-items: flex-start;
    }}
    .op-insight-icon {{
        font-size: 1.25rem;
        line-height: 1;
        margin-top: 2px;
    }}
    .op-insight-title {{
        font-size: 0.85rem;
        font-weight: 600;
        color: {TEXT_PRIMARY};
    }}
    .op-insight-desc {{
        font-size: 0.8rem;
        color: {TEXT_SECONDARY};
        margin-top: 2px;
    }}

    /* System Status Footer */
    .op-sys-status {{
        padding: 12px 14px;
        border-radius: 10px;
        background-color: rgba(255, 255, 255, 0.04);
        border: 1px solid rgba(255, 255, 255, 0.08);
        font-size: 0.75rem;
        margin-top: 1rem;
    }}
    .op-sys-status-row {{
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 6px;
    }}

    /* Empty state card */
    .op-empty-state {{
        text-align: center;
        padding: 3rem 1.5rem;
        background-color: #FFFFFF;
        border: 1.5px dashed {BORDER_COLOR};
        border-radius: 16px;
        margin: 1.5rem 0;
    }}
    .op-empty-icon {{
        font-size: 2.5rem;
        color: {TEXT_MUTED};
        margin-bottom: 0.75rem;
    }}
    .op-empty-title {{
        font-size: 1.1rem;
        font-weight: 600;
        color: {TEXT_PRIMARY};
        margin-bottom: 0.25rem;
    }}
    .op-empty-body {{
        font-size: 0.875rem;
        color: {TEXT_SECONDARY};
        max-width: 440px;
        margin: 0 auto 1.25rem auto;
    }}

    /* ─── Form Controls & Selectbox Visibility (High Contrast) ─── */
    .stSelectbox label, .stTextInput label, .stNumberInput label, .stMultiSelect label {{
        color: #1E293B !important;
        font-weight: 600 !important;
        font-size: 0.85rem !important;
    }}

    /* Main Area Selectboxes & Inputs */
    [data-testid="stMain"] div[data-baseweb="select"] > div,
    [data-testid="stMainBlockContainer"] div[data-baseweb="select"] > div,
    .main div[data-baseweb="select"] > div,
    div[data-testid="stSelectbox"] > div > div {{
        background-color: #FFFFFF !important;
        border: 1.5px solid #CBD5E1 !important;
        border-radius: 8px !important;
        color: #0F172A !important;
    }}
    [data-testid="stMain"] div[data-baseweb="select"] *,
    [data-testid="stMainBlockContainer"] div[data-baseweb="select"] *,
    .main div[data-baseweb="select"] *,
    div[data-testid="stSelectbox"] span,
    div[data-testid="stSelectbox"] div[aria-selected],
    div[data-testid="stSelectbox"] div[class*="ValueContainer"] {{
        color: #0F172A !important;
        font-weight: 500 !important;
        opacity: 1 !important;
    }}
    [data-testid="stMain"] div[data-baseweb="select"] svg,
    [data-testid="stMainBlockContainer"] div[data-baseweb="select"] svg,
    .main div[data-baseweb="select"] svg {{
        fill: #475569 !important;
    }}

    /* Dropdown Popover & Listbox Menu */
    div[data-baseweb="popover"],
    div[data-baseweb="popover"] > div,
    div[data-baseweb="menu"],
    ul[role="listbox"] {{
        background-color: #FFFFFF !important;
        border: 1px solid #CBD5E1 !important;
        border-radius: 8px !important;
        box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.15), 0 8px 10px -6px rgba(0, 0, 0, 0.1) !important;
    }}
    ul[role="listbox"] li,
    li[role="option"],
    div[role="option"] {{
        background-color: #FFFFFF !important;
        color: #0F172A !important;
        font-size: 0.875rem !important;
        padding: 8px 12px !important;
    }}
    ul[role="listbox"] li *,
    li[role="option"] * {{
        color: #0F172A !important;
    }}
    ul[role="listbox"] li:hover,
    li[role="option"]:hover,
    li[role="option"][aria-selected="true"] {{
        background-color: #EEF2FF !important;
        color: #4F46E5 !important;
        font-weight: 600 !important;
    }}
    ul[role="listbox"] li:hover *,
    li[role="option"]:hover * {{
        color: #4F46E5 !important;
    }}

    /* Inputs (Text, Number, Area) */
    [data-testid="stMain"] input, [data-testid="stMain"] textarea,
    [data-testid="stMainBlockContainer"] input, [data-testid="stMainBlockContainer"] textarea,
    .main input, .main textarea {{
        background-color: #FFFFFF !important;
        color: #0F172A !important;
        border: 1.5px solid #CBD5E1 !important;
        border-radius: 8px !important;
        font-size: 0.875rem !important;
    }}
    [data-testid="stMain"] input:focus, [data-testid="stMain"] textarea:focus,
    [data-testid="stMainBlockContainer"] input:focus, [data-testid="stMainBlockContainer"] textarea:focus {{
        border-color: #4F46E5 !important;
        box-shadow: 0 0 0 2px rgba(79, 70, 229, 0.2) !important;
    }}

    /* Sidebar Selectbox Customization (Dark Theme Legible) */
    [data-testid="stSidebar"] div[data-baseweb="select"] > div {{
        background-color: #151F35 !important;
        border: 1px solid rgba(255, 255, 255, 0.2) !important;
        border-radius: 8px !important;
    }}
    [data-testid="stSidebar"] div[data-baseweb="select"] *,
    [data-testid="stSidebar"] div[data-testid="stSelectbox"] * {{
        color: #F8FAFC !important;
    }}
    [data-testid="stSidebar"] div[data-baseweb="select"] svg {{
        fill: #94A3B8 !important;
    }}
    </style>
    """
    st.markdown(css, unsafe_allow_html=True)

