"""Data formatting and text sanitization helpers for FinExtract UI."""
import html
import math
import re
from decimal import Decimal
from typing import Any, Optional, Union


def to_float(val: Any, default: float = 0.0) -> float:
    """Safely convert any numeric representation to float."""
    if val is None:
        return default
    if isinstance(val, (float, int)):
        if math.isnan(val):
            return default
        return float(val)
    if isinstance(val, Decimal):
        return float(val)
    # Check for MongoDB Decimal128
    if hasattr(val, "to_decimal"):
        return float(val.to_decimal())
    try:
        s = str(val).strip().replace(",", "").replace("₹", "")
        if not s or s in ("—", "-", "None", "nan", "NaN"):
            return default
        return float(s)
    except (ValueError, TypeError):
        return default


def fmt_inr(
    val: Any,
    show_symbol: bool = True,
    compact: bool = False,
    default_empty: str = "—"
) -> str:
    """
    Format a number using Indian currency convention (lakhs & crores).
    e.g. 12,34,567.89 -> ₹12,34,568 or compact ₹12.3L
    """
    if val is None:
        return default_empty
    num = to_float(val, default=float("nan"))
    if math.isnan(num):
        return default_empty

    sym = "₹" if show_symbol else ""
    sign = "-" if num < 0 else ""
    abs_num = abs(num)

    if compact:
        if abs_num >= 10000000:  # 1 Crore
            return f"{sign}{sym}{abs_num / 10000000:.2f} Cr"
        elif abs_num >= 100000:   # 1 Lakh
            return f"{sign}{sym}{abs_num / 100000:.2f} L"
        elif abs_num >= 1000:     # 1 Thousand
            return f"{sign}{sym}{abs_num / 1000:.1f} K"
        else:
            return f"{sign}{sym}{abs_num:.2f}"

    # Standard Indian formatting
    int_part = int(abs_num)
    dec_part = f"{abs_num - int_part:.2f}"[2:]  # "00"
    s_int = str(int_part)

    if len(s_int) <= 3:
        formatted_int = s_int
    else:
        last3 = s_int[-3:]
        rest = s_int[:-3]
        groups = []
        while len(rest) > 2:
            groups.insert(0, rest[-2:])
            rest = rest[:-2]
        if rest:
            groups.insert(0, rest)
        formatted_int = ",".join(groups) + "," + last3

    return f"{sign}{sym}{formatted_int}.{dec_part}"


def fmt_date(val: Any, default_empty: str = "—") -> str:
    """Format dates uniformly to DD Mon YYYY."""
    if val is None:
        return default_empty
    try:
        import pandas as pd
        if isinstance(val, str):
            ts = pd.to_datetime(val, errors="coerce")
        else:
            ts = pd.to_datetime(val)
        if pd.isna(ts):
            return str(val) if val else default_empty
        return ts.strftime("%d %b %Y")
    except Exception:
        return str(val) if val else default_empty


def fmt_pct(val: Any, default_empty: str = "—") -> str:
    """Format decimal percentage (e.g. 0.854 -> 85.4%)."""
    if val is None:
        return default_empty
    num = to_float(val, default=float("nan"))
    if math.isnan(num):
        return default_empty
    # If passed as 85.4 instead of 0.854
    if num > 1.0:
        return f"{num:.1f}%"
    return f"{num * 100.0:.1f}%"


def clean_html(val: Any) -> str:
    """
    Sanitize text for safe HTML display.
    Escapes HTML entities and neutralizes LaTeX control characters like literal dollar signs.
    """
    if val is None:
        return ""
    s = str(val)
    # Escape HTML first, then replace $ with &#36; to prevent KaTeX math mode and avoid double-escaping &
    escaped = html.escape(s)
    return escaped.replace("$", "&#36;")
