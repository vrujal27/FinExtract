"""Reusable presentation components for FinExtract UI."""
import html
import streamlit as st
from typing import Optional, List, Dict, Any
from src.ui.formatters import clean_html, fmt_pct
from src.ui.theme import (
    CATEGORY_COLORS, PRIMARY, SUCCESS_GREEN, WARNING_AMBER, DANGER_RED,
    INFO_BLUE, TEXT_PRIMARY, TEXT_SECONDARY, TEXT_MUTED
)


def page_header(title: str, subtitle: str, right_badge: Optional[str] = None):
    """Render a standardized page title header."""
    badge_html = f'<span class="op-badge op-badge-info">{clean_html(right_badge)}</span>' if right_badge else ""
    st.markdown(f"""
    <div class="op-page-header">
        <div>
            <h1 class="op-page-title">{clean_html(title)}</h1>
            <p class="op-page-subtitle">{clean_html(subtitle)}</p>
        </div>
        <div>{badge_html}</div>
    </div>
    """, unsafe_allow_html=True)


def scope_bar(
    scope_name: str,
    date_range_str: Optional[str] = None,
    account_str: Optional[str] = None,
    total_txns: Optional[int] = None
):
    """Render the global context bar indicating the active scope."""
    pills = [f'<span class="op-scope-pill">📍 Scope: {clean_html(scope_name)}</span>']
    if account_str:
        pills.append(f'<span class="op-scope-pill">🏦 Account: {clean_html(account_str)}</span>')
    if date_range_str:
        pills.append(f'<span class="op-scope-pill">📅 Period: {clean_html(date_range_str)}</span>')
    if total_txns is not None:
        pills.append(f'<span class="op-scope-pill">💳 {total_txns:,} Transactions</span>')

    pills_html = "".join(pills)
    st.markdown(f"""
    <div class="op-scope-bar">
        {pills_html}
    </div>
    """, unsafe_allow_html=True)


def kpi_card(
    label: str,
    value: str,
    delta: Optional[str] = None,
    delta_type: str = "neutral",
    icon: Optional[str] = None,
    help_text: Optional[str] = None
):
    """Render an executive KPI card with tabular numeric formatting."""
    delta_html = ""
    if delta:
        delta_class = "op-badge-success" if delta_type == "good" else "op-badge-danger" if delta_type == "bad" else "op-badge-neutral"
        delta_html = f'<span class="op-badge {delta_class}" style="font-size: 0.7rem; padding: 1px 6px;">{clean_html(delta)}</span>'

    icon_html = f'<span style="font-size: 1rem; opacity: 0.7;">{icon}</span>' if icon else ""

    st.markdown(f"""
    <div class="op-kpi-card">
        <div class="op-kpi-label">
            <span>{clean_html(label)}</span>
            {icon_html}
        </div>
        <div class="op-kpi-val">{clean_html(value)}</div>
        <div class="op-kpi-sub">
            {delta_html}
            <span style="color: {TEXT_MUTED}; font-size: 0.75rem;">{clean_html(help_text or "")}</span>
        </div>
    </div>
    """, unsafe_allow_html=True)


def status_badge(status: str = "UNKNOWN", variant: Optional[str] = None, *args, **kwargs) -> str:
    """Return HTML markup for a validation or reconciliation status badge."""
    s = str(status or "UNKNOWN").upper()
    if variant:
        v = str(variant).lower()
        badge_cls = f"op-badge-{v}" if v in ("success", "danger", "warning", "info", "neutral") else (
            "op-badge-success" if v in ("green", "emerald") else
            "op-badge-danger" if v in ("red", "danger") else
            "op-badge-warning" if v in ("amber", "yellow", "orange") else
            "op-badge-info" if v in ("blue", "cyan", "indigo") else
            "op-badge-neutral"
        )
        return f'<span class="op-badge {badge_cls}">{clean_html(s)}</span>'

    if s in ("PASSED", "MATCHED", "COMPLETED", "VERIFIED"):
        return f'<span class="op-badge op-badge-success">✓ {clean_html(s)}</span>'
    elif s in ("WARNING", "NEEDS REVIEW", "REVIEW_REQUIRED", "PARTIAL"):
        return f'<span class="op-badge op-badge-warning">⚠ {clean_html(s)}</span>'
    elif s in ("FAILED", "MISMATCH", "ERROR"):
        return f'<span class="op-badge op-badge-danger">✕ {clean_html(s)}</span>'
    elif s in ("INFO", "INCONCLUSIVE"):
        return f'<span class="op-badge op-badge-neutral">ℹ {clean_html(s)}</span>'
    else:
        return f'<span class="op-badge op-badge-info">{clean_html(s)}</span>'


def method_badge(method: str) -> str:
    """Return HTML markup for a classification/extraction method badge."""
    m = (method or "UNKNOWN").upper()
    if "RULE" in m:
        return '<span class="op-badge op-badge-success" style="background-color: #F0FDF4; color: #166534;">⚡ Rule Engine</span>'
    elif "MACHINE" in m or "ML" in m:
        return '<span class="op-badge op-badge-info" style="background-color: #EEF2FF; color: #3730A3;">🤖 ML Model</span>'
    elif "MANUAL" in m or "USER" in m:
        return '<span class="op-badge op-badge-warning" style="background-color: #FFFBEB; color: #92400E;">✎ Manual</span>'
    elif "OCR" in m:
        return '<span class="op-badge op-badge-info" style="background-color: #F0F9FF; color: #0369A1;">👁 OCR</span>'
    elif "TEXT" in m or "PYMUPDF" in m:
        return '<span class="op-badge op-badge-neutral" style="background-color: #F8FAFC; color: #334155;">📄 Native Text</span>'
    else:
        return f'<span class="op-badge op-badge-neutral">{clean_html(m)}</span>'


def category_chip(category: str) -> str:
    """Return HTML markup for a colored category chip."""
    cat = category or "Unclassified"
    color = CATEGORY_COLORS.get(cat, "#64748B")
    return (
        f'<span style="display: inline-flex; align-items: center; gap: 6px; '
        f'font-size: 0.775rem; font-weight: 500; color: #1E293B; background-color: #F8FAFC; '
        f'padding: 2px 8px; border-radius: 999px; border: 1px solid #E2E8F0;">'
        f'<span style="width: 8px; height: 8px; border-radius: 50%; background-color: {color}; display: inline-block;"></span>'
        f'{clean_html(cat)}</span>'
    )


def confidence_bar(p: Optional[float]) -> str:
    """Render a compact horizontal confidence bar."""
    if p is None or p == 0:
        return '<span style="color: #94A3B8; font-size: 0.75rem;">—</span>'
    pct = p * 100.0 if p <= 1.0 else p
    color = SUCCESS_GREEN if pct >= 85 else WARNING_AMBER if pct >= 60 else DANGER_RED
    return (
        f'<div style="display: flex; align-items: center; gap: 6px;">'
        f'<div style="background-color: #E2E8F0; width: 44px; height: 6px; border-radius: 3px; overflow: hidden;">'
        f'<div style="background-color: {color}; width: {min(pct, 100):.0f}%; height: 100%;"></div>'
        f'</div>'
        f'<span style="font-size: 0.75rem; font-weight: 600; color: {color};">{pct:.0f}%</span>'
        f'</div>'
    )


def empty_state(
    icon: str = "📁",
    title: str = "",
    body: str = "",
    action_label: Optional[str] = None,
    message: Optional[str] = None,
    *args,
    **kwargs
):
    """Render an informative empty state callout."""
    text = message if message is not None else body
    st.markdown(f"""
    <div class="op-empty-state">
        <div class="op-empty-icon">{icon}</div>
        <div class="op-empty-title">{clean_html(title)}</div>
        <div class="op-empty-body">{clean_html(text)}</div>
    </div>
    """, unsafe_allow_html=True)


def skeleton(height_px: int = 240):
    """Render a shimmer placeholder for computing charts."""
    st.markdown(f"""
    <div style="height: {height_px}px; width: 100%; border-radius: 12px; background: linear-gradient(90deg, #F1F5F9 25%, #E2E8F0 50%, #F1F5F9 75%); background-size: 200% 100%; animation: shimmer 1.5s infinite; margin-bottom: 1rem;"></div>
    """, unsafe_allow_html=True)

