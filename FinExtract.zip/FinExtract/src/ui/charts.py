"""Plotly chart generation suite tailored for FinExtract Operations Console."""
import re
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from typing import Optional, List, Dict, Any

from src.ui.theme import (
    CATEGORY_COLORS, CHART_PALETTE, PRIMARY, ACCENT_CYAN,
    SUCCESS_GREEN, DANGER_RED, WARNING_AMBER, INFO_BLUE,
    TEXT_PRIMARY, TEXT_SECONDARY, TEXT_MUTED, BORDER_COLOR
)
from src.ui.formatters import fmt_inr, clean_html


def apply_theme(fig: go.Figure, title: str = "", subtitle: str = "") -> go.Figure:
    """Apply consistent fintech design language across all Plotly charts."""
    title_text = ""
    if title:
        title_text = f"<b>{title}</b>"
        if subtitle:
            title_text += f"<br><span style='font-size:11px;color:{TEXT_MUTED};font-weight:400;'>{subtitle}</span>"

    fig.update_layout(
        title=dict(
            text=title_text,
            font=dict(family="Inter, -apple-system, sans-serif", size=14, color=TEXT_PRIMARY),
            x=0.01,
            y=0.96,
            xanchor="left",
            yanchor="top"
        ) if title else None,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(family="Inter, -apple-system, sans-serif", size=12, color=TEXT_SECONDARY),
        margin=dict(l=16, r=16, t=44 if title else 20, b=24),
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1.0,
            font=dict(size=11),
            bgcolor="rgba(255,255,255,0.7)"
        ),
        hoverlabel=dict(
            bgcolor="#1E293B",
            font_size=12,
            font_family="Inter, sans-serif",
            font_color="#FFFFFF"
        ),
        colorway=CHART_PALETTE,
    )

    fig.update_xaxes(
        showgrid=False,
        zeroline=False,
        linecolor=BORDER_COLOR,
        tickfont=dict(size=11, color=TEXT_MUTED)
    )
    fig.update_yaxes(
        showgrid=True,
        gridcolor="#F1F5F9",
        zeroline=False,
        linecolor=BORDER_COLOR,
        tickfont=dict(size=11, color=TEXT_MUTED)
    )

    return fig


def chart_empty(message: str = "No data available for this view") -> go.Figure:
    """Return an empty placeholder figure."""
    fig = go.Figure()
    fig.add_annotation(
        text=message,
        xref="paper", yref="paper",
        x=0.5, y=0.5,
        showarrow=False,
        font=dict(size=13, color=TEXT_MUTED)
    )
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        xaxis=dict(showgrid=False, showticklabels=False, zeroline=False),
        yaxis=dict(showgrid=False, showticklabels=False, zeroline=False),
        margin=dict(l=10, r=10, t=20, b=20),
        height=260
    )
    return fig


def chart_income_expenses_monthly(df: pd.DataFrame) -> go.Figure:
    """Monthly grouped bars of Total Inflows vs Outflows + Net Trend."""
    if df.empty or "date_dt" not in df.columns or df["date_dt"].dropna().empty:
        return chart_empty("No dated transactions available for monthly trends.")

    df_valid = df.dropna(subset=["date_dt"]).copy()
    df_valid["month_period"] = df_valid["date_dt"].dt.to_period("M")
    
    monthly = df_valid.groupby("month_period").agg(
        Inflow=("credit", "sum"),
        Outflow=("debit", "sum"),
    ).reset_index()

    monthly["Month"] = monthly["month_period"].dt.strftime("%b %Y")
    monthly["Net"] = monthly["Inflow"] - monthly["Outflow"]

    fig = go.Figure()

    # Inflow Bars (Green)
    fig.add_trace(go.Bar(
        x=monthly["Month"],
        y=monthly["Inflow"],
        name="Inflows (Credits)",
        marker=dict(color=SUCCESS_GREEN, cornerradius=4),
        hovertemplate="<b>Inflow (%{x})</b>: ₹%{y:,.2f}<extra></extra>"
    ))

    # Outflow Bars (Red)
    fig.add_trace(go.Bar(
        x=monthly["Month"],
        y=monthly["Outflow"],
        name="Outflows (Debits)",
        marker=dict(color=DANGER_RED, cornerradius=4),
        hovertemplate="<b>Outflow (%{x})</b>: ₹%{y:,.2f}<extra></extra>"
    ))

    # Net Line
    fig.add_trace(go.Scatter(
        x=monthly["Month"],
        y=monthly["Net"],
        name="Net Cash Flow",
        mode="lines+markers",
        line=dict(color=PRIMARY, width=2.5),
        marker=dict(size=6, color=PRIMARY),
        hovertemplate="<b>Net (%{x})</b>: ₹%{y:,.2f}<extra></extra>"
    ))

    fig.update_layout(barmode="group", height=320)
    return apply_theme(fig, "Cash Flow Dynamics", "Monthly comparison of cash inflows, outflows, and net delta")


def chart_category_donut(df: pd.DataFrame) -> go.Figure:
    """Clean donut chart of expenses by category with total centered."""
    expense_df = df[df["debit"] > 0]
    if expense_df.empty:
        return chart_empty("No expense transactions recorded.")

    cat_totals = expense_df.groupby("category")["debit"].sum().reset_index()
    cat_totals = cat_totals.sort_values(by="debit", ascending=False)
    total_spend = cat_totals["debit"].sum()

    colors = [CATEGORY_COLORS.get(c, "#64748B") for c in cat_totals["category"]]

    fig = go.Figure(data=[go.Pie(
        labels=cat_totals["category"],
        values=cat_totals["debit"],
        hole=0.62,
        marker=dict(colors=colors, line=dict(color="#FFFFFF", width=2)),
        textinfo="percent",
        textposition="inside",
        insidetextorientation="horizontal",
        hovertemplate="<b>%{label}</b><br>Amount: ₹%{value:,.2f}<br>Share: %{percent}<extra></extra>"
    )])

    # Add center total
    fig.add_annotation(
        text=f"<span style='font-size:11px;color:{TEXT_MUTED};font-weight:600;'>TOTAL OUTFLOW</span><br><b style='font-size:16px;color:{TEXT_PRIMARY};'>{fmt_inr(total_spend, compact=True)}</b>",
        x=0.5, y=0.5,
        showarrow=False,
        align="center"
    )

    fig.update_layout(
        height=320,
        showlegend=True,
        legend=dict(orientation="v", yanchor="middle", y=0.5, xanchor="left", x=1.02)
    )
    return apply_theme(fig, "Expense Distribution by Category", "Proportional breakdown of debits across verified categories")


def chart_category_treemap(df: pd.DataFrame) -> go.Figure:
    """Treemap of spending by category."""
    expense_df = df[df["debit"] > 0]
    if expense_df.empty:
        return chart_empty("No expense transactions recorded.")

    cat_totals = expense_df.groupby("category")["debit"].sum().reset_index()
    cat_totals = cat_totals.sort_values(by="debit", ascending=False)
    
    fig = px.treemap(
        cat_totals,
        path=["category"],
        values="debit",
        color="category",
        color_discrete_map=CATEGORY_COLORS
    )
    fig.update_traces(
        hovertemplate="<b>%{label}</b><br>Amount: ₹%{value:,.2f}<extra></extra>",
        textinfo="label+value+percent entry"
    )
    fig.update_layout(height=320)
    return apply_theme(fig, "Spending Treemap", "Hierarchical footprint of category expenditures")


def chart_balance_timeline(df: pd.DataFrame, issues: Optional[List[Dict[str, Any]]] = None) -> go.Figure:
    """Running balance timeline with annotated extremes and mismatch flags."""
    bal_df = df[df["balance"].notna()].copy()
    if bal_df.empty:
        return chart_empty("No running balance data available.")

    bal_df = bal_df.sort_values(by=["date_dt", "transaction_id"]).reset_index(drop=True)
    x_axis = bal_df["date_dt"] if "date_dt" in bal_df.columns and bal_df["date_dt"].notna().any() else bal_df.index

    fig = go.Figure()

    # Balance area
    fig.add_trace(go.Scatter(
        x=x_axis,
        y=bal_df["balance"],
        name="Running Balance",
        mode="lines",
        line=dict(color=PRIMARY, width=2.5),
        fill="tozeroy",
        fillcolor="rgba(79, 70, 229, 0.06)",
        hovertemplate="<b>Balance</b>: ₹%{y:,.2f}<extra></extra>"
    ))

    # Highlight min and max points
    min_idx = bal_df["balance"].idxmin()
    max_idx = bal_df["balance"].idxmax()
    
    fig.add_trace(go.Scatter(
        x=[x_axis[min_idx]],
        y=[bal_df.loc[min_idx, "balance"]],
        mode="markers",
        marker=dict(color=DANGER_RED, size=9, symbol="diamond"),
        name="Low Balance Point",
        hovertemplate=f"Lowest: ₹{bal_df.loc[min_idx, 'balance']:,.2f}<extra></extra>"
    ))
    
    fig.add_trace(go.Scatter(
        x=[x_axis[max_idx]],
        y=[bal_df.loc[max_idx, "balance"]],
        mode="markers",
        marker=dict(color=SUCCESS_GREEN, size=9, symbol="star"),
        name="Peak Balance Point",
        hovertemplate=f"Peak: ₹{bal_df.loc[max_idx, 'balance']:,.2f}<extra></extra>"
    ))

    # Mismatch markers from issues
    if issues:
        mismatch_tids = {i.get("transaction_id") for i in issues if "MISMATCH" in str(i.get("issue_type", ""))}
        mismatch_rows = bal_df[bal_df["transaction_id"].isin(mismatch_tids)]
        if not mismatch_rows.empty:
            m_x = mismatch_rows["date_dt"] if "date_dt" in bal_df.columns and bal_df["date_dt"].notna().any() else mismatch_rows.index
            fig.add_trace(go.Scatter(
                x=m_x,
                y=mismatch_rows["balance"],
                mode="markers",
                marker=dict(color=DANGER_RED, size=10, symbol="x"),
                name="Reconciliation Anomaly",
                hovertemplate="<b>Reconciliation Mismatch</b>: ₹%{y:,.2f}<extra></extra>"
            ))

    fig.update_layout(height=320)
    return apply_theme(fig, "Mathematical Balance Timeline", "Continuous ledger continuity with annotated low and peak points")


def chart_classification_breakdown(df: pd.DataFrame) -> go.Figure:
    """Sunburst chart showing decision routing: Rule Engine vs Machine Learning -> Category."""
    if df.empty:
        return chart_empty("No classification records available.")

    breakdown = df.groupby(["classification_method", "category"]).size().reset_index(name="count")
    
    # Map friendly method names
    method_names = {
        "RULE_BASED": "Deterministic Rules",
        "MACHINE_LEARNING": "TF-IDF Logistic Regression",
        "MANUAL": "Auditor Corrected",
        "UNCLASSIFIED": "Unclassified"
    }
    breakdown["method_label"] = breakdown["classification_method"].map(lambda m: method_names.get(m, m))

    fig = px.sunburst(
        breakdown,
        path=["method_label", "category"],
        values="count",
        color="category",
        color_discrete_map=CATEGORY_COLORS
    )
    fig.update_traces(
        hovertemplate="<b>%{label}</b><br>Transactions: %{value}<br>Share of parent: %{percentParent:.1%}<extra></extra>"
    )
    fig.update_layout(height=320)
    return apply_theme(fig, "Classification Engine Routing", "Two-tier deterministic hierarchy: verified keyword rules vs. n-gram model")


def chart_confidence_distribution(df: pd.DataFrame) -> go.Figure:
    """Histogram of ML classifier confidence scores with decision threshold lines."""
    ml_rows = df[df["classification_method"] == "MACHINE_LEARNING"].copy()
    if ml_rows.empty or ml_rows["ml_confidence"].dropna().empty:
        return chart_empty("All transactions in current scope matched by deterministic rules (0 ML predictions).")

    conf_scores = ml_rows["ml_confidence"].dropna()
    # Normalize to 0-100%
    scores = conf_scores * 100.0 if conf_scores.max() <= 1.0 else conf_scores

    fig = go.Figure()
    fig.add_trace(go.Histogram(
        x=scores,
        nbinsx=20,
        marker=dict(color=PRIMARY, line=dict(color="#FFFFFF", width=1)),
        hovertemplate="<b>Confidence</b>: %{x:.0f}%<br>Count: %{y}<extra></extra>"
    ))

    # Add threshold vertical lines
    fig.add_vline(x=85, line_dash="dash", line_color=SUCCESS_GREEN, annotation_text="Auto-Accept (≥85%)", annotation_position="top left")
    fig.add_vline(x=60, line_dash="dash", line_color=WARNING_AMBER, annotation_text="Review Threshold (<60%)", annotation_position="top left")

    fig.update_layout(
        height=320,
        xaxis_title="Prediction Confidence Score (%)",
        yaxis_title="Transaction Count"
    )
    return apply_theme(fig, "ML Model Confidence Distribution", "Triage threshold: >=85% accepted, <60% flagged for manual review")


def chart_top_merchants(df: pd.DataFrame, top_n: int = 8) -> go.Figure:
    """Horizontal bar chart of top spending merchants."""
    expense_df = df[df["debit"] > 0].copy()
    if expense_df.empty:
        return chart_empty("No outflow merchant data.")

    # Clean merchant strings
    def clean_m(d):
        s = re.sub(r'^(UPI|NEFT|RTGS|IMPS|POS|CARD PAYMENT|ACH)[\-\s:]*', '', d, flags=re.I).strip()
        s = re.sub(r'REF[\s\d]+.*$', '', s, flags=re.I).strip()
        return s[:28] if s else d[:28]

    expense_df["clean_merchant"] = expense_df["description"].apply(clean_m)
    m_totals = expense_df.groupby("clean_merchant").agg(
        Total=("debit", "sum"),
        Count=("debit", "count")
    ).reset_index().sort_values(by="Total", ascending=True).tail(top_n)

    fig = go.Figure()
    fig.add_trace(go.Bar(
        x=m_totals["Total"],
        y=m_totals["clean_merchant"],
        orientation="h",
        marker=dict(color=PRIMARY, cornerradius=4),
        hovertemplate="<b>%{y}</b><br>Total Outflow: ₹%{x:,.2f}<extra></extra>"
    ))

    fig.update_layout(
        height=320,
        xaxis_title="Total Outflow (₹)",
        yaxis_title=None
    )
    return apply_theme(fig, "Top Outflow Merchants & Counterparties", f"Largest aggregate counterparties by outflow amount (Top {top_n})")


def chart_cashflow_sankey(df: pd.DataFrame) -> go.Figure:
    """Sankey diagram tracing Inflows -> Total Cashflow -> Outflows & Savings."""
    credits = df[df["credit"] > 0].copy()
    debits = df[df["debit"] > 0].copy()

    if credits.empty and debits.empty:
        return chart_empty("Insufficient flow data for Sankey generation.")

    # Filter out self transfers for clean picture
    debits_clean = debits[debits["category"] != "Transfers"]
    
    inflow_by_cat = credits.groupby("category")["credit"].sum().reset_index()
    outflow_by_cat = debits_clean.groupby("category")["debit"].sum().reset_index()

    total_in = inflow_by_cat["credit"].sum()
    total_out = outflow_by_cat["debit"].sum()

    if total_in <= 0 or total_out <= 0:
        return chart_empty("Sankey diagram requires both inflows and outflows.")

    # Nodes:
    # 0..N-1: Inflow categories
    # N: Total Inflow Central Node
    # N+1..N+M: Outflow categories
    # Optional N+M+1: Net Savings if positive
    in_cats = inflow_by_cat["category"].tolist()
    out_cats = outflow_by_cat["category"].tolist()

    central_node_idx = len(in_cats)
    nodes = in_cats + ["Total Cash Inflows"] + out_cats
    
    has_savings = total_in > total_out
    if has_savings:
        nodes.append("Net Surplus / Savings")

    sources = []
    targets = []
    values = []

    # Links: Inflow cats -> Central Node
    for i, row in inflow_by_cat.iterrows():
        if row["credit"] > 0:
            sources.append(i)
            targets.append(central_node_idx)
            values.append(float(row["credit"]))

    # Links: Central Node -> Outflow cats
    for j, row in outflow_by_cat.iterrows():
        if row["debit"] > 0:
            sources.append(central_node_idx)
            targets.append(central_node_idx + 1 + j)
            values.append(float(row["debit"]))

    if has_savings:
        sources.append(central_node_idx)
        targets.append(len(nodes) - 1)
        values.append(float(total_in - total_out))

    node_colors = []
    for node in nodes:
        if node == "Total Cash Inflows":
            node_colors.append(PRIMARY)
        elif node == "Net Surplus / Savings":
            node_colors.append(SUCCESS_GREEN)
        else:
            node_colors.append(CATEGORY_COLORS.get(node, "#64748B"))

    fig = go.Figure(data=[go.Sankey(
        node=dict(
            pad=15,
            thickness=18,
            line=dict(color="#CBD5E1", width=0.5),
            label=nodes,
            color=node_colors
        ),
        link=dict(
            source=sources,
            target=targets,
            value=values,
            color="rgba(203, 213, 225, 0.45)"
        )
    )])

    fig.update_layout(height=360)
    return apply_theme(fig, "Cash Flow Sankey Diagram", "Complete journey of capital: source inflows → operational total → category destinations")


def chart_waterfall_cashflow(df: pd.DataFrame, opening_balance: float = 0.0) -> go.Figure:
    """Waterfall chart mapping opening balance to closing balance through inflows and category outflows."""
    if df.empty:
        return chart_empty("No transaction records available for waterfall analysis.")

    inflow_sum = df["credit"].sum()
    expense_df = df[df["debit"] > 0]
    cat_outflows = expense_df.groupby("category")["debit"].sum().reset_index()
    cat_outflows = cat_outflows.sort_values(by="debit", ascending=False).head(6)

    other_debit = expense_df["debit"].sum() - cat_outflows["debit"].sum()
    if other_debit > 0:
        other_row = pd.DataFrame([{"category": "Other Categories", "debit": other_debit}])
        cat_outflows = pd.concat([cat_outflows, other_row], ignore_index=True)

    measure = ["absolute", "relative"] + ["relative"] * len(cat_outflows) + ["total"]
    x = ["Opening Balance", "Total Inflows"] + cat_outflows["category"].tolist() + ["Closing Balance"]
    y = [opening_balance, inflow_sum] + (-cat_outflows["debit"]).tolist() + [0]

    fig = go.Figure(go.Waterfall(
        name="Cash Movement",
        orientation="v",
        measure=measure,
        x=x,
        textposition="outside",
        text=[fmt_inr(v, compact=True) for v in y],
        y=y,
        connector={"line": {"color": "#CBD5E1"}},
        decreasing={"marker": {"color": DANGER_RED}},
        increasing={"marker": {"color": SUCCESS_GREEN}},
        totals={"marker": {"color": PRIMARY}}
    ))

    fig.update_layout(height=340)
    return apply_theme(fig, "Capital Reconciliation Waterfall", "Cumulative bridge from statement start to closing ledger balance")

