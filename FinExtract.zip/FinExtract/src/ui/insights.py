"""Deterministic statistical insights engine for FinExtract (Strictly Non-LLM)."""
import re
import numpy as np
import pandas as pd
from typing import List, Dict, Any, Optional
from src.ui.formatters import fmt_inr, fmt_pct, clean_html


def generate_insights(df: pd.DataFrame, job_data: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    """
    Generate deterministic rule-based operational insights.
    Returns a list of insight dictionaries:
    {
        "id": str,
        "title": str,
        "finding": str,
        "value": str,
        "icon": str,
        "type": "info" | "warning" | "success",
        "rule_used": str
    }
    """
    if df.empty or len(df) == 0:
        return []

    insights: List[Dict[str, Any]] = []

    # 1. Largest Single Outflow
    debits_df = df[df["debit"] > 0]
    if not debits_df.empty:
        max_row = debits_df.loc[debits_df["debit"].idxmax()]
        clean_desc = re.sub(r'^(UPI|NEFT|RTGS|IMPS|POS|CARD PAYMENT)[\-\s:]*', '', max_row["description"], flags=re.I).strip()
        clean_desc = (clean_desc[:32] + "…") if len(clean_desc) > 32 else clean_desc
        insights.append({
            "id": "largest_expense",
            "title": "Largest Single Outflow",
            "finding": f"{clean_desc} in {max_row['category']}",
            "value": fmt_inr(max_row["debit"]),
            "icon": "💸",
            "type": "info",
            "rule_used": "Max debit value across all scoped records"
        })

    # 2. Savings Rate / Cash Flow Inflow vs Outflow
    total_in = df["credit"].sum()
    total_out = df["debit"].sum()
    if total_in > 0:
        net = total_in - total_out
        rate = net / total_in
        pct_str = fmt_pct(rate)
        if rate >= 0.20:
            finding = f"Healthy cash retention (+{pct_str} retained)"
            t_type = "success"
        elif rate >= 0:
            finding = f"Balanced cash flow (+{pct_str} retained)"
            t_type = "info"
        else:
            finding = f"Net outflow exceeded inflows by {fmt_inr(abs(net))}"
            t_type = "warning"

        insights.append({
            "id": "savings_rate",
            "title": "Net Cash Position",
            "finding": finding,
            "value": f"{rate * 100.0:+.1f}%",
            "icon": "📈" if rate >= 0 else "📉",
            "type": t_type,
            "rule_used": "Inflow vs Outflow ratio: (Total Inflow - Total Outflow) / Total Inflow"
        })

    # 3. Recurring Commitments
    if not debits_df.empty and "date_dt" in df.columns and df["date_dt"].notna().sum() > 3:
        debits_df = debits_df.copy()
        debits_df["month"] = debits_df["date_dt"].dt.to_period("M")
        months_count = debits_df["month"].nunique()

        if months_count >= 2:
            recurring_merchants = []
            for merchant, group in debits_df.groupby("description"):
                m_count = group["month"].nunique()
                if m_count >= 2:
                    amounts = group["debit"].values
                    # Check if amounts are within ±10% variation
                    cv = np.std(amounts) / max(np.mean(amounts), 1.0)
                    if cv <= 0.15:
                        recurring_merchants.append((merchant, np.mean(amounts), m_count))

            if recurring_merchants:
                recurring_merchants.sort(key=lambda x: x[1], reverse=True)
                top_m, top_amt, top_m_count = recurring_merchants[0]
                short_m = (top_m[:28] + "…") if len(top_m) > 28 else top_m
                insights.append({
                    "id": "recurring_detected",
                    "title": "Recurring Payment Pattern",
                    "finding": f"{short_m} recurring across {top_m_count} periods",
                    "value": f"~{fmt_inr(top_amt)}/mo",
                    "icon": "🔁",
                    "type": "info",
                    "rule_used": "Identified by identical merchant description appearing in multiple distinct months with CV <= 0.15"
                })

    # 4. Outlier Anomaly Detection (Statistical IQR)
    if len(debits_df) >= 8:
        debit_vals = debits_df["debit"].values
        q25, q75 = np.percentile(debit_vals, [25, 75])
        iqr = q75 - q25
        high_threshold = q75 + (2.5 * iqr)
        outliers = debits_df[debits_df["debit"] > high_threshold]

        if not outliers.empty:
            outlier_count = len(outliers)
            max_outlier = outliers.loc[outliers["debit"].idxmax()]
            insights.append({
                "id": "statistical_outlier",
                "title": "Statistical Expense Outlier",
                "finding": f"{outlier_count} transaction(s) exceed normal spending distribution (Q3 + 2.5×IQR)",
                "value": f"Peak: {fmt_inr(max_outlier['debit'])}",
                "icon": "🔍",
                "type": "warning",
                "rule_used": f"Tukey's Outlier Filter: debit > ₹{high_threshold:,.2f}"
            })

    # 5. Data Quality & Audit Readiness
    review_needed = (df["review_required"] == True).sum()
    unclassified = (df["category"] == "Unclassified").sum()
    total_tx = len(df)
    
    if review_needed > 0 or unclassified > 0:
        insights.append({
            "id": "audit_review",
            "title": "Audit Review Recommended",
            "finding": f"{review_needed} transaction(s) flagged for manual verification",
            "value": f"{((total_tx - review_needed) / total_tx) * 100:.0f}% verified",
            "icon": "📋",
            "type": "warning" if review_needed > 5 else "info",
            "rule_used": "System verification flags: review_required == True or unclassified"
        })
    else:
        insights.append({
            "id": "audit_passed",
            "title": "Full Verification Confidence",
            "finding": "100% of transactions verified with deterministic rules or high-confidence ML",
            "value": "100% verified",
            "icon": "🛡️",
            "type": "success",
            "rule_used": "Zero review flags and zero unclassified transactions in scoped data"
        })

    return insights

