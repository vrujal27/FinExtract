"""Export Centre & Compliance Reporting Studio for FinExtract."""
import io
import pandas as pd
import streamlit as st
from typing import Optional, List, Dict, Any

from src.ui.formatters import fmt_inr, clean_html
from src.ui.components import page_header, kpi_card, empty_state
from src.ui.state import get_scoped_dataframe, get_active_job
from src.exporters.excel_exporter import export_to_excel
from src.exporters.csv_exporter import export_transactions_csv, export_summary_csv, export_validation_csv


def render_export_centre():
    """Render the structured report generation and spreadsheet export studio."""
    page_header(
        title="Export Centre",
        subtitle="Export reconciled statements into multi-tab audit workbooks and standard CSV formats",
        right_badge="Enterprise Compliance"
    )

    scope = st.session_state.get("selected_scope", "Current statement")
    account_id = st.session_state.get("selected_account_id")
    df, meta = get_scoped_dataframe(scope=scope, account_id=account_id)
    active_job = get_active_job()

    if df.empty:
        empty_state(
            icon="⬇️",
            title="No Statements to Export",
            body="Load a statement to generate Excel workbooks and audit export bundles."
        )
        return

    total_tx = len(df)
    active_filename = active_job.get("filename", "statement.pdf") if active_job else "statement.pdf"
    base_name = active_filename.rsplit(".", 1)[0]

    # Pre-generate Excel Workbook in memory
    excel_bytes = None
    try:
        raw_txns = active_job.get("transactions", []) if active_job else df.to_dict(orient="records")
        acct_info = active_job.get("account_info", {}) if active_job else {}
        val_issues = active_job.get("validation_issues", []) if active_job else []
        reconciliation = active_job.get("reconciliation", {}) if active_job else {}
        
        job_info = {
            "job_id": active_job.get("job_id", "JOB-EXPORT") if active_job else "JOB-EXPORT",
            "filename": active_filename,
            "created_at": active_job.get("created_at") if active_job else None,
            "pdf_type": active_job.get("detection", {}).get("pdf_type", "text") if active_job else "text",
            "page_count": active_job.get("detection", {}).get("total_pages", 1) if active_job else 1,
        }
        excel_bytes = export_to_excel(
            transactions=raw_txns,
            account_info=acct_info,
            validation_issues=val_issues,
            job_info=job_info,
            reconciliation=reconciliation
        )
    except Exception as ex:
        st.warning(f"Excel builder notice: {ex}")

    # Pre-generate CSV exports
    csv_txns = export_transactions_csv(raw_txns)
    csv_summary = export_summary_csv(job_info, acct_info, raw_txns, reconciliation)
    csv_validation = export_validation_csv(val_issues)

    # ─── Export Option Cards ──────────────────────────────────────────────────
    st.markdown("##### 📦 Structured Report Formats")
    e1, e2 = st.columns(2)

    with e1:
        st.markdown(f"""
        <div class="op-card">
            <div style="font-weight: 700; font-size: 1.1rem; color: #1E293B; margin-bottom: 4px;">📊 Comprehensive Multi-Sheet Excel Workbook</div>
            <div style="font-size: 0.85rem; color: #64748B; margin-bottom: 12px;">
                Complete financial package with formatted columns, summary cards, validation report, and raw data across 4 dedicated sheets.
            </div>
            <div style="font-size: 0.775rem; color: #475569; margin-bottom: 16px;">
                Includes: <b>Transactions ({total_tx:,})</b> &bull; <b>Audit Summary</b> &bull; <b>Validation Issues ({len(val_issues)})</b> &bull; <b>Metadata</b>
            </div>
        </div>
        """, unsafe_allow_html=True)

        if excel_bytes:
            st.download_button(
                label=f"⬇️ Download Excel Workbook ({base_name}.xlsx)",
                data=excel_bytes,
                file_name=f"{base_name}_reconciled.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                type="primary",
                use_container_width=True,
                key="dl_excel_btn"
            )

    with e2:
        st.markdown(f"""
        <div class="op-card">
            <div style="font-weight: 700; font-size: 1.1rem; color: #1E293B; margin-bottom: 4px;">📄 Universal Ledger CSV (All Transactions)</div>
            <div style="font-size: 0.85rem; color: #64748B; margin-bottom: 12px;">
                Standard RFC-4180 comma-separated transaction records compatible with ERPs, QuickBooks, Tally, and custom database loaders.
            </div>
            <div style="font-size: 0.775rem; color: #475569; margin-bottom: 16px;">
                Records: <b>{total_tx:,} transactions</b> &bull; <b>ISO-8601 Dates</b> &bull; <b>Decimal Currencies</b>
            </div>
        </div>
        """, unsafe_allow_html=True)

        st.download_button(
            label=f"⬇️ Download Transactions CSV ({base_name}.csv)",
            data=csv_txns,
            file_name=f"{base_name}_transactions.csv",
            mime="text/csv",
            use_container_width=True,
            key="dl_csv_tx_btn"
        )

    st.markdown("<div style='height: 16px;'></div>", unsafe_allow_html=True)

    # Secondary CSV Exports
    st.markdown("##### 📑 Specialized Compliance Export Feeds")
    sc1, sc2 = st.columns(2)
    with sc1:
        st.download_button(
            label="⬇️ Download Account Summary CSV",
            data=csv_summary,
            file_name=f"{base_name}_summary.csv",
            mime="text/csv",
            use_container_width=True,
            key="dl_summary_csv"
        )
    with sc2:
        st.download_button(
            label=f"⬇️ Download Audit & Validation Issues CSV ({len(val_issues)} Issues)",
            data=csv_validation,
            file_name=f"{base_name}_validation_issues.csv",
            mime="text/csv",
            use_container_width=True,
            key="dl_val_csv"
        )

    # ─── Live Previews ────────────────────────────────────────────────────────
    st.markdown("<div style='height: 20px;'></div>", unsafe_allow_html=True)
    st.markdown("##### 👁 Pre-Flight Export Data Preview")
    
    prev_tab1, prev_tab2 = st.tabs(["Ledger Feed Preview", "Validation Ledger Preview"])
    with prev_tab1:
        st.dataframe(df.head(10), use_container_width=True, hide_index=True)
    with prev_tab2:
        if val_issues:
            st.dataframe(pd.DataFrame(val_issues).head(10), use_container_width=True, hide_index=True)
        else:
            st.info("No validation issues present in export payload.")

