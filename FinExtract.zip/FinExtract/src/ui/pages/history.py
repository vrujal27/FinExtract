"""Processing History and Audit Trail page for FinExtract."""
import streamlit as st
import pandas as pd
from typing import Dict, Any, List

from src.ui.formatters import fmt_date, clean_html
from src.ui.components import page_header, status_badge, empty_state
from src.ui.state import init_session_state, get_all_jobs
from src.database.connection import get_db
from src.database.collections import delete_job


@st.dialog("Confirm Statement Deletion")
def _confirm_delete_dialog(job: Dict[str, Any]):
    """Confirmation modal for safe statement purge."""
    job_id = job.get("job_id", "")
    filename = job.get("filename", "Unknown")
    tx_count = job.get("transaction_count", 0)
    
    st.markdown(
        f'<div style="font-size: 0.95rem; color: #1E293B; line-height: 1.5; margin-bottom: 16px;">'
        f'Are you sure you want to permanently delete statement <strong>{clean_html(filename)}</strong> (Job ID: <code>{job_id}</code>)?'
        f'</div>'
        f'<div style="background: #FEF2F2; border-left: 4px solid #EF4444; padding: 12px 14px; border-radius: 6px; font-size: 0.85rem; color: #991B1B; margin-bottom: 20px;">'
        f'<strong>Destructive Action:</strong> This will permanently erase the job manifest, <strong>{tx_count}</strong> ledger transactions, and all associated validation issues from local MongoDB storage. This operation cannot be undone.'
        f'</div>',
        unsafe_allow_html=True
    )
    
    c1, c2 = st.columns([1, 1])
    with c1:
        if st.button("Cancel", use_container_width=True, key=f"cancel_del_{job_id}"):
            st.rerun()
    with c2:
        if st.button("Permanently Delete", type="primary", use_container_width=True, key=f"confirm_del_{job_id}"):
            # Delete from database
            db, db_connected = get_db()
            if db_connected:
                delete_job(job_id)
            
            # Remove from session state if present
            if job_id in st.session_state.processed_jobs:
                del st.session_state.processed_jobs[job_id]
            if st.session_state.active_job_id == job_id:
                st.session_state.active_job_id = None
                
            st.toast(f"Successfully purged {filename}", icon="🗑️")
            st.rerun()


def render_history():
    """Render historical batch processing ledger."""
    init_session_state()
    
    page_header(
        title="Processing History",
        subtitle="Chronological audit trail of all parsed bank statements, execution durations, and raw manifests.",
        right_badge="Database Synchronized"
    )
    
    all_jobs = get_all_jobs()
    
    if not all_jobs:
        empty_state(
            title="No Statements Processed Yet",
            message="No bank statements have been ingested into this workspace. Upload your first statement or select a verified synthetic sample to begin.",
            icon="📁"
        )
        if st.button("Upload Statement Now", type="primary"):
            st.session_state["nav"] = "Upload Statement"
            st.rerun()
        return

    # Summary metric ribbon
    m1, m2, m3, m4 = st.columns(4)
    total_txns = sum(j.get("transaction_count", 0) for j in all_jobs)
    total_pages = sum(j.get("page_count", 1) for j in all_jobs)
    avg_duration = sum(j.get("processing_duration", 0.0) for j in all_jobs) / max(len(all_jobs), 1)
    scanned_count = sum(1 for j in all_jobs if j.get("pdf_type") in ("scanned", "mixed"))
    
    with m1:
        st.metric("Total Documents", len(all_jobs))
    with m2:
        st.metric("Total Transactions", f"{total_txns:,}")
    with m3:
        st.metric("Pages Analyzed", total_pages)
    with m4:
        st.metric("Avg Ingestion Time", f"{avg_duration:.2f}s")
        
    st.markdown("<div style='height: 16px;'></div>", unsafe_allow_html=True)
    
    # Timeline Table Header
    st.markdown("##### 📜 Statement Ingestion Registry")
    
    for idx, job in enumerate(all_jobs):
        if not isinstance(job, dict):
            continue
        job_id = job.get("job_id", f"JOB-{idx}")
        filename = job.get("filename", "Unknown Statement")
        bank_name = job.get("bank_name", "Unknown Bank")
        pdf_type = job.get("pdf_type", "text")
        page_count = job.get("page_count", 1)
        tx_count = job.get("transaction_count", 0)
        duration = job.get("processing_duration", 0.0)
        created_at = fmt_date(job.get("created_at") or job.get("processed_at"))
        raw_warnings = job.get("warnings", [])
        warnings = raw_warnings if isinstance(raw_warnings, list) else []
        is_active = (job_id == st.session_state.active_job_id)
        
        badge_type = "green" if pdf_type == "text" else ("blue" if pdf_type == "scanned" else "amber")
        
        with st.container(border=True):
            st.markdown(
                f'<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">'
                f'<div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">'
                f'<span style="font-size: 1.1rem; font-weight: 700; color: #1E293B;">{clean_html(filename)}</span>'
                f'{status_badge(pdf_type.upper(), badge_type)}'
                f'{status_badge("ACTIVE SCOPE", "indigo") if is_active else ""}'
                f'</div>'
                f'<div style="font-size: 0.8rem; color: #64748B; font-family: monospace;">'
                f'{job_id} &bull; {created_at}'
                f'</div>'
                f'</div>'
                f'<div style="display: flex; gap: 20px; flex-wrap: wrap; font-size: 0.875rem; color: #475569; margin-bottom: 10px;">'
                f'<div>🏛️ <strong>Bank:</strong> {clean_html(bank_name)}</div>'
                f'<div>📄 <strong>Pages:</strong> {page_count}</div>'
                f'<div>📊 <strong>Ledger Rows:</strong> {tx_count:,}</div>'
                f'<div>⚡ <strong>Latency:</strong> {duration:.2f}s</div>'
                f'<div>⚠️ <strong>Warnings:</strong> {len(warnings)}</div>'
                f'</div>',
                unsafe_allow_html=True
            )
            
            # Row Actions and Details
            col_act1, col_act2, col_act3 = st.columns([2, 1, 1])
            with col_act1:
                with st.expander("🔍 View Technical Manifest & Audit Diagnostics", expanded=False):
                    st.json({
                        "job_id": job_id,
                        "account_id": job.get("account_id"),
                        "bank_name": bank_name,
                        "pdf_type": pdf_type,
                        "page_count": page_count,
                        "transaction_count": tx_count,
                        "processing_duration": duration,
                        "warnings": warnings,
                        "methods": job.get("extraction_methods", ["PyMuPDF", "Regex Parser", "Heuristic Rules"])
                    })
            with col_act2:
                if not is_active:
                    if st.button("Set as Active", key=f"set_act_{job_id}", use_container_width=True):
                        st.session_state.active_job_id = job_id
                        st.toast(f"Switched active statement to {filename}", icon="🎯")
                        st.rerun()
                else:
                    st.button("Currently Active", key=f"act_btn_{job_id}", disabled=True, use_container_width=True)
            with col_act3:
                if st.button("🗑️ Delete Statement", key=f"btn_del_{job_id}", use_container_width=True):
                    _confirm_delete_dialog(job)
            
            st.markdown("<hr style='margin: 12px 0 16px 0; border: none; border-top: 1px dashed #E2E8F0;'>", unsafe_allow_html=True)
