"""Operations Console Executive Dashboard for FinExtract."""
import streamlit as st
import pandas as pd
from typing import Optional

from src.ui.theme import PRIMARY, SUCCESS_GREEN, DANGER_RED, WARNING_AMBER
from src.ui.formatters import fmt_inr, fmt_pct, clean_html
from src.ui.components import page_header, kpi_card, status_badge, empty_state
from src.ui.state import get_scoped_dataframe, get_active_job, get_all_jobs
from src.ui.insights import generate_insights
from src.ui.charts import (
    chart_income_expenses_monthly, chart_category_donut, chart_category_treemap,
    chart_balance_timeline, chart_classification_breakdown, chart_confidence_distribution,
    chart_top_merchants, chart_cashflow_sankey, chart_waterfall_cashflow
)


def render_dashboard():
    """Render the main executive operations dashboard."""
    page_header(
        title="Operations Dashboard",
        subtitle="Real-time financial telemetry, statement reconciliation, and classification analytics",
        right_badge="Deterministic Architecture"
    )

    scope = st.session_state.get("selected_scope", "Current statement")
    account_id = st.session_state.get("selected_account_id")
    df, meta = get_scoped_dataframe(scope=scope, account_id=account_id)
    active_job = get_active_job()

    if df.empty:
        empty_state(
            icon="📂",
            title="No Bank Statements Loaded Yet",
            body="Upload a digital or scanned bank statement PDF or choose one of our verified synthetic test statements to launch telemetry.",
            action_label="Upload Statement"
        )
        return

    # Calculate High-Level Operational Metrics
    total_txns = len(df)
    total_income = df["credit"].sum()
    total_expenses = df["debit"].sum()
    net_flow = total_income - total_expenses

    review_needed = int((df["review_required"] == True).sum())
    unclassified_count = int((df["category"] == "Unclassified").sum())
    rule_matched = int((df["classification_method"] == "RULE_BASED").sum())
    auto_matched_pct = ((total_txns - review_needed) / max(total_txns, 1)) * 100.0

    # Reconciliation Pass Rate
    recon_status = "PASSED"
    recon_matched = total_txns
    recon_total = total_txns
    if active_job and isinstance(active_job.get("reconciliation"), dict):
        rec = active_job["reconciliation"]
        recon_status = rec.get("status", "INCONCLUSIVE")
        recon_matched = rec.get("matched", 0)
        recon_total = rec.get("total_checked", total_txns)
        recon_rate_pct = (recon_matched / max(recon_total, 1)) * 100.0 if recon_total > 0 else 100.0
    else:
        recon_rate_pct = 100.0

    # ─── Executive KPI Strip ──────────────────────────────────────────────────
    k1, k2, k3, k4 = st.columns(4)
    with k1:
        kpi_card(
            label="Total Extracted Volume",
            value=f"{total_txns:,}",
            delta=f"{meta.get('bank_name', 'Bank Statement')}",
            delta_type="neutral",
            icon="📄",
            help_text="Transactions loaded"
        )
    with k2:
        kpi_card(
            label="Total Inflows (Credits)",
            value=fmt_inr(total_income, compact=True),
            delta=f"+{fmt_inr(total_income, compact=False)}",
            delta_type="good",
            icon="📥",
            help_text="Aggregate statement deposits"
        )
    with k3:
        kpi_card(
            label="Total Outflows (Debits)",
            value=fmt_inr(total_expenses, compact=True),
            delta=f"-{fmt_inr(total_expenses, compact=False)}",
            delta_type="bad",
            icon="📤",
            help_text="Aggregate statement withdrawals"
        )
    with k4:
        net_delta_type = "good" if net_flow >= 0 else "bad"
        kpi_card(
            label="Net Capital Position",
            value=fmt_inr(net_flow, compact=True),
            delta=f"{'+' if net_flow >= 0 else ''}{fmt_inr(net_flow, compact=False)}",
            delta_type=net_delta_type,
            icon="⚖️",
            help_text="Inflows minus outflows"
        )

    st.markdown("<div style='height: 10px;'></div>", unsafe_allow_html=True)

    k5, k6, k7, k8 = st.columns(4)
    with k5:
        recon_delta = "good" if recon_status == "PASSED" else "bad" if recon_status == "FAILED" else "neutral"
        kpi_card(
            label="Ledger Continuity",
            value=f"{recon_rate_pct:.1f}%",
            delta=f"{recon_matched}/{recon_total} Matched",
            delta_type=recon_delta,
            icon="✓",
            help_text="Continuous balance reconciliation"
        )
    with k6:
        review_delta = "good" if review_needed == 0 else "bad" if review_needed > 10 else "neutral"
        kpi_card(
            label="Audit Review Queue",
            value=str(review_needed),
            delta=f"{unclassified_count} Unclassified",
            delta_type=review_delta,
            icon="🔍",
            help_text="Records requiring manual triage"
        )
    with k7:
        kpi_card(
            label="Auto-Match Confidence",
            value=f"{auto_matched_pct:.1f}%",
            delta=f"{rule_matched} by deterministic rule",
            delta_type="good",
            icon="⚡",
            help_text="Autonomous categorization"
        )
    with k8:
        all_jobs = get_all_jobs()
        kpi_card(
            label="Statements Processed",
            value=str(len(all_jobs)),
            delta="100% Local Processing",
            delta_type="neutral",
            icon="📁",
            help_text="Active statement sessions"
        )

    # ─── Statistical Insights Bar ─────────────────────────────────────────────
    insights = generate_insights(df, active_job)
    if insights:
        st.markdown("<div style='height: 12px;'></div>", unsafe_allow_html=True)
        st.markdown("##### 📌 Operational Telemetry Insights")
        icols = st.columns(min(len(insights), 3))
        for idx, item in enumerate(insights[:3]):
            with icols[idx]:
                st.markdown(f"""
                <div class="op-insight-card">
                    <div class="op-insight-icon">{item['icon']}</div>
                    <div>
                        <div class="op-insight-title">{clean_html(item['title'])} &bull; <span style="color:{PRIMARY};">{clean_html(item['value'])}</span></div>
                        <div class="op-insight-desc">{clean_html(item['finding'])}</div>
                    </div>
                </div>
                """, unsafe_allow_html=True)
        st.caption("<span style='font-size:0.75rem; color:#94A3B8;'>* Insights are generated strictly via deterministic statistical rules, not external AI models.</span>", unsafe_allow_html=True)

    # ─── Chart Tabs ───────────────────────────────────────────────────────────
    st.markdown("<div style='height: 16px;'></div>", unsafe_allow_html=True)
    tab_cashflow, tab_categories, tab_ledger, tab_engine = st.tabs([
        "📊 Cash Flow Dynamics",
        "🏷️ Category Footprint",
        "📈 Ledger Continuity",
        "🤖 Engine Diagnostics"
    ])

    with tab_cashflow:
        c1, c2 = st.columns([1, 1])
        with c1:
            st.plotly_chart(
                chart_income_expenses_monthly(df),
                use_container_width=True,
                key="dash_monthly_cf"
            )
        with c2:
            st.plotly_chart(
                chart_cashflow_sankey(df),
                use_container_width=True,
                key="dash_sankey"
            )

    with tab_categories:
        col_view, col_merchants = st.columns([1, 1])
        with col_view:
            chart_type = st.radio("Display Format:", ["Donut Chart", "Treemap View"], horizontal=True, key="cat_chart_type")
            if chart_type == "Donut Chart":
                st.plotly_chart(
                    chart_category_donut(df),
                    use_container_width=True,
                    key="dash_cat_donut"
                )
            else:
                st.plotly_chart(
                    chart_category_treemap(df),
                    use_container_width=True,
                    key="dash_cat_tree"
                )
        with col_merchants:
            st.plotly_chart(
                chart_top_merchants(df, top_n=8),
                use_container_width=True,
                key="dash_top_merchants"
            )

    with tab_ledger:
        issues = active_job.get("validation_issues", []) if active_job else []
        st.plotly_chart(
            chart_balance_timeline(df, issues=issues),
            use_container_width=True,
            key="dash_bal_timeline"
        )
        op_bal = active_job.get("account_info", {}).get("opening_balance", 0.0) if active_job else 0.0
        st.plotly_chart(
            chart_waterfall_cashflow(df, opening_balance=float(op_bal or 0.0)),
            use_container_width=True,
            key="dash_waterfall"
        )

    with tab_engine:
        e1, e2 = st.columns([1, 1])
        with e1:
            st.plotly_chart(
                chart_classification_breakdown(df),
                use_container_width=True,
                key="dash_engine_breakdown"
            )
        with e2:
            st.plotly_chart(
                chart_confidence_distribution(df),
                use_container_width=True,
                key="dash_conf_dist"
            )

