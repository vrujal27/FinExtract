"""Transaction Ledger & Audit Studio for FinExtract."""
import re
import pandas as pd
import streamlit as st
from typing import Optional, List, Dict, Any

from src.config import CATEGORIES
from src.ui.formatters import fmt_inr, clean_html, fmt_date, fmt_pct
from src.ui.components import page_header, status_badge, method_badge, category_chip, empty_state
from src.ui.state import get_scoped_dataframe, get_active_job


def render_transactions():
    """Render the high-density financial ledger and transaction editor."""
    page_header(
        title="Transactions Ledger",
        subtitle="Search, filter, inspect mathematical reconciliation math, and adjust category classifications",
        right_badge="Interactive Audit"
    )

    scope = st.session_state.get("selected_scope", "Current statement")
    account_id = st.session_state.get("selected_account_id")
    df, meta = get_scoped_dataframe(scope=scope, account_id=account_id)

    if df.empty:
        empty_state(
            icon="💳",
            title="No Transactions to Display",
            body="Load a statement from the Upload Statement screen to explore and inspect ledger records."
        )
        return

    # ─── Filter Toolbar ───────────────────────────────────────────────────────
    fcol1, fcol2, fcol3 = st.columns([3, 2, 2])
    with fcol1:
        search_query = st.text_input("🔍 Search description, reference, or amount:", key="tx_search", placeholder="e.g. Swiggy, Salary, 1000...")
    with fcol2:
        category_filter = st.selectbox("Filter Category:", ["All Categories"] + sorted(list(df["category"].unique())), key="tx_cat_filter")
    with fcol3:
        method_filter = st.selectbox("Classification Tier:", ["All Methods", "Deterministic Rules", "Machine Learning", "Needs Review"], key="tx_method_filter")

    # Filter dataframe
    filtered_df = df.copy()
    if search_query:
        q = search_query.lower()
        filtered_df = filtered_df[
            filtered_df["description"].str.lower().str.contains(q) |
            filtered_df["reference"].str.lower().str.contains(q) |
            filtered_df["debit"].astype(str).str.contains(q) |
            filtered_df["credit"].astype(str).str.contains(q)
        ]

    if category_filter != "All Categories":
        filtered_df = filtered_df[filtered_df["category"] == category_filter]

    if method_filter == "Deterministic Rules":
        filtered_df = filtered_df[filtered_df["classification_method"] == "RULE_BASED"]
    elif method_filter == "Machine Learning":
        filtered_df = filtered_df[filtered_df["classification_method"] == "MACHINE_LEARNING"]
    elif method_filter == "Needs Review":
        filtered_df = filtered_df[filtered_df["review_required"] == True]

    # ─── Filter Summary Bar ───────────────────────────────────────────────────
    filt_count = len(filtered_df)
    filt_debit = filtered_df["debit"].sum()
    filt_credit = filtered_df["credit"].sum()
    filt_net = filt_credit - filt_debit

    st.markdown(f"""
    <div style="background-color: #FFFFFF; border: 1px solid #E2E8F0; border-radius: 10px; padding: 10px 16px; margin: 10px 0 16px 0; display: flex; justify-content: space-between; align-items: center; font-size: 0.85rem;">
        <div>Showing <b>{filt_count:,}</b> of {len(df):,} transactions</div>
        <div style="display: flex; gap: 20px;">
            <div>Inflows: <b style="color: #059669;">+{fmt_inr(filt_credit)}</b></div>
            <div>Outflows: <b style="color: #DC2626;">-{fmt_inr(filt_debit)}</b></div>
            <div>Net: <b>{fmt_inr(filt_net)}</b></div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # ─── Display Columns Prep ─────────────────────────────────────────────────
    display_df = filtered_df[[
        "transaction_id", "transaction_date", "description",
        "debit", "credit", "balance", "category",
        "classification_method", "ml_confidence", "review_required"
    ]].copy()

    # Column configuration
    col_config = {
        "transaction_id": st.column_config.TextColumn("ID", width="small"),
        "transaction_date": st.column_config.TextColumn("Date", width="small"),
        "description": st.column_config.TextColumn("Description / Narration", width="large"),
        "debit": st.column_config.NumberColumn("Withdrawal (₹)", format="₹%.2f"),
        "credit": st.column_config.NumberColumn("Deposit (₹)", format="₹%.2f"),
        "balance": st.column_config.NumberColumn("Running Balance (₹)", format="₹%.2f"),
        "category": st.column_config.TextColumn("Category", width="medium"),
        "classification_method": st.column_config.TextColumn("Tier", width="small"),
        "ml_confidence": st.column_config.ProgressColumn("Confidence", min_value=0.0, max_value=1.0, format="%.2f"),
        "review_required": st.column_config.CheckboxColumn("Needs Review", width="small"),
    }

    selection = st.dataframe(
        display_df,
        column_config=col_config,
        use_container_width=True,
        hide_index=True,
        on_select="rerun",
        selection_mode="single-row",
        key="tx_ledger_table"
    )

    # Fallback selectbox for transaction detail inspection
    st.markdown("<div style='height: 12px;'></div>", unsafe_allow_html=True)
    all_tids = filtered_df["transaction_id"].tolist()
    
    selected_tid = None
    if selection and selection.get("selection", {}).get("rows"):
        selected_idx = selection["selection"]["rows"][0]
        if selected_idx < len(display_df):
            selected_tid = display_df.iloc[selected_idx]["transaction_id"]

    sel_col1, sel_col2 = st.columns([3, 1])
    with sel_col1:
        chosen_tid = st.selectbox(
            "Select transaction to inspect details, explanation, or override category:",
            options=["None"] + all_tids,
            index=(all_tids.index(selected_tid) + 1) if selected_tid in all_tids else 0,
            key="tx_selector_box"
        )
    with sel_col2:
        st.write("")
        st.write("")
        open_btn = st.button("🔍 Open Audit Dossier", use_container_width=True, key="btn_open_dossier")

    target_tid = chosen_tid if chosen_tid != "None" else selected_tid
    if (open_btn or chosen_tid != "None") and target_tid and target_tid != "None":
        row_matches = df[df["transaction_id"] == target_tid]
        if not row_matches.empty:
            tx_row = row_matches.iloc[0].to_dict()
            _render_detail_modal(tx_row)


@st.dialog("Transaction Audit Dossier")
def _render_detail_modal(tx: Dict[str, Any]):
    """Modal dialog displaying deep explainability, reconciliation math, and category overrides."""
    tid = tx.get("transaction_id", "")
    desc = tx.get("description", "")
    raw_desc = tx.get("raw_description", desc)
    category = tx.get("category", "Unclassified")
    method = tx.get("classification_method", "UNKNOWN")
    debit = tx.get("debit", 0.0)
    credit = tx.get("credit", 0.0)
    balance = tx.get("balance")
    source_page = tx.get("source_page", 1)
    extraction_method = tx.get("extraction_method", "text")
    rule_id = tx.get("rule_id", "")
    confidence = tx.get("ml_confidence")

    st.markdown(f"### `{clean_html(tid)}`")
    st.markdown(f"**Narration:** {clean_html(desc)}")
    if raw_desc != desc:
        st.caption(f"Raw Extracted Text: `{clean_html(raw_desc)}`")

    st.markdown("---")

    # Financial Details
    c1, c2, c3 = st.columns(3)
    with c1:
        st.metric("Debit (Outflow)", fmt_inr(debit) if debit > 0 else "—")
    with c2:
        st.metric("Credit (Inflow)", fmt_inr(credit) if credit > 0 else "—")
    with c3:
        st.metric("Running Balance", fmt_inr(balance) if balance is not None else "—")

    # Classification Explainability Box
    st.markdown("#### 🧠 Classification Engine Reasoning")
    if method == "RULE_BASED":
        st.success(f"**Deterministic Rule Match**: Matched verified rule `{clean_html(rule_id)}` with priority enforcement.")
    elif method == "MACHINE_LEARNING":
        conf_str = fmt_pct(confidence) if confidence is not None else "—"
        st.info(f"**Statistical ML Model**: Classified via character-ngram TF-IDF vectorization with Logistic Regression (Confidence: {conf_str}).")
    elif method == "MANUAL":
        st.warning("**Auditor Override**: Manually corrected by user.")
    else:
        st.warning("**Unclassified**: No deterministic rule matched and ML confidence was below threshold.")

    # Mathematical Ledger Check
    st.markdown("#### ⚖️ Mathematical Ledger Continuity")
    if balance is not None:
        st.markdown(f"""
        <div style="background-color: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 8px; padding: 10px 14px; font-size: 0.85rem;">
            Extracted Ledger Balance: <b>{fmt_inr(balance)}</b><br>
            Source Page: <b>Page {source_page}</b> ({extraction_method.upper()} stream)
        </div>
        """, unsafe_allow_html=True)
    else:
        st.info("No balance continuity check applicable for this line item.")

    # Category Override Form
    st.markdown("#### ✏️ Override Classification")
    new_cat = st.selectbox(
        "Assign Correct Category:",
        CATEGORIES,
        index=CATEGORIES.index(category) if category in CATEGORIES else 0,
        key=f"edit_cat_{tid}"
    )

    if st.button("Save Verified Category", type="primary", use_container_width=True, key=f"save_cat_{tid}"):
        active_job = get_active_job()
        if active_job:
            for t in active_job.get("transactions", []):
                if t.get("transaction_id") == tid:
                    t["category"] = new_cat
                    t["classification_method"] = "MANUAL"
                    t["review_required"] = False
                    break
        
        # Persist to database if connected
        try:
            from src.database.collections import update_transaction_category
            update_transaction_category(tid, new_cat, reason="Auditor override via Operations Console")
        except Exception:
            pass

        st.toast(f"Updated {tid} to {new_cat} ✓")
        st.rerun()

