"""Deep Financial Analytics and Spending Insights for FinExtract."""
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from typing import Optional, List, Dict, Any

from src.ui.formatters import fmt_inr, clean_html, fmt_pct
from src.ui.components import page_header, kpi_card, empty_state
from src.ui.state import get_scoped_dataframe, get_active_job, get_all_accounts
from src.ui.charts import (
    apply_theme, chart_income_expenses_monthly, chart_category_donut,
    chart_category_treemap, chart_top_merchants, chart_waterfall_cashflow
)


def render_analytics():
    """Render advanced financial intelligence and temporal pattern analytics."""
    page_header(
        title="Financial Analytics & Intelligence",
        subtitle="Multi-dimensional spending analytics, counterparty aggregation, and temporal cashflow patterns",
        right_badge="Quantitative Analytics"
    )

    scope = st.session_state.get("selected_scope", "Current statement")
    account_id = st.session_state.get("selected_account_id")
    df, meta = get_scoped_dataframe(scope=scope, account_id=account_id)
    active_job = get_active_job()

    if df.empty:
        empty_state(
            icon="📊",
            title="No Data for Analytics",
            body="Load a bank statement to unlock spending breakdowns, counterparty aggregation, and trends."
        )
        return

    # Categorized Analytics Tabs
    tab_inc, tab_exp, tab_cats, tab_merch, tab_time, tab_accts = st.tabs([
        "📥 Inflow Trends",
        "📤 Outflow Trends",
        "🏷️ Category Breakdown",
        "🏪 Counterparty Intelligence",
        "📅 Temporal Patterns",
        "🏦 Account Portfolio"
    ])

    # ─── Tab 1: Inflow Trends ─────────────────────────────────────────────────
    with tab_inc:
        credits_df = df[df["credit"] > 0].copy()
        if credits_df.empty:
            st.info("No inflow (credit) transactions found in this statement.")
        else:
            tot_in = credits_df["credit"].sum()
            avg_in = credits_df["credit"].mean()
            max_in = credits_df["credit"].max()

            i1, i2, i3 = st.columns(3)
            with i1:
                kpi_card("Total Inflow Volume", fmt_inr(tot_in), f"{len(credits_df)} deposits", "good", "📥")
            with i2:
                kpi_card("Average Deposit Size", fmt_inr(avg_in), "Mean credit", "neutral", "📊")
            with i3:
                kpi_card("Largest Single Credit", fmt_inr(max_in), "Peak inflow", "good", "⭐")

            st.markdown("<div style='height: 12px;'></div>", unsafe_allow_html=True)
            # Largest Inflows Table
            st.markdown("###### Top 10 Inflow Transactions")
            top_inflows = credits_df.sort_values(by="credit", ascending=False).head(10)[[
                "transaction_date", "description", "credit", "category", "reference"
            ]]
            st.dataframe(
                top_inflows,
                use_container_width=True,
                hide_index=True,
                column_config={
                    "transaction_date": st.column_config.TextColumn("Date"),
                    "description": st.column_config.TextColumn("Description"),
                    "credit": st.column_config.NumberColumn("Deposit (₹)", format="₹%.2f"),
                    "category": st.column_config.TextColumn("Category"),
                    "reference": st.column_config.TextColumn("Reference / UTR")
                }
            )

    # ─── Tab 2: Outflow Trends ────────────────────────────────────────────────
    with tab_exp:
        debits_df = df[df["debit"] > 0].copy()
        if debits_df.empty:
            st.info("No outflow (debit) transactions found in this statement.")
        else:
            tot_out = debits_df["debit"].sum()
            avg_out = debits_df["debit"].mean()
            max_out = debits_df["debit"].max()

            o1, o2, o3 = st.columns(3)
            with o1:
                kpi_card("Total Outflow Volume", fmt_inr(tot_out), f"{len(debits_df)} withdrawals", "bad", "📤")
            with o2:
                kpi_card("Average Outflow Size", fmt_inr(avg_out), "Mean debit", "neutral", "📊")
            with o3:
                kpi_card("Largest Single Debit", fmt_inr(max_out), "Peak outflow", "bad", "💸")

            st.markdown("<div style='height: 12px;'></div>", unsafe_allow_html=True)
            # Largest Outflows Table
            st.markdown("###### Top 10 Outflow Transactions")
            top_outflows = debits_df.sort_values(by="debit", ascending=False).head(10)[[
                "transaction_date", "description", "debit", "category", "reference"
            ]]
            st.dataframe(
                top_outflows,
                use_container_width=True,
                hide_index=True,
                column_config={
                    "transaction_date": st.column_config.TextColumn("Date"),
                    "description": st.column_config.TextColumn("Description"),
                    "debit": st.column_config.NumberColumn("Withdrawal (₹)", format="₹%.2f"),
                    "category": st.column_config.TextColumn("Category"),
                    "reference": st.column_config.TextColumn("Reference / UTR")
                }
            )

    # ─── Tab 3: Category Breakdown ────────────────────────────────────────────
    with tab_cats:
        c1, c2 = st.columns([1, 1])
        with c1:
            st.plotly_chart(chart_category_donut(df), use_container_width=True, key="an_cat_donut")
        with c2:
            st.plotly_chart(chart_category_treemap(df), use_container_width=True, key="an_cat_tree")

        # Category Summary Table
        cat_agg = df[df["debit"] > 0].groupby("category").agg(
            Total=("debit", "sum"),
            Count=("debit", "count"),
            Average=("debit", "mean")
        ).reset_index().sort_values(by="Total", ascending=False)
        total_exp = cat_agg["Total"].sum()
        cat_agg["Share (%)"] = (cat_agg["Total"] / max(total_exp, 1.0)) * 100.0

        st.markdown("###### Complete Category Aggregation")
        st.dataframe(
            cat_agg,
            use_container_width=True,
            hide_index=True,
            column_config={
                "category": st.column_config.TextColumn("Category"),
                "Total": st.column_config.NumberColumn("Total Expenditure (₹)", format="₹%.2f"),
                "Count": st.column_config.NumberColumn("Transaction Count"),
                "Average": st.column_config.NumberColumn("Average Size (₹)", format="₹%.2f"),
                "Share (%)": st.column_config.ProgressColumn("Share of Outflow", min_value=0.0, max_value=100.0, format="%.1f%%")
            }
        )

    # ─── Tab 4: Counterparty Intelligence ─────────────────────────────────────
    with tab_merch:
        st.plotly_chart(chart_top_merchants(df, top_n=10), use_container_width=True, key="an_merch_bars")

    # ─── Tab 5: Temporal Patterns ─────────────────────────────────────────────
    with tab_time:
        if "date_dt" in df.columns and df["date_dt"].notna().sum() > 0:
            dated_df = df.dropna(subset=["date_dt"]).copy()
            dated_df["DayOfWeek"] = dated_df["date_dt"].dt.day_name()
            dated_df["DayOfMonth"] = dated_df["date_dt"].dt.day

            # Day of Week Aggregation
            days_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
            dow_agg = dated_df.groupby("DayOfWeek")["debit"].sum().reindex(days_order).reset_index()

            dow_fig = px.bar(
                dow_agg,
                x="DayOfWeek",
                y="debit",
                color_discrete_sequence=["#4F46E5"]
            )
            dow_fig.update_layout(
                xaxis_title="Day of Week",
                yaxis_title="Total Outflow (₹)",
                height=320
            )
            st.plotly_chart(apply_theme(dow_fig, "Spending Velocity by Day of Week", "Distribution of debits across calendar weekdays"), use_container_width=True, key="an_dow_fig")
        else:
            st.info("No dated transactions available for temporal pattern analysis.")

    # ─── Tab 6: Account Portfolio ─────────────────────────────────────────────
    with tab_accts:
        accounts = get_all_accounts()
        if accounts:
            st.markdown(f"##### Detected Account Portfolio ({len(accounts)} Accounts)")
            accts_df = pd.DataFrame(accounts)
            st.dataframe(accts_df, use_container_width=True, hide_index=True)
        else:
            st.info("Single statement active. Upload multiple statements to unlock portfolio aggregation.")

