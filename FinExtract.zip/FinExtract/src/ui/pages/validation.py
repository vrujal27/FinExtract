"""Validation Centre and Balance Reconciliation Studio for FinExtract."""
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from typing import Optional, List, Dict, Any

from src.ui.formatters import fmt_inr, clean_html, fmt_pct
from src.ui.components import page_header, kpi_card, status_badge, empty_state
from src.ui.state import get_scoped_dataframe, get_active_job
from src.ui.charts import apply_theme, chart_balance_timeline


def render_validation_centre():
    """Render the mathematical balance verification and data audit center."""
    page_header(
        title="Validation & Audit Centre",
        subtitle="Mathematical running balance reconciliation, data continuity verification, and duplicate triage",
        right_badge="Continuous Ledger Audit"
    )

    scope = st.session_state.get("selected_scope", "Current statement")
    account_id = st.session_state.get("selected_account_id")
    df, meta = get_scoped_dataframe(scope=scope, account_id=account_id)
    active_job = get_active_job()

    if df.empty:
        empty_state(
            icon="🔍",
            title="No Statements Loaded for Validation",
            body="Upload a statement from the Upload Statement screen to inspect balance integrity and anomaly detection."
        )
        return

    # Gather reconciliation data
    recon = active_job.get("reconciliation", {}) if active_job and isinstance(active_job.get("reconciliation"), dict) else {}
    issues = active_job.get("validation_issues", []) if active_job and isinstance(active_job.get("validation_issues"), list) else []
    total_tx = len(df)
    matched_count = recon.get("matched", total_tx)
    mismatched_count = recon.get("mismatched", 0)
    total_checked = recon.get("total_checked", total_tx)
    recon_status = recon.get("status", "PASSED")
    pass_rate = (matched_count / max(total_checked, 1)) * 100.0 if total_checked > 0 else 100.0

    errors_count = sum(1 for i in issues if isinstance(i, dict) and str(i.get("severity")).upper() == "ERROR")
    warnings_count = sum(1 for i in issues if isinstance(i, dict) and str(i.get("severity")).upper() == "WARNING")

    # ─── Top Verification Metrics ─────────────────────────────────────────────
    v1, v2, v3, v4 = st.columns(4)
    with v1:
        recon_badge = "good" if recon_status == "PASSED" else "bad" if recon_status == "FAILED" else "neutral"
        kpi_card(
            label="Reconciliation Status",
            value=recon_status,
            delta=f"{pass_rate:.1f}% Integrity",
            delta_type=recon_badge,
            icon="⚖️",
            help_text="Mathematical ledger audit"
        )
    with v2:
        kpi_card(
            label="Continuous Matches",
            value=f"{matched_count:,}",
            delta=f"{matched_count} of {total_checked} rows",
            delta_type="good",
            icon="✓",
            help_text="Exact running balance continuity"
        )
    with v3:
        err_type = "good" if errors_count == 0 else "bad"
        kpi_card(
            label="Critical Ledger Mismatches",
            value=str(mismatched_count),
            delta="0 breaks" if mismatched_count == 0 else f"{mismatched_count} breaks",
            delta_type=err_type,
            icon="✕",
            help_text="Line items failing balance test"
        )
    with v4:
        warn_type = "good" if warnings_count == 0 else "neutral"
        kpi_card(
            label="Validation Alerts Logged",
            value=str(len(issues)),
            delta=f"{warnings_count} warnings, {errors_count} errors",
            delta_type=warn_type,
            icon="⚠️",
            help_text="Audit and parser notices"
        )

    st.markdown("<div style='height: 14px;'></div>", unsafe_allow_html=True)

    # ─── Balance Timeline Chart ───────────────────────────────────────────────
    st.markdown("##### 📈 Running Balance Continuous Audit")
    st.plotly_chart(
        chart_balance_timeline(df, issues=issues),
        use_container_width=True,
        key="val_bal_timeline"
    )

    st.markdown("<div style='height: 14px;'></div>", unsafe_allow_html=True)

    # ─── Audit Issues & Anomalies ─────────────────────────────────────────────
    st.markdown("##### 📋 Detected Audit Issues & Ledger Warnings")
    if not issues:
        st.success("✓ Zero validation or reconciliation issues detected in this document scope.")
    else:
        issue_rows = []
        for i in issues:
            issue_rows.append({
                "Severity": str(i.get("severity", "WARNING")).upper(),
                "Type": str(i.get("issue_type", "AUDIT_NOTICE")),
                "Description": str(i.get("description", "")),
                "Transaction ID": str(i.get("transaction_id", "—")),
                "Expected Value": str(i.get("expected_value", "—")),
                "Extracted Value": str(i.get("actual_value", "—"))
            })

        issues_df = pd.DataFrame(issue_rows)
        st.dataframe(
            issues_df,
            use_container_width=True,
            hide_index=True,
            column_config={
                "Severity": st.column_config.TextColumn(width="small"),
                "Type": st.column_config.TextColumn(width="medium"),
                "Description": st.column_config.TextColumn(width="large"),
                "Transaction ID": st.column_config.TextColumn(width="small"),
                "Expected Value": st.column_config.TextColumn(width="small"),
                "Extracted Value": st.column_config.TextColumn(width="small")
            }
        )

    # ─── OCR Confidence Audit for Scanned Pages ───────────────────────────────
    det = active_job.get("detection", {}) if active_job else {}
    if det.get("requires_ocr") or det.get("pdf_type") in ("scanned", "mixed"):
        st.markdown("<div style='height: 14px;'></div>", unsafe_allow_html=True)
        st.markdown("##### 👁 OCR Stream Confidence Breakdown")
        page_details = det.get("page_details", [])
        ocr_pages = [p for p in page_details if p.get("page_type") == "scanned"]
        
        if ocr_pages:
            op_data = []
            for p in ocr_pages:
                op_data.append({
                    "Page": f"Page {p.get('page_number')}",
                    "Stream": "Tesseract OCR",
                    "Status": "Completed",
                    "Text Length": p.get("text_length", 0)
                })
            st.dataframe(pd.DataFrame(op_data), use_container_width=True, hide_index=True)
        else:
            st.info("No scanned pages required OCR processing in this statement.")

