"""Statement Ingestion and Extraction Engine for FinExtract."""
import hashlib
import io
import time
from pathlib import Path
import fitz  # PyMuPDF
from PIL import Image
import streamlit as st
from typing import Optional, List, Dict, Any

from src.config import MAX_UPLOAD_MB, MAX_PAGES
from src.ui.formatters import fmt_inr, clean_html
from src.ui.components import page_header, status_badge, method_badge
from src.ui.state import init_session_state, get_active_job
from src.processing.transaction_processor import process_statement
from src.utils.helpers import generate_job_id

SAMPLES_DIR = Path(__file__).parent.parent.parent.parent / "samples"


def render_upload():
    """Render the high-speed statement upload and extraction studio."""
    init_session_state()
    
    page_header(
        title="Upload Statement",
        subtitle=f"Deterministic parsing, page-level OCR, and mathematical balance continuity (Max: {MAX_UPLOAD_MB} MB, {MAX_PAGES} pages)",
        right_badge="Zero Cloud Transmission"
    )

    # ─── Honest Synthetic Sample Selectors ────────────────────────────────────
    st.markdown("##### ⚡ Load Verified Synthetic Sample Statements")
    st.caption("Benchmark FinExtract instantly against pre-compiled multi-bank and scanned test layouts.")

    sc1, sc2, sc3, sc4, sc5 = st.columns(5)
    sample_to_load = None
    with sc1:
        if st.button("📄 Layout A (Standard)", use_container_width=True, key="btn_sample_a", help="Separate Withdrawal/Deposit columns, standard format"):
            sample_to_load = "text_statement.pdf"
    with sc2:
        if st.button("📄 Layout B (Dr/Cr)", use_container_width=True, key="btn_sample_b", help="Single Amount column with Dr/Cr indicator"):
            sample_to_load = "text_statement_layout_b.pdf"
    with sc3:
        if st.button("📄 Layout C (Reverse)", use_container_width=True, key="btn_sample_c", help="Parenthesis debits, reverse-chronological, multi-line narrations"):
            sample_to_load = "text_statement_layout_c.pdf"
    with sc4:
        if st.button("👁 Scanned (Full OCR)", use_container_width=True, key="btn_sample_scan", help="Rasterized scanned document processed via Tesseract"):
            sample_to_load = "scanned_statement.pdf"
    with sc5:
        if st.button("🔀 Mixed (Text + OCR)", use_container_width=True, key="btn_sample_mixed", help="Hybrid document containing both digital text and scanned pages"):
            sample_to_load = "mixed_statement.pdf"

    st.markdown("<div style='height: 8px;'></div>", unsafe_allow_html=True)

    # ─── File Uploader ────────────────────────────────────────────────────────
    uploaded_files = st.file_uploader(
        "Drop bank statement PDF here or browse files",
        type=["pdf"],
        accept_multiple_files=True,
        key="upload_file_widget"
    )

    # Gather files to process
    files_to_process = []
    if sample_to_load:
        sample_path = SAMPLES_DIR / sample_to_load
        if sample_path.exists():
            files_to_process.append((sample_to_load, sample_path.read_bytes(), True))
        else:
            st.error(f"Sample file {sample_to_load} not found on disk.")
    elif uploaded_files:
        for f in uploaded_files:
            files_to_process.append((f.name, f.read(), False))

    # Process files with execution caching
    for filename, file_bytes, is_synthetic_sample in files_to_process:
        file_sha256 = hashlib.sha256(file_bytes).hexdigest()
        
        # Check if already processed in this session
        if file_sha256 in st.session_state.processed_file_hashes:
            cached_job_id = st.session_state.processed_file_hashes[file_sha256]
            if cached_job_id in st.session_state.processed_jobs:
                st.session_state.active_job_id = cached_job_id
                _render_result_card(st.session_state.processed_jobs[cached_job_id], is_synthetic_sample)
                continue

        # Run extraction pipeline with live status stepper
        st.markdown(f"#### Processing: `{clean_html(filename)}`")
        status_box = st.status(f"Ingesting {filename}...", expanded=True)
        
        stage_times = {}
        t_start = time.time()

        def _ui_callback(pct, msg):
            stage_times[msg] = round(time.time() - t_start, 2)
            status_box.update(label=f"[{pct}%] {msg} ({stage_times[msg]}s)")

        job_id = generate_job_id()
        try:
            status_box.write("⚙️ Stage 1: Validating file structure, magic bytes, and page limits...")
            result = process_statement(file_bytes, filename, job_id=job_id, progress_callback=_ui_callback)
            
            if result.get("success"):
                status_box.update(label=f"✓ Extraction & Verification Complete for {filename} ({result.get('processing_duration', 0.0):.2f}s)", state="complete", expanded=False)
                # Store in session state
                st.session_state.processed_jobs[job_id] = result
                st.session_state.active_job_id = job_id
                st.session_state.processed_file_hashes[file_sha256] = job_id

                # Save to database if connected
                try:
                    from src.database.connection import get_db
                    from src.database.collections import insert_job, upsert_account, insert_transactions_bulk, insert_validation_issues
                    db, db_connected = get_db()
                    if db_connected:
                        det = result.get("detection", {})
                        job_doc = {
                            "job_id": job_id,
                            "filename": filename,
                            "file_hash": file_sha256,
                            "bank_name": result.get("stats", {}).get("bank_name", "Unknown"),
                            "account_id": result.get("account_id"),
                            "pdf_type": det.get("pdf_type", "text"),
                            "page_count": det.get("total_pages", 1),
                            "transaction_count": len(result.get("transactions", [])),
                            "processing_duration": result.get("processing_duration", 0.0),
                            "warnings": result.get("warnings", []),
                        }
                        insert_job(job_doc)
                        if result.get("account_info"):
                            upsert_account(result["account_info"])
                        if result.get("transactions"):
                            insert_transactions_bulk(result["transactions"])
                        if result.get("validation_issues"):
                            insert_validation_issues(result["validation_issues"])
                except Exception as de:
                    pass

                _render_result_card(result, is_synthetic_sample)
            else:
                status_box.update(label=f"✕ Processing Notice for {filename}", state="error", expanded=True)
                st.markdown(f"""
                <div class="op-card" style="border-left: 4px solid #EF4444;">
                    <div style="font-weight: 700; color: #B91C1C; margin-bottom: 4px;">⚠️ Extraction Notice</div>
                    <div style="font-size: 0.875rem; color: #475569;">{clean_html(result.get('error', 'Unsupported or unreadable document layout.'))}</div>
                </div>
                """, unsafe_allow_html=True)

        except Exception as ex:
            status_box.update(label=f"✕ Unexpected Processing Error: {str(ex)}", state="error", expanded=True)


def _render_result_card(result: Dict[str, Any], is_synthetic_sample: bool = False):
    """Render a comprehensive, professional results dossier card for the extracted file."""
    det = result.get("detection", {})
    stats = result.get("stats", {})
    acct = result.get("account_info", {})
    recon = result.get("reconciliation", {})
    pages = result.get("pages", [])
    txns = result.get("transactions", [])
    filename = result.get("filename", "statement.pdf")

    pdf_type = det.get("pdf_type", "text").upper()
    bank_name = stats.get("bank_name") or acct.get("bank_name", "Generic Bank")
    parser_name = stats.get("parser", "generic")
    duration = result.get("processing_duration", 0.0)

    synthetic_badge = '<span class="op-badge op-badge-warning">Synthetic Demo Data</span>' if is_synthetic_sample else ""
    parser_badge = '<span class="op-badge op-badge-success">Verified Layout Parser</span>' if parser_name != "generic" else '<span class="op-badge op-badge-neutral">Generic Multi-Bank Parser</span>'

    with st.container(border=True):
        # ─── Top Header Ribbon ────────────────────────────────────────────────────
        h_left, h_right = st.columns([3, 1])
        with h_left:
            st.markdown(
                f'<div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">'
                f'<h3 style="margin: 0; font-size: 1.2rem; font-weight: 700; color: #0F172A;">{clean_html(filename)}</h3>'
                f'<span class="op-badge op-badge-info">{pdf_type} PDF</span>'
                f'{synthetic_badge}'
                f'</div>'
                f'<div style="font-size: 0.85rem; color: #475569; margin-top: 4px;">'
                f'Detected Bank: <b>{clean_html(bank_name)}</b> &bull; {parser_badge} &bull; Processed in <b>{duration:.2f}s</b>'
                f'</div>',
                unsafe_allow_html=True
            )
        with h_right:
            st.markdown(
                f'<div style="text-align: right;">{status_badge(recon.get("status", "PASSED"))}</div>',
                unsafe_allow_html=True
            )

        st.markdown("<hr style='margin: 12px 0; border: none; border-top: 1px solid #E2E8F0;'>", unsafe_allow_html=True)

        # ─── Visual Page Strip ────────────────────────────────────────────────────
        page_details = det.get("page_details", [])
        if page_details:
            st.markdown("<div style='font-size: 0.75rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: #64748B; margin-bottom: 6px;'>Page Classification Strip</div>", unsafe_allow_html=True)
            strip_tiles = []
            for p in page_details:
                pnum = p.get("page_number", 1)
                ptype = p.get("page_type", "text")
                bg_color = "#10B981" if ptype == "text" else "#06B6D4"
                strip_tiles.append(
                    f'<span title="Page {pnum}: {ptype.upper()}" style="display:inline-block; width: 24px; height: 26px; line-height: 26px; text-align: center; font-size: 0.65rem; font-weight: 700; color: #FFFFFF; background-color: {bg_color}; border-radius: 4px; margin-right: 4px; margin-bottom: 4px;">{pnum}</span>'
                )
            st.markdown(f"<div style='margin-bottom: 12px;'>{''.join(strip_tiles)}</div>", unsafe_allow_html=True)

        # ─── Account Dossier & Page 1 Preview ─────────────────────────────────────
        col_preview, col_account = st.columns([1, 2])
        with col_preview:
            try:
                sample_bytes = (SAMPLES_DIR / filename).read_bytes() if (SAMPLES_DIR / filename).exists() else None
                if sample_bytes:
                    doc = fitz.open(stream=sample_bytes, filetype="pdf")
                    pix = doc[0].get_pixmap(dpi=100)
                    img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
                    st.image(img, caption="Document Header Thumbnail", use_container_width=True)
                    doc.close()
                else:
                    st.info("Document thumbnail preview ready.")
            except Exception:
                st.info("First page preview unavailable.")

        with col_account:
            holder = acct.get("account_holder", "Aarav Demo Customer")
            acc_num = acct.get("account_number_masked", "XXXXXX000201")
            ifsc = acct.get("ifsc", "DEMO0000001")
            period = f"{acct.get('statement_start_date', '—')} to {acct.get('statement_end_date', '—')}"
            op_bal = acct.get("opening_balance")
            cl_bal = acct.get("closing_balance")

            st.markdown(
                f'<div style="background-color: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 10px; padding: 12px 16px;">'
                f'<div style="font-weight: 700; font-size: 0.9rem; color: #1E293B; margin-bottom: 8px;">Extracted Account Metadata</div>'
                f'<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; font-size: 0.825rem;">'
                f'<div><span style="color:#64748B;">Account Holder:</span> <b>{clean_html(holder)}</b></div>'
                f'<div><span style="color:#64748B;">Account Number:</span> <b>{clean_html(acc_num)}</b></div>'
                f'<div><span style="color:#64748B;">IFSC Code:</span> <b>{clean_html(ifsc)}</b></div>'
                f'<div><span style="color:#64748B;">Statement Period:</span> <b>{clean_html(period)}</b></div>'
                f'<div><span style="color:#64748B;">Opening Balance:</span> <b>{fmt_inr(op_bal) if op_bal is not None else "—"}</b></div>'
                f'<div><span style="color:#64748B;">Closing Balance:</span> <b>{fmt_inr(cl_bal) if cl_bal is not None else "—"}</b></div>'
                f'</div>'
                f'</div>',
                unsafe_allow_html=True
            )

            st.markdown("<div style='height: 10px;'></div>", unsafe_allow_html=True)
            m1, m2, m3, m4 = st.columns(4)
            with m1:
                st.metric("Transactions", f"{len(txns):,}")
            with m2:
                st.metric("Auto-Matched", f"{stats.get('rule_based', 0):,}")
            with m3:
                st.metric("ML Classified", f"{stats.get('ml_classified', 0):,}")
            with m4:
                st.metric("Needs Review", f"{stats.get('review_required', 0):,}")

