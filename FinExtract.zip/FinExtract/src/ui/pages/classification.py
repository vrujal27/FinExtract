"""Classification Centre & Machine Learning Model Card for FinExtract."""
import json
from pathlib import Path
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from typing import Optional, List, Dict, Any

from src.config import CLASSIFIER_META_PATH, RULES_FILE, CATEGORIES
from src.ui.formatters import fmt_inr, clean_html, fmt_pct
from src.ui.components import page_header, kpi_card, status_badge, method_badge, category_chip, empty_state
from src.ui.state import get_scoped_dataframe, get_active_job
from src.ui.charts import apply_theme


def render_classification_centre():
    """Render the classification audit studio, explainability queue, and ML model card."""
    page_header(
        title="Classification Centre",
        subtitle="Two-tier hybrid categorization engine: deterministic rules + TF-IDF Logistic Regression",
        right_badge="Zero External LLM APIs"
    )

    scope = st.session_state.get("selected_scope", "Current statement")
    account_id = st.session_state.get("selected_account_id")
    df, meta = get_scoped_dataframe(scope=scope, account_id=account_id)

    total_txns = len(df)
    rule_count = int((df["classification_method"] == "RULE_BASED").sum()) if not df.empty else 0
    ml_count = int((df["classification_method"] == "MACHINE_LEARNING").sum()) if not df.empty else 0
    manual_count = int((df["classification_method"] == "MANUAL").sum()) if not df.empty else 0
    review_count = int((df["review_required"] == True).sum()) if not df.empty else 0
    unclass_count = int((df["category"] == "Unclassified").sum()) if not df.empty else 0

    # ─── Hierarchy Funnel Metric Strip ────────────────────────────────────────
    c1, c2, c3, c4, c5 = st.columns(5)
    with c1:
        kpi_card("Total Scoped", f"{total_txns:,}", "100% Volume", "neutral", "📦")
    with c2:
        kpi_card("Deterministic Rules", f"{rule_count:,}", f"{(rule_count/max(total_txns,1))*100:.1f}%", "good", "⚡", "Priority keyword match")
    with c3:
        kpi_card("Machine Learning", f"{ml_count:,}", f"{(ml_count/max(total_txns,1))*100:.1f}%", "good", "🤖", "TF-IDF Logistic Reg")
    with c4:
        kpi_card("Review Flagged", f"{review_count:,}", f"{(review_count/max(total_txns,1))*100:.1f}%", "bad" if review_count > 0 else "good", "⚠️", "Low ML confidence")
    with c5:
        kpi_card("Auditor Corrected", f"{manual_count:,}", f"{manual_count} overrides", "neutral", "✎", "Manual adjustments")

    st.markdown("<div style='height: 16px;'></div>", unsafe_allow_html=True)

    tab_queue, tab_rules, tab_model = st.tabs([
        "📋 Human-in-the-Loop Review Queue",
        "⚡ Deterministic Rule Engine",
        "📊 ML Model Card & Evaluation"
    ])

    # ─── Tab 1: Human-in-the-Loop Review Queue ────────────────────────────────
    with tab_queue:
        if df.empty:
            empty_state("📋", "No Records in Scope", "Load a statement to inspect classification triage.")
        else:
            review_df = df[df["review_required"] == True].copy()
            if review_df.empty:
                st.success("🎉 All scoped transactions have been categorized with high confidence! Zero items require review.")
            else:
                st.markdown(f"##### Showing {len(review_df)} Line Items Requiring Verification")
                st.caption("Transactions routed here due to conflicting merchant keywords or prediction confidence < 60%.")

                for idx, row in review_df.iterrows():
                    tid = row["transaction_id"]
                    desc = row["description"]
                    cat = row["category"]
                    conf = row["ml_confidence"]
                    amt = row["debit"] if row["debit"] > 0 else row["credit"]
                    amt_type = "Debit" if row["debit"] > 0 else "Credit"

                    with st.container():
                        st.markdown(f"""
                        <div style="background-color: #FFFFFF; border: 1px solid #E2E8F0; border-radius: 10px; padding: 12px 16px; margin-bottom: 10px; display: flex; justify-content: space-between; align-items: center;">
                            <div>
                                <span style="font-size: 0.75rem; font-weight: 700; color: #64748B;">{clean_html(tid)}</span> &bull; 
                                <span style="font-size: 0.9rem; font-weight: 600; color: #0F172A;">{clean_html(desc)}</span><br>
                                <span style="font-size: 0.775rem; color: #64748B;">Amount: <b>{fmt_inr(amt)}</b> ({amt_type}) &bull; ML Confidence: <b>{fmt_pct(conf)}</b> &bull; Assigned: <b>{clean_html(cat)}</b></span>
                            </div>
                            <div>
                                {method_badge(row['classification_method'])}
                            </div>
                        </div>
                        """, unsafe_allow_html=True)
                        
                        col_action, col_btn = st.columns([3, 1])
                        with col_action:
                            chosen_cat = st.selectbox(
                                "Verify / Reassign Category:",
                                CATEGORIES,
                                index=CATEGORIES.index(cat) if cat in CATEGORIES else 0,
                                key=f"q_cat_{tid}"
                            )
                        with col_btn:
                            st.write("")
                            st.write("")
                            if st.button("Approve & Verify ✓", key=f"q_btn_{tid}", use_container_width=True):
                                active_job = get_active_job()
                                if active_job:
                                    for t in active_job.get("transactions", []):
                                        if t.get("transaction_id") == tid:
                                            t["category"] = chosen_cat
                                            t["review_required"] = False
                                            t["classification_method"] = "MANUAL"
                                            break
                                st.toast(f"Verified {tid} as {chosen_cat} ✓")
                                st.rerun()

    # ─── Tab 2: Deterministic Rule Engine ─────────────────────────────────────
    with tab_rules:
        st.markdown("##### Pre-Compiled Deterministic Rules Catalog")
        st.caption("First-tier classification: exact and regex keyword patterns execute in priority order with zero hallucination.")

        rules = []
        if RULES_FILE.exists():
            try:
                with open(RULES_FILE, "r", encoding="utf-8") as rf:
                    data = json.load(rf)
                    if isinstance(data, dict):
                        rules = data.get("rules", [])
                    elif isinstance(data, list):
                        rules = data
            except Exception:
                rules = []

        if rules:
            rule_rows = []
            for r in rules:
                if not isinstance(r, dict):
                    continue
                pat = r.get("pattern", "")
                cat = r.get("category", "")
                prio = r.get("priority", 50)
                strat = r.get("strategy", "contains")
                rid = r.get("id", "")
                
                # Count matches in current dataset
                hits = 0
                if not df.empty:
                    hits = int((df["rule_id"] == rid).sum())

                rule_rows.append({
                    "Rule ID": rid,
                    "Target Category": cat,
                    "Pattern": pat,
                    "Strategy": strat,
                    "Priority": prio,
                    "Scope Hits": hits
                })

            rules_df = pd.DataFrame(rule_rows)
            st.dataframe(
                rules_df,
                use_container_width=True,
                hide_index=True,
                column_config={
                    "Rule ID": st.column_config.TextColumn(width="medium"),
                    "Target Category": st.column_config.TextColumn(width="medium"),
                    "Pattern": st.column_config.TextColumn(width="large"),
                    "Priority": st.column_config.NumberColumn(width="small"),
                    "Scope Hits": st.column_config.NumberColumn("Current Matches", width="small")
                }
            )
        else:
            st.info("No rules.json catalog found.")

    # ─── Tab 3: ML Model Card & Evaluation ────────────────────────────────────
    with tab_model:
        st.markdown("##### Machine Learning Model Card & Technical Specifications")
        st.caption("Second-tier classification: invoked when deterministic rules do not match.")

        meta_data = {}
        if CLASSIFIER_META_PATH.exists():
            try:
                with open(CLASSIFIER_META_PATH, "r", encoding="utf-8") as mf:
                    meta_data = json.load(mf)
            except Exception:
                meta_data = {}

        if meta_data:
            mc1, mc2, mc3, mc4 = st.columns(4)
            with mc1:
                st.metric("Training Architecture", "TF-IDF + LogisticReg")
            with mc2:
                st.metric("Synthetic Sample Count", f"{meta_data.get('total_samples', 2000):,}")
            with mc3:
                st.metric("Held-Out Accuracy", fmt_pct(meta_data.get("accuracy", 1.0)))
            with mc4:
                st.metric("Macro F1-Score", fmt_pct(meta_data.get("macro_f1", 1.0)))

            st.caption("<span style='color: #64748B;'>* Model trained on synthetic retail statements; metrics reflect held-out synthetic test validation and strictly non-LLM inference.</span>", unsafe_allow_html=True)

            # Confusion Matrix Heatmap
            cm = meta_data.get("confusion_matrix")
            classes = meta_data.get("classes", [])
            if cm and classes:
                st.markdown("###### Multi-Class Confusion Matrix")
                cm_fig = go.Figure(data=go.Heatmap(
                    z=cm,
                    x=classes,
                    y=classes,
                    colorscale="Blues",
                    hovertemplate="True: %{y}<br>Predicted: %{x}<br>Count: %{z}<extra></extra>"
                ))
                cm_fig.update_layout(
                    height=450,
                    xaxis=dict(tickangle=-45),
                    margin=dict(l=80, r=20, t=20, b=100)
                )
                st.plotly_chart(apply_theme(cm_fig), use_container_width=True, key="ml_cm_heatmap")

            # Per-class F1 Bar Chart
            report = meta_data.get("classification_report", {})
            f1_data = []
            for k, v in report.items():
                if isinstance(v, dict) and "f1-score" in v and k not in ("macro avg", "weighted avg"):
                    f1_data.append({"Category": k, "F1-Score": v["f1-score"]})

            if f1_data:
                f1_df = pd.DataFrame(f1_data).sort_values(by="F1-Score", ascending=True)
                st.markdown("###### Per-Class F1 Performance")
                f1_fig = px.bar(
                    f1_df,
                    x="F1-Score",
                    y="Category",
                    orientation="h",
                    color_discrete_sequence=["#4F46E5"]
                )
                f1_fig.update_layout(height=400)
                st.plotly_chart(apply_theme(f1_fig), use_container_width=True, key="ml_f1_barchart")
        else:
            st.info("No model metadata file available.")

