"""Parsers module for FinExtract."""
from src.parsers.base_parser import BaseParser
from src.parsers.bank_detector import detect_bank, register_parser
from src.parsers.generic_parser import GenericParser
from src.parsers.hdfc_parser import HDFCParser
from src.parsers.icici_parser import ICICIParser
from src.parsers.sbi_parser import SBIParser
from src.parsers.axis_parser import AxisParser

__all__ = [
    "BaseParser",
    "detect_bank",
    "register_parser",
    "GenericParser",
    "HDFCParser",
    "ICICIParser",
    "SBIParser",
    "AxisParser",
]
