"""State Bank of India statement parser adapter."""
import re
from typing import Dict, List
from src.parsers.base_parser import BaseParser
from src.parsers.bank_detector import register_parser
from src.parsers.generic_parser import GenericParser


@register_parser
class SBIParser(BaseParser):
    """
    SBI Bank statement parser.
    Note: Detection verified against synthetic snippets. Layout parsing delegates to GenericParser.
    """
    name = "sbi"
    bank_name = "State Bank of India"
    verified = True

    def detect(self, text: str) -> bool:
        if not text:
            return False
        return (
            bool(re.search(r'\bSTATE\s+BANK\s+OF\s+INDIA\b', text, re.IGNORECASE))
            or bool(re.search(r'\bSBIN[0-9A-Z]{7}\b', text))
            or bool(re.search(r'\bSBI\b', text))
        )

    def parse_account(self, text: str) -> Dict:
        result = GenericParser().parse_account(text)
        result["bank_name"] = "State Bank of India"
        result["layout_note"] = "SBI adapter active (detection verified on synthetic snippet; layout unverified)"
        return result

    def parse_transactions(self, pages: List[Dict]) -> List[Dict]:
        return GenericParser().parse_transactions(pages)

