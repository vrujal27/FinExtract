"""Generic bank statement parser - handles multiple layouts via column detection."""
import logging
import re
from decimal import Decimal
from typing import Dict, List, Optional, Tuple

from src.parsers.base_parser import BaseParser
from src.parsers.bank_detector import register_parser
from src.utils.helpers import parse_decimal, parse_date, infer_day_first, normalize_description, truncate_string

logger = logging.getLogger("finextract.generic_parser")

# Column header synonyms for detection
DATE_HEADERS = {"date", "transaction date", "txn date", "value date", "posting date", "trans date", "tran date", "value dt"}
DESC_HEADERS = {"description", "particulars", "narration", "details", "transaction details", "remarks", "narrative", "txn description", "particular"}
DEBIT_HEADERS = {"debit", "withdrawal", "withdrawals", "dr", "debit amount", "amount debited", "paid out", "withdrawal amount", "dr amount"}
CREDIT_HEADERS = {"credit", "deposit", "deposits", "cr", "credit amount", "amount credited", "paid in", "deposit amount", "cr amount"}
BALANCE_HEADERS = {"balance", "running balance", "closing balance", "available balance", "bal", "book balance", "ledger balance"}
AMOUNT_HEADERS = {"amount", "transaction amount", "net amount", "amt"}
INDICATOR_HEADERS = {"dr/cr", "type", "indicator", "cr/dr", "d/c", "c/d"}
REF_HEADERS = {"reference", "ref no", "reference no", "chq no", "cheque no", "utr", "transaction id", "ref", "cheque number"}

SYNTHETIC_MARKER = "SYNTHETIC SAMPLE"

# Typical date regex patterns
DATE_RE = re.compile(
    r'^(?:'
    r'\d{1,2}[-/]\d{1,2}[-/]\d{2,4}|'           # 01/01/2025, 01-01-2025
    r'\d{4}[-/]\d{1,2}[-/]\d{1,2}|'           # 2025-01-01
    r'\d{1,2}[-\s][A-Za-z]{3,9}[-\s]\d{2,4}|' # 01 Jan 2025
    r'[A-Za-z]{3,9}[-\s]\d{1,2},?[-\s]\d{2,4}' # Jan 01, 2025
    r')$'
)

DATE_SEARCH_RE = re.compile(
    r'(?:\b|^)('
    r'\d{1,2}[-/]\d{1,2}[-/]\d{2,4}|'
    r'\d{4}[-/]\d{1,2}[-/]\d{1,2}|'
    r'\d{1,2}[-\s][A-Za-z]{3,9}[-\s]\d{2,4}|'
    r'[A-Za-z]{3,9}[-\s]\d{1,2},?[-\s]\d{2,4}'
    r')(?:\b|$)'
)

DEBIT_KEYWORDS = (
    'DR', 'WDL', 'WITHDRAWAL', 'DEBIT', 'PAYMENT', 'PURCHASE', 'POS', 'BILL', 
    'EXPENSE', 'FEE', 'CHARGES', 'TAX', 'SWIGGY', 'ZOMATO', 'UBER', 'OLA', 
    'AMAZON', 'FLIPKART', 'NETFLIX', 'PHARMACY', 'PETROL', 'FUEL', 'RECHARGE', 
    'TRANSFER TO', 'SENT', 'ATM', 'FOOD', 'SHOP'
)

CREDIT_KEYWORDS = (
    'CR', 'CREDIT', 'DEPOSIT', 'SALARY', 'REFUND', 'INTEREST', 'CASHBACK', 
    'DIVIDEND', 'RECEIVED', 'TRANSFER FROM'
)

AMOUNT_RE = re.compile(r'^[\d,]+(\.\d{1,2})?$')
PARENTHESIS_AMOUNT_RE = re.compile(r'^\([\d,]+(\.\d{1,2})?\)$')


def _normalize_header(h: str) -> str:
    return h.lower().strip().replace('\n', ' ')


def _classify_header(h: str) -> str:
    hn = _normalize_header(h)
    clean_h = re.sub(r'[\(\)\[\]]', '', hn).strip()

    # Exact match first
    if hn in DATE_HEADERS or clean_h in DATE_HEADERS:
        return "date"
    if hn in DEBIT_HEADERS or clean_h in DEBIT_HEADERS:
        return "debit"
    if hn in CREDIT_HEADERS or clean_h in CREDIT_HEADERS:
        return "credit"
    if hn in BALANCE_HEADERS or clean_h in BALANCE_HEADERS:
        return "balance"
    if hn in DESC_HEADERS or clean_h in DESC_HEADERS:
        return "description"
    if hn in INDICATOR_HEADERS or clean_h in INDICATOR_HEADERS:
        return "indicator"
    if hn in AMOUNT_HEADERS or clean_h in AMOUNT_HEADERS:
        return "amount"
    if hn in REF_HEADERS or clean_h in REF_HEADERS:
        return "reference"

    # Substring / keyword matching
    if any(k in hn for k in ["date", "txn dt", "value dt", "trans dt"]):
        return "date"
    if any(k in hn for k in ["withdrawal", "debit", "dr"]):
        return "debit"
    if any(k in hn for k in ["deposit", "credit", "cr"]) and not any(k in hn for k in ["indicator", "type"]):
        return "credit"
    if any(k in hn for k in ["balance", "bal"]):
        return "balance"
    if any(k in hn for k in ["particular", "narration", "description", "remark", "detail"]):
        return "description"
    if any(k in hn for k in ["dr/cr", "cr/dr", "indicator"]):
        return "indicator"
    if any(k in hn for k in ["amount", "amt"]):
        return "amount"
    if any(k in hn for k in ["ref", "chq", "utr"]):
        return "reference"
    return "unknown"


def _is_amount(val: str) -> bool:
    cleaned = val.replace(',', '').strip()
    # Remove currency symbols
    cleaned = re.sub(r'^[₹$Rs\.]+', '', cleaned)
    cleaned = re.sub(r'(DR|CR|D|C)$', '', cleaned, flags=re.IGNORECASE).strip()
    if cleaned.startswith('(') and cleaned.endswith(')'):
        cleaned = cleaned[1:-1]
    if cleaned.startswith('-'):
        cleaned = cleaned[1:]
    try:
        float(cleaned)
        return bool(cleaned)
    except ValueError:
        return False


def _is_date(val: str) -> bool:
    return bool(DATE_RE.match(val.strip()))


@register_parser
class GenericParser(BaseParser):
    """
    Generic parser that handles multiple column layouts by detecting headers.
    Supports:
    - Layout A: Separate Withdrawal/Deposit columns, DD/MM/YYYY
    - Layout B: Single Amount column with Dr/Cr indicator, DD-MMM-YYYY
    - Layout C: Debit/Credit columns with parentheses, reverse-chronological, multi-line narrations
    """
    name = "generic"
    bank_name = "Generic Bank"
    verified = True  # Verified against synthetic layouts A, B, C

    def detect(self, text: str) -> bool:
        """Generic parser is always a valid fallback."""
        return True

    def parse_account(self, text: str) -> Dict:
        """Extract account information."""
        # Skip synthetic marker line in parsing
        clean_text = text.replace(SYNTHETIC_MARKER, "")
        return {
            "bank_name": self._detect_bank_name(text),
            "account_holder": self._extract_account_holder(clean_text),
            "account_number_masked": self._mask_extracted_account(self._extract_account_number(clean_text)),
            "ifsc": self._extract_ifsc(clean_text),
            "statement_start_date": None,
            "statement_end_date": None,
            "opening_balance": self._extract_opening_balance(clean_text),
            "closing_balance": self._extract_closing_balance(clean_text),
            "currency": "INR",
            "layout_note": "Generic parser - layout not specifically verified for this bank."
        }

    def _detect_bank_name(self, text: str) -> str:
        """Try to detect bank name from text."""
        bank_patterns = {
            "HDFC Bank": r'\bHDFC\s+Bank\b',
            "ICICI Bank": r'\bICICI\s+Bank\b',
            "State Bank of India": r'\b(?:State Bank of India|SBI)\b',
            "Axis Bank": r'\bAxis\s+Bank\b',
            "Kotak Bank": r'\bKotak\b',
            "Yes Bank": r'\bYes\s+Bank\b',
            "Punjab National Bank": r'\bPNB\b|\bPunjab National Bank\b',
            "Bank of Baroda": r'\bBank of Baroda\b|\bBoB\b',
        }
        for name, pattern in bank_patterns.items():
            if re.search(pattern, text, re.IGNORECASE):
                return name
        # Try generic "BANK" occurrence
        m = re.search(r'([A-Z][A-Za-z\s]+Bank)', text)
        return m.group(1).strip() if m else "Unknown Bank"

    def _mask_extracted_account(self, account_num: str) -> str:
        from src.utils.helpers import mask_account_number
        return mask_account_number(account_num)

    def parse_transactions(self, pages: List[Dict]) -> List[Dict]:
        """
        Parse transactions from all pages.
        Detects layout per page (or uses first detected layout for consistency).
        """
        all_transactions = []
        layout = None
        col_map = None
        self._last_balance = None
        
        # Check first page or full text for opening balance
        for page_data in pages:
            text = page_data.get("text", "")
            m_op = re.search(r'Opening Balance[:\s]+(?:INR\s+)?([\d,]+\.\d{2})', text, re.I)
            if m_op:
                op_dec = parse_decimal(m_op.group(1))
                if op_dec:
                    self._last_balance = float(op_dec)
                    break
        
        all_dates = []
        
        for page_data in pages:
            page_num = page_data.get("page_number", 1)
            page_txns = []

            # Check if this page introduces a new section opening balance
            text = page_data.get("text", "")
            m_op = re.search(r'Opening Balance[:\s]+(?:INR\s+)?([\d,]+\.\d{2})', text, re.I)
            if m_op:
                op_dec = parse_decimal(m_op.group(1))
                if op_dec:
                    self._last_balance = float(op_dec)

            # Try pdfplumber tables first (most reliable for structured PDFs)
            pdfplumber_data = page_data.get("pdfplumber")
            if pdfplumber_data and pdfplumber_data.get("tables"):
                for table in pdfplumber_data["tables"]:
                    if not table or len(table) < 2:
                        continue
                    txns, detected_layout, detected_col_map = self._parse_table(
                        table, page_num, layout, col_map
                    )
                    if txns:
                        if layout is None:
                            layout = detected_layout
                            col_map = detected_col_map
                        page_txns.extend(txns)
                        all_dates.extend(t.get("raw_date", "") for t in txns if t.get("raw_date"))

            # If table extraction succeeded for this page, do NOT double-parse with text fallback
            if page_txns:
                all_transactions.extend(page_txns)
                continue

            # Fall back to text parsing
            if text:
                txns = self._parse_text_lines(text, page_num)
                all_transactions.extend(txns)
                all_dates.extend(t.get("raw_date", "") for t in txns if t.get("raw_date"))
        
        # Infer date format and normalize dates
        day_first = infer_day_first(all_dates)
        for txn in all_transactions:
            raw_date = txn.get("raw_date", "")
            if raw_date:
                parsed = parse_date(raw_date, day_first=day_first)
                txn["transaction_date"] = parsed
                txn["date_ambiguous"] = not day_first and not any(
                    int(p) > 12 for p in re.split(r'[-/]', raw_date) if p.isdigit()
                )
        
        return all_transactions

    def _parse_table(
        self, table: List[List], page_num: int,
        existing_layout: str = None, existing_col_map: Dict = None
    ) -> Tuple[List[Dict], str, Dict]:
        """Parse a pdfplumber table into transactions."""
        if not table:
            return [], existing_layout, existing_col_map
        
        # Find header row
        header_row_idx = None
        col_map = existing_col_map
        layout = existing_layout
        
        for i, row in enumerate(table):
            if row is None:
                continue
            normalized = [_classify_header(str(c or "")) for c in row]
            if "date" in normalized and ("description" in normalized or "debit" in normalized or "credit" in normalized):
                header_row_idx = i
                col_map = {}
                for j, col_type in enumerate(normalized):
                    if col_type not in col_map:
                        col_map[col_type] = j
                # Detect layout
                if "debit" in col_map and "credit" in col_map:
                    layout = "A_or_C"
                elif "amount" in col_map and "indicator" in col_map:
                    layout = "B"
                elif "amount" in col_map:
                    layout = "B_no_indicator"
                break
        
        if header_row_idx is None:
            if existing_col_map is not None:
                header_row_idx = -1
                col_map = existing_col_map
                layout = existing_layout
            else:
                return [], layout, col_map
        
        transactions = []
        pending_desc = []
        pending_row = None
        
        def flush_pending():
            if pending_row:
                if pending_desc:
                    extra = " ".join(pending_desc).strip()
                    if extra:
                        pending_row["description"] = pending_row["description"] + " " + extra
                        pending_row["raw_description"] = pending_row["description"]
                transactions.append(pending_row)
            pending_desc.clear()
        
        for row in table[header_row_idx + 1:]:
            if row is None or all(c is None or str(c).strip() == "" for c in row):
                continue
            
            cells = [str(c or "").strip() for c in row]
            
            # Skip repeated header rows
            if _classify_header(cells[col_map.get("date", 0)]) == "date":
                continue
            
            # Skip synthetic marker
            if any(SYNTHETIC_MARKER in c for c in cells):
                continue
            
            date_val = cells[col_map["date"]] if "date" in col_map and col_map["date"] < len(cells) else ""
            
            if _is_date(date_val):
                flush_pending()
                pending_row = self._extract_row(cells, col_map, layout, page_num)
                pending_desc = []
            elif pending_row is not None:
                # Multi-line description continuation
                desc_col = col_map.get("description", 1)
                if desc_col < len(cells) and cells[desc_col]:
                    pending_desc.append(cells[desc_col])
        
        flush_pending()
        return transactions, layout, col_map

    def _extract_row(self, cells: List[str], col_map: Dict, layout: str, page_num: int) -> Dict:
        """Extract a single transaction row."""
        from src.utils.helpers import generate_transaction_id
        
        raw_date = cells[col_map["date"]] if "date" in col_map and col_map["date"] < len(cells) else ""
        
        desc_col = col_map.get("description", -1)
        raw_desc = cells[desc_col] if desc_col >= 0 and desc_col < len(cells) else ""
        
        ref_col = col_map.get("reference", -1)
        ref = cells[ref_col] if ref_col >= 0 and ref_col < len(cells) else ""
        
        bal_col = col_map.get("balance", -1)
        bal_str = cells[bal_col] if bal_col >= 0 and bal_col < len(cells) else ""
        
        debit = None
        credit = None
        
        if layout == "B" or layout == "B_no_indicator":
            amt_col = col_map.get("amount", -1)
            amt_str = cells[amt_col] if amt_col >= 0 and amt_col < len(cells) else ""
            ind_col = col_map.get("indicator", -1)
            ind = cells[ind_col].upper() if ind_col >= 0 and ind_col < len(cells) else ""
            
            amt = parse_decimal(amt_str)
            if amt is not None:
                if "CR" in ind or ind == "C":
                    credit = abs(float(amt))
                elif "DR" in ind or ind == "D":
                    debit = abs(float(amt))
                elif amt < 0:
                    debit = abs(float(amt))
                else:
                    credit = float(amt)  # ambiguous - default to credit
        else:
            # Layout A or C: separate debit/credit
            deb_col = col_map.get("debit", -1)
            cred_col = col_map.get("credit", -1)

            deb_str = cells[deb_col] if deb_col >= 0 and deb_col < len(cells) else ""
            cred_str = cells[cred_col] if cred_col >= 0 and cred_col < len(cells) else ""

            # Check for embedded reference numbers placed in amount cells by table overflow
            for s in (deb_str, cred_str):
                ref_m = re.search(r'\b(\d{10,16})\b', s)
                if ref_m and not ref:
                    ref = ref_m.group(1)

            def _clean_amount_cell(val_str: str) -> Optional[Decimal]:
                if not val_str:
                    return None
                digits_only = re.sub(r'\D', '', val_str)
                if len(digits_only) >= 10 and '.' not in val_str:
                    return None
                parsed = parse_decimal(val_str)
                if parsed is not None:
                    return parsed
                found = re.findall(r'[\d,]+\.\d{2}', val_str)
                if found:
                    return parse_decimal(found[0])
                return None

            deb_val = _clean_amount_cell(deb_str)
            cred_val = _clean_amount_cell(cred_str)

            if deb_val is not None and abs(float(deb_val)) > 0:
                debit = abs(float(deb_val))
            if cred_val is not None and abs(float(cred_val)) > 0:
                credit = abs(float(cred_val))
        
        balance = None
        if bal_str:
            bal_val = parse_decimal(bal_str)
            if bal_val is not None:
                balance = abs(float(bal_val))
        
        return {
            "raw_date": raw_date,
            "transaction_date": None,  # Will be parsed after day_first inference
            "description": truncate_string(raw_desc, 500),
            "raw_description": truncate_string(raw_desc, 500),
            "reference": ref,
            "debit": debit,
            "credit": credit,
            "balance": balance,
            "raw_amount_text": "",
            "currency": "INR",
            "source_page": page_num,
            "extraction_method": "pdfplumber_table",
            "extraction_confidence": 90.0,
        }

    def _parse_text_lines(self, text: str, page_num: int) -> List[Dict]:
        """
        Fallback text-line parsing when no table structure is detected.
        Handles both vertical multi-line transaction layouts and single-line / OCR transactions.
        """
        transactions = []
        raw_lines = text.splitlines()

        # Skip synthetic marker lines and empty lines
        lines = [l.strip() for l in raw_lines if l.strip() and SYNTHETIC_MARKER not in l]
        if not lines:
            return []

        # Check for vertical multi-line layout:
        # Detected when there are multiple lines that match DATE_RE
        standalone_date_indices = [
            i for i, l in enumerate(lines)
            if DATE_RE.match(l)
        ]

        if len(standalone_date_indices) >= 2:
            # Parse vertical multi-line blocks
            blocks = []
            curr = []
            for l in lines:
                if DATE_RE.match(l):
                    # Check if this is a consecutive date line (e.g. Value Date right after Txn Date)
                    if curr and len(curr) == 1 and DATE_RE.match(curr[0]):
                        curr.append(l)
                    else:
                        if curr and any(DATE_RE.match(x) for x in curr):
                            blocks.append(curr)
                        curr = [l]
                elif curr:
                    curr.append(l)
            if curr and any(DATE_RE.match(x) for x in curr):
                blocks.append(curr)

            for block in blocks:
                txn = self._parse_vertical_block(block, page_num)
                if txn:
                    transactions.append(txn)
            return transactions

        # Single-line or OCR line parsing
        current_txn = None
        for line in lines:
            m = DATE_SEARCH_RE.search(line)
            if m:
                if current_txn:
                    transactions.append(current_txn)
                current_txn = self._parse_single_line(line, m, page_num)
            elif current_txn is not None:
                # Continuation description
                if any(c.isalpha() for c in line) and not _is_amount(line) and not self._is_footer_line(line):
                    current_txn["description"] = (current_txn.get("description", "") + " " + line).strip()
                    current_txn["raw_description"] = current_txn["description"]

        if current_txn:
            transactions.append(current_txn)

        return transactions

    def _parse_vertical_block(self, block: List[str], page_num: int) -> Optional[Dict]:
        """Parse a vertical multi-line transaction block into a transaction dictionary."""
        if not block:
            return None

        raw_date = block[0]
        idx = 1
        value_date = None
        if idx < len(block) and DATE_RE.match(block[idx]):
            value_date = block[idx]
            idx += 1

        tail = list(block[idx:])
        # Strip trailing page footers until we find an amount, dash, or DR/CR indicator
        amount_re = re.compile(r'^\s*[\d,]+\.\d{2}\s*$')
        while tail and not amount_re.match(tail[-1]) and tail[-1].upper() not in ('CR', 'DR') and tail[-1] != '-':
            tail.pop()

        if not tail:
            return None

        balance = None
        debit = None
        credit = None
        ref_no = None

        # Last element is balance if it matches amount pattern
        if amount_re.match(tail[-1]):
            bal_dec = parse_decimal(tail[-1])
            balance = abs(float(bal_dec)) if bal_dec else None
            tail = tail[:-1]

        # Check remaining tail
        if len(tail) >= 2 and tail[-1].upper() in ('CR', 'DR') and amount_re.match(tail[-2]):
            ind = tail[-1].upper()
            amt_dec = parse_decimal(tail[-2])
            amt = abs(float(amt_dec)) if amt_dec else 0.0
            if ind == 'CR':
                credit = amt
            else:
                debit = amt
            tail = tail[:-2]
        elif len(tail) >= 2 and (amount_re.match(tail[-1]) or tail[-1] == '-') and (amount_re.match(tail[-2]) or tail[-2] == '-'):
            if tail[-1] != '-':
                cr_dec = parse_decimal(tail[-1])
                credit = abs(float(cr_dec)) if cr_dec else None
            if tail[-2] != '-':
                dr_dec = parse_decimal(tail[-2])
                debit = abs(float(dr_dec)) if dr_dec else None
            tail = tail[:-2]
        elif len(tail) >= 1 and (amount_re.match(tail[-1]) or tail[-1] == '-'):
            if tail[-1] != '-':
                val_dec = parse_decimal(tail[-1])
                val = abs(float(val_dec)) if val_dec else None
                if val is not None:
                    # 1. Math continuity with previous running balance
                    last_bal = getattr(self, "_last_balance", None)
                    if balance is not None and last_bal is not None:
                        diff = round(balance - last_bal, 2)
                        if abs(abs(diff) - val) < 0.05:
                            if diff < 0:
                                debit = val
                            else:
                                credit = val
                    # 2. Keyword heuristic check
                    if debit is None and credit is None:
                        block_txt = " ".join(block).upper()
                        is_deb = any(k in block_txt for k in DEBIT_KEYWORDS)
                        is_cred = any(k in block_txt for k in CREDIT_KEYWORDS)
                        if is_deb and not is_cred:
                            debit = val
                        elif is_cred and not is_deb:
                            credit = val
                        elif 'DR' in block_txt or 'WDL' in block_txt or 'WITHDRAWAL' in block_txt:
                            debit = val
                        else:
                            debit = val
            tail = tail[:-1]

        # Ref number check: token of digits or dash right before amounts
        if tail and (re.match(r'^\d{6,14}$', tail[-1]) or tail[-1] == '-'):
            ref_no = tail[-1] if tail[-1] != '-' else None
            tail = tail[:-1]

        desc = " ".join(tail).strip()

        if balance is not None:
            self._last_balance = balance

        return {
            "raw_date": raw_date,
            "value_date": value_date,
            "transaction_date": None,
            "description": truncate_string(desc, 500),
            "raw_description": truncate_string(desc, 500),
            "reference": ref_no,
            "debit": debit,
            "credit": credit,
            "balance": balance,
            "raw_amount_text": "",
            "currency": "INR",
            "source_page": page_num,
            "extraction_method": "text_vertical_block",
            "extraction_confidence": 85.0,
        }

    def _parse_single_line(self, line: str, date_match, page_num: int) -> Dict:
        """Parse a single text line or OCR line containing a date and amounts."""
        raw_date = re.sub(r'\s+', '', date_match.group(1))
        after = line[date_match.end():].strip()
        after = re.sub(r'FinExtract Synthetic Test Pack.*$', '', after, flags=re.I).strip()
        after = re.sub(r'All transaction data.*$', '', after, flags=re.I).strip()

        amounts = re.findall(r'[\d,]+\.\d{2}', after)

        balance = None
        debit = None
        credit = None

        if len(amounts) >= 3:
            bal_dec = parse_decimal(amounts[-1])
            balance = abs(float(bal_dec)) if bal_dec else None
            cr_dec = parse_decimal(amounts[-2])
            credit = abs(float(cr_dec)) if cr_dec else None
            dr_dec = parse_decimal(amounts[-3])
            debit = abs(float(dr_dec)) if dr_dec else None
            first_amt = amounts[-3]
        elif len(amounts) == 2:
            bal_dec = parse_decimal(amounts[-1])
            balance = abs(float(bal_dec)) if bal_dec else None
            amt_str = amounts[0]
            first_amt = amt_str
            amt_dec = parse_decimal(amt_str)
            amt_val = abs(float(amt_dec)) if amt_dec else None

            up = after.upper()
            has_explicit_dr = bool(re.search(r'\b(DR|DEBIT)\b', up))
            has_explicit_cr = bool(re.search(r'\b(CR|CREDIT)\b', up))
            if has_explicit_dr and not has_explicit_cr:
                debit = amt_val
            elif has_explicit_cr and not has_explicit_dr:
                credit = amt_val
            else:
                last_bal = getattr(self, "_last_balance", None)
                if balance is not None and last_bal is not None and amt_val is not None:
                    diff = round(balance - last_bal, 2)
                    if abs(abs(diff) - amt_val) < 0.05:
                        if diff < 0:
                            debit = amt_val
                        else:
                            credit = amt_val

                if debit is None and credit is None:
                    idx = after.rfind(amt_str)
                    between = after[idx + len(amt_str): after.rfind(amounts[-1])]
                    before = after[:idx]
                    if '-' in between or '—' in between:
                        debit = amt_val
                    elif '-' in before or '—' in before or ':' in before:
                        credit = amt_val
                    else:
                        is_deb = any(k in up for k in DEBIT_KEYWORDS)
                        is_cred = any(k in up for k in CREDIT_KEYWORDS)
                        if is_cred and not is_deb:
                            credit = amt_val
                        else:
                            debit = amt_val

        if balance is not None:
            self._last_balance = balance
        elif len(amounts) == 1:
            val_dec = parse_decimal(amounts[0])
            val = abs(float(val_dec)) if val_dec else None
            first_amt = amounts[0]
            if 'DR' in line.upper() or 'WDL' in line.upper():
                debit = val
            else:
                credit = val
        else:
            first_amt = None

        if first_amt:
            desc_part = after[:after.find(first_amt)].strip()
        else:
            desc_part = after

        ref_m = re.search(r'[\s\-—:]+(\d{6,14})[\s\-—:]*$', desc_part)
        ref_no = None
        if ref_m:
            ref_no = ref_m.group(1)
            desc_part = desc_part[:ref_m.start()].strip()

        desc_part = re.sub(r'^[|\-—:\s]+', '', desc_part).strip()

        return {
            "raw_date": raw_date,
            "transaction_date": None,
            "description": truncate_string(desc_part or after, 500),
            "raw_description": truncate_string(desc_part or after, 500),
            "reference": ref_no,
            "debit": debit,
            "credit": credit,
            "balance": balance,
            "raw_amount_text": "",
            "currency": "INR",
            "source_page": page_num,
            "extraction_method": "text_single_line",
            "extraction_confidence": 75.0,
        }

    def _is_footer_line(self, line: str) -> bool:
        """Check if a line looks like statement footer/disclaimer text."""
        lower = line.lower()
        return any(x in lower for x in [
            "finextract synthetic",
            "fictional test data",
            "not issued by",
            "page ",
            "opening balance",
            "closing balance",
            "total debits",
            "total credits"
        ])

    def _parse_transaction_line(self, line: str, page_num: int) -> Dict:
        """Legacy single-line transaction parser compatibility."""
        m = re.search(r'(?:\b|^)(\d{1,2}\s*[-/]\s*\d{1,2}\s*[-/]\s*\d{2,4})(?:\b|$)', line)
        if m:
            return self._parse_single_line(line, m, page_num)
        return {
            "raw_date": "",
            "transaction_date": None,
            "description": line,
            "raw_description": line,
            "debit": None,
            "credit": None,
            "balance": None,
            "raw_amount_text": "",
            "currency": "INR",
            "source_page": page_num,
            "extraction_method": "text_line_heuristic",
            "extraction_confidence": 60.0,
        }
