"""Detects which bank a statement belongs to."""
import re
import logging
from typing import Optional, Type

from src.parsers.base_parser import BaseParser

logger = logging.getLogger("finextract.bank_detector")

# Registry of parsers - add new parsers here
_PARSER_REGISTRY = {}


def register_parser(parser_class: Type[BaseParser]):
    """Register a parser class in the global registry."""
    _PARSER_REGISTRY[parser_class.name] = parser_class
    return parser_class


def detect_bank(text: str) -> Optional[BaseParser]:
    """
    Detect which bank parser should handle this statement.
    Returns an instantiated parser (most specific named bank match first, generic fallback last).
    """
    # Import parsers to trigger registration
    _ensure_parsers_registered()

    # Named bank parsers MUST always be tested before generic fallback
    named_parsers = [
        cls for name, cls in _PARSER_REGISTRY.items()
        if name != "generic"
    ]
    # Verified named parsers first
    named_parsers.sort(key=lambda p: (not getattr(p, "verified", False), p.name))

    matched_parsers = []
    for parser_class in named_parsers:
        try:
            parser = parser_class()
            if parser.detect(text):
                matched_parsers.append(parser)
        except Exception as e:
            logger.debug(f"Parser {parser_class.name} detection failed: {e}")

    if len(matched_parsers) > 1:
        from src.parsers.generic_parser import GenericParser
        logger.info(f"Multiple bank headers detected ({[p.bank_name for p in matched_parsers]}), using generic multi-bank parser.")
        gp = GenericParser()
        gp.bank_name = "Multi-Bank Statement"
        return gp

    if len(matched_parsers) == 1:
        logger.info(f"Detected bank parser: {matched_parsers[0].name} (bank={matched_parsers[0].bank_name})")
        return matched_parsers[0]

    # Fall back to generic
    from src.parsers.generic_parser import GenericParser
    logger.info("No specific bank detected, using generic parser.")
    return GenericParser()


def _ensure_parsers_registered():
    """Import all parsers to trigger their registration decorators."""
    try:
        import src.parsers.hdfc_parser
        import src.parsers.icici_parser
        import src.parsers.sbi_parser
        import src.parsers.axis_parser
        import src.parsers.generic_parser
    except Exception as e:
        logger.debug(f"Parser import warning: {e}")
