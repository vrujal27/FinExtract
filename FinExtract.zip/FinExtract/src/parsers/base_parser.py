"""Base parser interface for FinExtract bank statement parsers."""
import re
from abc import ABC, abstractmethod
from typing import Dict, List, Optional
from datetime import datetime


class BaseParser(ABC):
    """Abstract base class for all bank statement parsers."""
    
    name: str = "base"
    bank_name: str = "Unknown"
    verified: bool = False  # True only if tested against real/representative samples
    
    @abstractmethod
    def detect(self, text: str) -> bool:
        """Return True if this parser can handle the given text."""
        raise NotImplementedError
    
    @abstractmethod
    def parse_account(self, text: str) -> Dict:
        """Extract account metadata from statement text."""
        raise NotImplementedError
    
    @abstractmethod
    def parse_transactions(self, pages: List[Dict]) -> List[Dict]:
        """Extract transactions from page data list."""
        raise NotImplementedError
    
    def parse(self, pages: List[Dict]) -> Dict:
        """Full parse: account info + transactions."""
        full_text = "\n".join(p.get("text", "") for p in pages)
        account_info = self.parse_account(full_text)
        transactions = self.parse_transactions(pages)
        return {
            "bank_name": self.bank_name,
            "parser": self.name,
            "verified": self.verified,
            "account_info": account_info,
            "transactions": transactions,
        }
    
    def _extract_account_number(self, text: str) -> str:
        """Extract account number from text."""
        patterns = [
            r'(?:Account\s+(?:No|Number|#)\s*[:\-]?\s*)(\d[\d\s\-]{6,18}\d)',
            r'(?:A/C\s+(?:No|Number)?\s*[:\-]?\s*)(\d[\d\s\-]{6,18}\d)',
            r'(?:Acct\.?\s+(?:No|Number)?\s*[:\-]?\s*)(\d[\d\s\-]{6,18}\d)',
        ]
        for p in patterns:
            m = re.search(p, text, re.IGNORECASE)
            if m:
                return re.sub(r'\s+', '', m.group(1))
        return ""
    
    def _extract_ifsc(self, text: str) -> str:
        """Extract IFSC code."""
        m = re.search(r'\b([A-Z]{4}0[A-Z0-9]{6})\b', text)
        return m.group(1) if m else ""
    
    def _extract_account_holder(self, text: str) -> str:
        """Extract account holder name."""
        patterns = [
            r'(?:Account\s+Holder(?:\s+Name)?|Customer\s+Name)\s*[:\-]\s*([A-Za-z][A-Za-z \t\.]{1,50})',
            r'(?:Dear|MR\.|MRS\.|MS\.)\s+([A-Za-z][A-Za-z \t\.]{1,40})',
            r'\bName\s*[:\-]\s*([A-Za-z][A-Za-z \t\.]{1,50})',
        ]
        for p in patterns:
            m = re.search(p, text, re.IGNORECASE)
            if m:
                raw_name = m.group(1).splitlines()[0].strip()
                raw_name = re.sub(r'\s+(?:Account|A/C|No|Number|IFSC|Branch|Date|Rs|INR)\b.*$', '', raw_name, flags=re.IGNORECASE).strip()
                if len(raw_name) >= 2:
                    return raw_name
        return ""
    
    def _extract_statement_period(self, text: str) -> tuple:
        """Extract statement period (start, end) dates."""
        patterns = [
            r'(?:From|Period)\s*[:\-]?\s*(\d{1,2}[-/]\d{1,2}[-/]\d{2,4})\s+(?:To)\s*[:\-]?\s*(\d{1,2}[-/]\d{1,2}[-/]\d{2,4})',
            r'(?:Statement\s+Period\s*[:\-]?\s*)(\d{1,2}[-/]\d{1,2}[-/]\d{2,4})\s+(?:to|-)\s+(\d{1,2}[-/]\d{1,2}[-/]\d{2,4})',
        ]
        for p in patterns:
            m = re.search(p, text, re.IGNORECASE)
            if m:
                from src.utils.helpers import parse_date
                start = parse_date(m.group(1))
                end = parse_date(m.group(2))
                return start, end
        return None, None
    
    def _extract_opening_balance(self, text: str) -> Optional[float]:
        """Extract opening balance."""
        patterns = [
            r'(?:Opening|Open)\s+Balance\s*[:\-]?\s*(?:Rs\.?|INR|₹)?\s*([\d,]+\.?\d*)',
            r'(?:Balance\s+Brought\s+Forward|B/F)\s*[:\-]?\s*(?:Rs\.?|INR|₹)?\s*([\d,]+\.?\d*)',
        ]
        from src.utils.helpers import parse_decimal
        for p in patterns:
            m = re.search(p, text, re.IGNORECASE)
            if m:
                val = parse_decimal(m.group(1))
                return float(val) if val is not None else None
        return None
    
    def _extract_closing_balance(self, text: str) -> Optional[float]:
        """Extract closing balance."""
        patterns = [
            r'(?:Closing|Close)\s+Balance\s*[:\-]?\s*(?:Rs\.?|INR|₹)?\s*([\d,]+\.?\d*)',
            r'(?:Balance\s+Carried\s+Forward|C/F)\s*[:\-]?\s*(?:Rs\.?|INR|₹)?\s*([\d,]+\.?\d*)',
        ]
        from src.utils.helpers import parse_decimal
        for p in patterns:
            m = re.search(p, text, re.IGNORECASE)
            if m:
                val = parse_decimal(m.group(1))
                return float(val) if val is not None else None
        return None
