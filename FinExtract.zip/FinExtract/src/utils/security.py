"""Security utilities for FinExtract."""
import os
import re
import tempfile
import uuid
from pathlib import Path
from typing import Optional


def safe_temp_file(suffix: str = ".pdf") -> str:
    """Create a safe temporary file path (not using user-supplied names)."""
    temp_dir = tempfile.gettempdir()
    safe_name = f"finextract_{uuid.uuid4().hex}{suffix}"
    return os.path.join(temp_dir, safe_name)


def sanitize_query_string(value: str, max_length: int = 200) -> str:
    """Sanitize a string for use in MongoDB queries."""
    if not value:
        return ""
    # Strip control characters
    value = re.sub(r'[\x00-\x1f\x7f]', '', value)
    return value[:max_length]


def escape_regex(value: str) -> str:
    """Escape special regex characters for safe regex queries."""
    return re.escape(value)


def mask_uri(uri: str) -> str:
    """Mask credentials in a MongoDB URI for safe logging."""
    return re.sub(r'(mongodb://[^:]+:)[^@]+(@)', r'\1****\2', uri)
