"""Utility helpers for FinExtract."""
import hashlib
import re
import uuid
from datetime import datetime
from decimal import Decimal, InvalidOperation
from typing import Optional


def generate_job_id() -> str:
    """Generate a unique job ID."""
    return f"JOB-{uuid.uuid4().hex[:12].upper()}"


def generate_transaction_id(job_id: str, index: int) -> str:
    """Generate a deterministic transaction ID."""
    return f"TXN-{job_id}-{index:05d}"


def generate_file_hash(file_bytes: bytes) -> str:
    """Generate SHA-256 hash of file bytes."""
    return hashlib.sha256(file_bytes).hexdigest()


def generate_transaction_fingerprint(
    account_id: str, date: str, amount_str: str, balance_str: str,
    description: str, occurrence_index: int = 0
) -> str:
    """Generate a deterministic fingerprint for duplicate detection."""
    raw = f"{account_id}|{date}|{amount_str}|{balance_str}|{description}|{occurrence_index}"
    return hashlib.sha256(raw.encode()).hexdigest()


def mask_account_number(account_number: str) -> str:
    """Mask account number showing only last 4 digits."""
    if not account_number:
        return ""
    cleaned = re.sub(r'[^0-9X]', '', account_number.upper())
    if len(cleaned) <= 4:
        return cleaned
    return "X" * (len(cleaned) - 4) + cleaned[-4:]


def parse_decimal(value_str: str) -> Optional[Decimal]:
    """Parse Indian number format to Decimal."""
    if not value_str:
        return None
    cleaned = str(value_str).strip()
    if not cleaned:
        return None
    # Remove currency words and symbols
    cleaned = re.sub(r'\b(INR|Rs)\b\.?', '', cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r'[₹$]', '', cleaned).strip()

    # Handle DR/CR notation
    is_negative = False
    if cleaned.upper().endswith('DR'):
        is_negative = True
        cleaned = cleaned[:-2].strip()
    elif cleaned.upper().endswith('CR'):
        cleaned = cleaned[:-2].strip()

    # Handle parentheses as negative
    if cleaned.startswith('(') and cleaned.endswith(')'):
        is_negative = True
        cleaned = cleaned[1:-1].strip()
    elif cleaned.startswith('-'):
        is_negative = True
        cleaned = cleaned[1:].strip()

    # Remove commas and remaining spaces
    cleaned = cleaned.replace(',', '').replace(' ', '')
    if not cleaned:
        return None

    # Guard: A 10+ digit contiguous integer without decimal point is a reference number / UTR / timestamp, not money
    if cleaned.isdigit() and len(cleaned) >= 10:
        return None

    try:
        value = Decimal(cleaned)
        return -value if is_negative else value
    except InvalidOperation:
        return None


def normalize_description(description: str) -> str:
    """Normalize transaction description for classification."""
    if not description:
        return ""
    text = description.upper().strip()
    # Remove UPI/NEFT/IMPS/RTGS prefixes (payment method, not purpose)
    text = re.sub(r'^(UPI|NEFT|IMPS|RTGS|NACH|ECS|ENACH)\s*[-/]?\s*', '', text)
    # Remove reference numbers (long digit sequences)
    text = re.sub(r'\b\d{8,}\b', '', text)
    # Remove common noise
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


def parse_date(date_str: str, day_first: bool = True) -> Optional[datetime]:
    """Parse date string with multiple format support."""
    if not date_str:
        return None
    date_str = str(date_str).strip()
    formats = []
    if day_first:
        formats = [
            '%d/%m/%Y', '%d-%m-%Y', '%d/%m/%y', '%d-%m-%y',
            '%d-%b-%Y', '%d-%b-%y', '%d %b %Y', '%d %b %y',
            '%d/%b/%Y', '%Y-%m-%d', '%m/%d/%Y', '%m-%d-%Y',
        ]
    else:
        formats = [
            '%m/%d/%Y', '%m-%d-%Y', '%Y-%m-%d',
            '%d/%m/%Y', '%d-%m-%Y', '%d-%b-%Y', '%d-%b-%y',
        ]
    for fmt in formats:
        try:
            return datetime.strptime(date_str, fmt)
        except ValueError:
            continue
    return None


def infer_day_first(date_strings: list) -> bool:
    """Infer whether dates are day-first by looking for days > 12."""
    for ds in date_strings:
        if not ds:
            continue
        parts = re.split(r'[-/]', str(ds).strip())
        if len(parts) >= 2:
            try:
                first = int(parts[0])
                second = int(parts[1])
                if first > 12:
                    return True  # day-first confirmed
                if second > 12:
                    return False  # month-first confirmed
            except ValueError:
                continue
    return True  # default to day-first (India standard)


def safe_float(value) -> Optional[float]:
    """Safely convert to float."""
    try:
        if value is None:
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def truncate_string(s: str, max_len: int = 200) -> str:
    """Truncate string to max length."""
    if not s:
        return ""
    return s[:max_len] if len(s) > max_len else s
