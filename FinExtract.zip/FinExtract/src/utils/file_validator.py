"""File validation utilities."""
import io
from pathlib import Path
from typing import Tuple

from src.config import MAX_UPLOAD_BYTES, MAX_PAGES


def validate_pdf_file(file_bytes: bytes, filename: str) -> Tuple[bool, str]:
    """Validate a PDF file. Returns (is_valid, error_message)."""
    if not filename.lower().endswith('.pdf'):
        return False, f"File '{filename}' must have a .pdf extension."

    if len(file_bytes) == 0:
        return False, f"File '{filename}' is empty."

    if len(file_bytes) > MAX_UPLOAD_BYTES:
        mb = len(file_bytes) / (1024 * 1024)
        return False, f"File '{filename}' ({mb:.1f} MB) exceeds the {MAX_UPLOAD_BYTES // (1024*1024)} MB limit."

    # Check PDF magic bytes
    if not file_bytes.startswith(b'%PDF'):
        return False, f"File '{filename}' does not appear to be a valid PDF (bad magic bytes)."

    # Try opening with PyMuPDF
    try:
        import fitz
        doc = fitz.open(stream=file_bytes, filetype="pdf")
        if doc.is_encrypted:
            doc.close()
            return False, f"File '{filename}' is password-protected. Please provide an unprotected PDF."
        page_count = len(doc)
        doc.close()
        if page_count == 0:
            return False, f"File '{filename}' has no pages."
        if page_count > MAX_PAGES:
            return False, f"File '{filename}' has {page_count} pages, exceeding the {MAX_PAGES}-page limit."
    except Exception as e:
        return False, f"File '{filename}' could not be opened: {str(e)}"

    return True, ""
