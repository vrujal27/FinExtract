"""Duplicate transaction detection for FinExtract."""
import logging
from typing import Dict, List, Set, Tuple

logger = logging.getLogger("finextract.deduplicator")


def detect_duplicates(transactions: List[Dict]) -> Tuple[List[Dict], List[Dict]]:
    """
    Detect possible duplicate transactions within a set.
    Does NOT auto-delete; flags for review.
    
    Returns:
        (transactions_with_flags, duplicate_issues)
    """
    seen_fingerprints: Dict[str, int] = {}  # fingerprint -> first index
    issues = []
    
    for i, txn in enumerate(transactions):
        fp = txn.get("fingerprint", "")
        if not fp:
            continue
        
        if fp in seen_fingerprints:
            first_idx = seen_fingerprints[fp]
            first_txn = transactions[first_idx]
            
            # Flag both as possible duplicates
            txn["possible_duplicate"] = True
            txn["duplicate_of"] = first_txn.get("transaction_id")
            first_txn["possible_duplicate"] = True
            
            issues.append({
                "type": "POSSIBLE_DUPLICATE",
                "description": (
                    f"Transaction {txn.get('transaction_id')} may be a duplicate of "
                    f"{first_txn.get('transaction_id')} "
                    f"(same date/amount/description)."
                ),
                "severity": "WARNING",
                "transaction_id": txn.get("transaction_id"),
                "duplicate_of": first_txn.get("transaction_id"),
            })
        else:
            seen_fingerprints[fp] = i
            txn.setdefault("possible_duplicate", False)
    
    return transactions, issues
