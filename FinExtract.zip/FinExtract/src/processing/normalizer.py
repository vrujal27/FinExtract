"""Transaction normalization for FinExtract."""
import hashlib
import logging
import re
import uuid
from datetime import datetime
from decimal import Decimal
from typing import Dict, List, Optional

from src.utils.helpers import (
    parse_decimal, parse_date, infer_day_first,
    mask_account_number, generate_transaction_id, truncate_string
)
from src.config import DEFAULT_CURRENCY

logger = logging.getLogger("finextract.normalizer")


def normalize_transaction(
    raw_txn: Dict, job_id: str, account_id: str, row_index: int,
    day_first: bool = True, ocr_confidence: float = 100.0
) -> Dict:
    """
    Normalize a raw parsed transaction into the standard structure.
    """
    txn_id = generate_transaction_id(job_id, row_index)
    
    # Date
    raw_date = raw_txn.get("raw_date", "")
    tx_date = raw_txn.get("transaction_date")
    if tx_date is None and raw_date:
        tx_date = parse_date(raw_date, day_first=day_first)
    
    # Amounts - keep as float for MongoDB storage (Decimal128 handled at DB layer)
    debit = raw_txn.get("debit")
    credit = raw_txn.get("credit")
    balance = raw_txn.get("balance")
    
    if isinstance(debit, str):
        d = parse_decimal(debit)
        debit = abs(float(d)) if d is not None else None
    if isinstance(credit, str):
        c = parse_decimal(credit)
        credit = abs(float(c)) if c is not None else None
    if isinstance(balance, str):
        b = parse_decimal(balance)
        balance = abs(float(b)) if b is not None else None
    
    description = truncate_string(str(raw_txn.get("description", "") or "").strip(), 500)
    raw_description = truncate_string(str(raw_txn.get("raw_description", description) or "").strip(), 500)
    
    # Extraction method and confidence
    extraction_method = raw_txn.get("extraction_method", "text")
    extraction_confidence = raw_txn.get("extraction_confidence", ocr_confidence)
    
    # Determine validation status
    validation_status = "PENDING"
    review_required = True
    
    # Basic quality checks
    has_date = tx_date is not None
    has_amounts = (debit is not None and debit > 0) or (credit is not None and credit > 0)
    has_description = bool(description)
    
    if not has_date or not has_amounts:
        validation_status = "INCOMPLETE"
        review_required = True
    
    if extraction_confidence < 60:
        review_required = True
    
    # Fingerprint for duplicate detection
    amount_str = f"{debit or 0:.2f}_{credit or 0:.2f}"
    balance_str = f"{balance or 0:.2f}"
    date_str = tx_date.strftime("%Y-%m-%d") if tx_date else raw_date
    fingerprint = hashlib.sha256(
        f"{account_id}|{date_str}|{amount_str}|{balance_str}|{description}|{row_index}".encode()
    ).hexdigest()
    
    return {
        "transaction_id": txn_id,
        "job_id": job_id,
        "account_id": account_id,
        "row_index": row_index,
        
        "transaction_date": tx_date,
        "raw_date": raw_date,
        
        "description": description,
        "raw_description": raw_description,
        
        "debit": debit,
        "credit": credit,
        "balance": balance,
        "raw_amount_text": raw_txn.get("raw_amount_text", ""),
        "currency": raw_txn.get("currency", DEFAULT_CURRENCY),
        "reference": raw_txn.get("reference", ""),
        
        "category": "Unclassified",
        "predicted_category": "Unclassified",
        "classification_method": "",
        "ml_confidence": None,
        "rule_id": None,
        "rule_match_strength": None,
        
        "review_required": review_required,
        "validation_status": validation_status,
        
        "extraction_method": extraction_method,
        "extraction_confidence": extraction_confidence,
        "source_page": raw_txn.get("source_page", 1),
        
        "fingerprint": fingerprint,
        
        "created_at": None,
        "updated_at": None,
    }


def normalize_transactions(
    raw_transactions: List[Dict], job_id: str, account_id: str,
    day_first: bool = True, ocr_confidence: float = 100.0
) -> List[Dict]:
    """Normalize a list of raw transactions."""
    normalized = []
    for i, raw in enumerate(raw_transactions):
        try:
            txn = normalize_transaction(raw, job_id, account_id, i, day_first, ocr_confidence)
            normalized.append(txn)
        except Exception as e:
            logger.warning(f"Failed to normalize transaction {i}: {e}")
    return normalized
