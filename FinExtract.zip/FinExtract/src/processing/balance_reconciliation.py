"""Balance reconciliation engine for FinExtract."""
import logging
from decimal import Decimal
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger("finextract.reconciliation")

BALANCE_TOLERANCE = 0.01


def reconcile_balances(
    transactions: List[Dict],
    opening_balance: Optional[float] = None,
    tolerance: float = BALANCE_TOLERANCE,
) -> Dict:
    """
    Validate that balance = previous_balance + credit - debit for each transaction.
    
    Returns:
        {
            "status": "PASSED" | "FAILED" | "INCONCLUSIVE" | "WARNING",
            "total_checked": int,
            "matched": int,
            "mismatched": int,
            "issues": [...],
            "opening_balance": float or None,
        }
    """
    result = {
        "status": "INCONCLUSIVE",
        "total_checked": 0,
        "matched": 0,
        "mismatched": 0,
        "issues": [],
        "opening_balance": opening_balance,
    }
    
    # Filter to transactions with balance
    checkable = [t for t in transactions if t.get("balance") is not None]
    result["total_checked"] = len(checkable)
    
    if not checkable:
        result["status"] = "INCONCLUSIVE"
        result["issues"].append({
            "type": "NO_BALANCE_DATA",
            "description": "No transactions with balance data available for reconciliation.",
            "severity": "INFO",
        })
        return result
    
    # Try to determine optimal chronological order
    # Test: document order, reverse document order, forward date sorted, reverse date sorted
    doc_matches = _check_sequence(checkable, opening_balance, tolerance)
    rev_matches = _check_sequence(list(reversed(checkable)), opening_balance, tolerance)
    
    with_dates = [t for t in checkable if t.get("transaction_date") is not None]
    fwd_matches = _check_sequence(sorted(with_dates, key=lambda t: t["transaction_date"]), opening_balance, tolerance) if with_dates else -1
    rev_date_matches = _check_sequence(sorted(with_dates, key=lambda t: t["transaction_date"], reverse=True), opening_balance, tolerance) if with_dates else -1

    best_score = max(doc_matches, rev_matches, fwd_matches, rev_date_matches)
    if best_score == doc_matches:
        ordered = checkable
    elif best_score == rev_matches:
        ordered = list(reversed(checkable))
    elif best_score == fwd_matches:
        ordered = sorted(with_dates, key=lambda t: t["transaction_date"])
    else:
        ordered = sorted(with_dates, key=lambda t: t["transaction_date"], reverse=True)
    
    # Perform reconciliation
    if opening_balance is None:
        # Infer opening balance from first transaction
        first = ordered[0]
        first_bal = first.get("balance", 0) or 0
        first_credit = first.get("credit", 0) or 0
        first_debit = first.get("debit", 0) or 0
        inferred_opening = first_bal - first_credit + first_debit
        result["opening_balance"] = round(inferred_opening, 2)
        result["issues"].append({
            "type": "OPENING_BALANCE_INFERRED",
            "description": f"Opening balance not provided. Inferred as {inferred_opening:.2f} from first transaction.",
            "severity": "INFO",
        })
        prev_balance = inferred_opening
    else:
        prev_balance = opening_balance
    
    for txn in ordered:
        credit = txn.get("credit") or 0
        debit = txn.get("debit") or 0
        actual_balance = txn.get("balance")
        
        expected_balance = prev_balance + credit - debit
        
        if actual_balance is not None:
            diff = abs(expected_balance - actual_balance)
            if diff <= tolerance:
                result["matched"] += 1
                txn["reconciliation_status"] = "MATCHED"
            else:
                result["mismatched"] += 1
                txn["reconciliation_status"] = "MISMATCH"
                result["issues"].append({
                    "type": "BALANCE_MISMATCH",
                    "description": f"Balance mismatch on transaction {txn.get('transaction_id', '?')}",
                    "severity": "WARNING",
                    "expected": round(expected_balance, 2),
                    "actual": round(actual_balance, 2),
                    "difference": round(diff, 2),
                    "transaction_id": txn.get("transaction_id"),
                })
            prev_balance = actual_balance  # Use actual for next iteration
        else:
            prev_balance = expected_balance
    
    # Determine overall status
    total = result["matched"] + result["mismatched"]
    if total == 0:
        result["status"] = "INCONCLUSIVE"
    elif result["mismatched"] == 0:
        result["status"] = "PASSED"
    elif result["matched"] > result["mismatched"]:
        result["status"] = "WARNING"
    else:
        result["status"] = "FAILED"
    
    return result


def _check_sequence(
    transactions: List[Dict], opening_balance: Optional[float], tolerance: float
) -> int:
    """Count how many consecutive balance checks pass in this sequence."""
    if not transactions:
        return 0
    
    if opening_balance is None:
        first = transactions[0]
        prev = (first.get("balance", 0) or 0) - (first.get("credit", 0) or 0) + (first.get("debit", 0) or 0)
    else:
        prev = opening_balance
    
    matches = 0
    for txn in transactions:
        credit = txn.get("credit") or 0
        debit = txn.get("debit") or 0
        actual = txn.get("balance")
        expected = prev + credit - debit
        if actual is not None and abs(expected - actual) <= tolerance:
            matches += 1
        prev = actual if actual is not None else expected
    
    return matches
