"""Main transaction processing orchestrator for FinExtract."""
import logging
import uuid
from datetime import datetime
from typing import Dict, List, Optional, Tuple

from src.processing.normalizer import normalize_transactions
from src.processing.validator import validate_transactions
from src.processing.balance_reconciliation import reconcile_balances
from src.processing.deduplicator import detect_duplicates
from src.classification.hybrid_classifier import classify_transactions_batch
from src.parsers.bank_detector import detect_bank
from src.extraction.extraction_manager import extract_pdf
from src.utils.helpers import generate_job_id, generate_file_hash, infer_day_first

logger = logging.getLogger("finextract.transaction_processor")


def process_statement(
    file_bytes: bytes, filename: str, job_id: str = None, progress_callback=None
) -> Dict:
    """
    Full end-to-end processing pipeline for a bank statement PDF.
    
    Returns:
        {
            "job_id": str,
            "success": bool,
            "error": str or None,
            "detection": {...},
            "account_info": {...},
            "transactions": [...],
            "validation_issues": [...],
            "reconciliation": {...},
            "warnings": [...],
            "stats": {...},
        }
    """
    if job_id is None:
        job_id = generate_job_id()
    
    file_hash = generate_file_hash(file_bytes)
    
    result = {
        "job_id": job_id,
        "file_hash": file_hash,
        "filename": filename,
        "success": False,
        "error": None,
        "detection": {},
        "account_info": {},
        "account_id": "",
        "transactions": [],
        "validation_issues": [],
        "reconciliation": {},
        "warnings": [],
        "stats": {},
        "processing_duration": 0.0,
    }
    
    start_time = datetime.utcnow()
    
    try:
        # Step 1: Extract
        logger.info(f"[{job_id}] Starting extraction for {filename}")
        if progress_callback:
            progress_callback(10, f"Starting extraction for {filename}...")
        extraction = extract_pdf(file_bytes, filename, progress_callback=progress_callback)
        result["detection"] = extraction.get("detection", {})
        result["warnings"].extend(extraction.get("warnings", []))
        
        if not extraction.get("success"):
            result["error"] = extraction.get("error", "Extraction failed.")
            return result
        
        pages = extraction.get("pages", [])
        
        if not pages:
            result["error"] = "No pages could be extracted from the PDF."
            return result
        
        # Step 2: Parse (bank detection + transaction extraction)
        logger.info(f"[{job_id}] Parsing extracted content...")
        if progress_callback:
            progress_callback(60, "Identifying bank format and parsing transactions...")
        full_text = extraction.get("full_text", "")
        parser = detect_bank(full_text)
        
        parse_result = parser.parse(pages)
        account_info = parse_result.get("account_info", {})
        raw_transactions = parse_result.get("transactions", [])
        
        result["account_info"] = account_info
        
        # Generate account_id
        bank = account_info.get("bank_name", "Unknown")
        acct_masked = account_info.get("account_number_masked", "")
        account_id = f"ACC-{generate_file_hash((bank + acct_masked).encode())[:12].upper()}"
        result["account_id"] = account_id
        
        if not raw_transactions:
            result["error"] = "No transactions could be extracted from the statement."
            result["success"] = True  # Not a fatal error - just empty
            result["warnings"].append("No transactions found. The PDF may use an unsupported layout.")
            return result
        
        logger.info(f"[{job_id}] Extracted {len(raw_transactions)} raw transactions")
        
        # Step 3: Infer date format
        all_raw_dates = [t.get("raw_date", "") for t in raw_transactions]
        day_first = infer_day_first(all_raw_dates)
        
        # Step 4: Normalize
        if progress_callback:
            progress_callback(75, f"Normalizing {len(raw_transactions)} transactions...")
        avg_confidence = sum(
            p.get("confidence", 100) for p in pages
        ) / max(len(pages), 1)
        
        normalized = normalize_transactions(
            raw_transactions, job_id, account_id,
            day_first=day_first,
            ocr_confidence=avg_confidence
        )
        
        # Step 5: Classify
        logger.info(f"[{job_id}] Classifying transactions...")
        if progress_callback:
            progress_callback(85, f"Categorizing {len(normalized)} transactions...")
        classified = classify_transactions_batch(normalized)
        
        # Step 6: Validate
        logger.info(f"[{job_id}] Validating transactions...")
        if progress_callback:
            progress_callback(92, "Validating business rules...")
        validated, validation_issues = validate_transactions(classified)
        
        # Step 7: Detect duplicates
        deduplicated, dup_issues = detect_duplicates(validated)
        all_issues = validation_issues + [
            {**issue, "transaction_id": issue.get("transaction_id", ""), "job_id": job_id}
            for issue in dup_issues
        ]
        
        # Add job_id to all issues
        for issue in all_issues:
            issue.setdefault("job_id", job_id)
        
        # Step 8: Reconcile balances
        logger.info(f"[{job_id}] Reconciling balances...")
        if progress_callback:
            progress_callback(97, "Reconciling running balances...")
        opening_balance = account_info.get("opening_balance")
        reconciliation = reconcile_balances(deduplicated, opening_balance)

        # Merge reconciliation issues (mismatches, continuity breaks) into validation issues
        import uuid
        for rec_issue in reconciliation.get("issues", []):
            if rec_issue.get("severity") in ("ERROR", "WARNING"):
                all_issues.append({
                    "issue_id": f"ISSUE-REC-{uuid.uuid4().hex[:8].upper()}",
                    "job_id": job_id,
                    "transaction_id": rec_issue.get("transaction_id", ""),
                    "issue_type": rec_issue.get("type", "BALANCE_MISMATCH"),
                    "severity": rec_issue.get("severity", "WARNING"),
                    "description": rec_issue.get("description", "Balance reconciliation continuity mismatch"),
                    "expected_value": str(rec_issue.get("expected", "")),
                    "actual_value": str(rec_issue.get("actual", "")),
                })

        result["transactions"] = deduplicated
        result["validation_issues"] = all_issues
        result["reconciliation"] = reconciliation
        
        end_time = datetime.utcnow()
        duration = (end_time - start_time).total_seconds()
        result["processing_duration"] = duration
        
        # Stats
        result["stats"] = {
            "total_transactions": len(deduplicated),
            "review_required": sum(1 for t in deduplicated if t.get("review_required")),
            "unclassified": sum(1 for t in deduplicated if t.get("category") == "Unclassified"),
            "rule_based": sum(1 for t in deduplicated if t.get("classification_method") == "RULE_BASED"),
            "ml_classified": sum(1 for t in deduplicated if t.get("classification_method") == "MACHINE_LEARNING"),
            "validation_errors": sum(1 for i in all_issues if i.get("severity") == "ERROR"),
            "validation_warnings": sum(1 for i in all_issues if i.get("severity") == "WARNING"),
            "possible_duplicates": sum(1 for t in deduplicated if t.get("possible_duplicate")),
            "reconciliation_status": reconciliation.get("status", "INCONCLUSIVE"),
            "processing_duration_seconds": duration,
            "bank_name": parse_result.get("bank_name", "Unknown"),
            "parser": parse_result.get("parser", "generic"),
            "pdf_type": result["detection"].get("pdf_type", "unknown"),
        }
        
        result["success"] = True
        logger.info(f"[{job_id}] Processing complete: {len(deduplicated)} transactions")
        
    except Exception as e:
        logger.exception(f"[{job_id}] Processing failed: {e}")
        result["error"] = str(e)
    
    return result
