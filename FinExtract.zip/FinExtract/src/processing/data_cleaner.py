"""Data cleaning utilities for raw statement text and extracted rows."""
import re
from typing import Dict, List, Optional


def clean_text_line(line: str) -> str:
    """Clean extra spaces, non-printable characters, and trim."""
    if not line:
        return ""
    # Strip control characters except newline and tab
    cleaned = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', line)
    # Collapse multiple whitespace
    cleaned = re.sub(r'[ \t]+', ' ', cleaned)
    return cleaned.strip()


def remove_noise_lines(lines: List[str]) -> List[str]:
    """Remove header/footer boilerplate and synthetic markers."""
    clean_lines = []
    for line in lines:
        s = line.strip()
        if not s:
            continue
        if "SYNTHETIC SAMPLE" in s:
            continue
        if re.match(r'^(page\s+\d+(\s+of\s+\d+)?|\d+/\d+)$', s, re.IGNORECASE):
            continue
        clean_lines.append(s)
    return clean_lines


def clean_description(desc: str) -> str:
    """Clean messy narration text while preserving key transaction info."""
    if not desc:
        return ""
    # Replace line breaks with spaces
    d = desc.replace('\r', ' ').replace('\n', ' ')
    d = re.sub(r'\s+', ' ', d)
    return d.strip()

