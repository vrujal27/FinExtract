"""Financial validation engine for FinExtract."""
import logging
import uuid
from datetime import datetime
from decimal import Decimal
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger("finextract.validator")

BALANCE_TOLERANCE = 0.01


def validate_transaction(txn: Dict) -> List[Dict]:
    """
    Validate a single transaction and return list of issues found.
    Each issue: {issue_type, description, severity, expected_value, actual_value}
    """
    issues = []
    
    # Required fields
    if not txn.get("transaction_date"):
        issues.append({
            "issue_type": "MISSING_DATE",
            "description": "Transaction date is missing or could not be parsed.",
            "severity": "ERROR",
            "expected_value": "Valid date",
            "actual_value": txn.get("raw_date", ""),
        })
    
    if not txn.get("description"):
        issues.append({
            "issue_type": "MISSING_DESCRIPTION",
            "description": "Transaction description is empty.",
            "severity": "WARNING",
            "expected_value": "Non-empty description",
            "actual_value": "",
        })
    
    debit = txn.get("debit")
    credit = txn.get("credit")
    
    if debit is None and credit is None:
        issues.append({
            "issue_type": "MISSING_AMOUNT",
            "description": "Both debit and credit amounts are missing.",
            "severity": "ERROR",
            "expected_value": "At least one of debit/credit",
            "actual_value": "null",
        })
    
    if debit is not None and credit is not None and debit > 0 and credit > 0:
        issues.append({
            "issue_type": "BOTH_DEBIT_CREDIT",
            "description": "Both debit and credit are populated with non-zero values.",
            "severity": "WARNING",
            "expected_value": "Only one of debit/credit",
            "actual_value": f"Debit={debit}, Credit={credit}",
        })
    
    if debit is not None and debit < 0:
        issues.append({
            "issue_type": "NEGATIVE_DEBIT",
            "description": "Debit amount is negative.",
            "severity": "WARNING",
            "expected_value": "Positive debit",
            "actual_value": str(debit),
        })
    
    if credit is not None and credit < 0:
        issues.append({
            "issue_type": "NEGATIVE_CREDIT",
            "description": "Credit amount is negative.",
            "severity": "WARNING",
            "expected_value": "Positive credit",
            "actual_value": str(credit),
        })
    
    # OCR confidence
    if txn.get("extraction_confidence", 100) < 60:
        issues.append({
            "issue_type": "LOW_OCR_CONFIDENCE",
            "description": f"Low OCR confidence: {txn.get('extraction_confidence', 0):.0f}%",
            "severity": "WARNING",
            "expected_value": ">= 60%",
            "actual_value": f"{txn.get('extraction_confidence', 0):.0f}%",
        })
    
    return issues


def validate_transactions(transactions: List[Dict]) -> Tuple[List[Dict], List[Dict]]:
    """
    Validate all transactions and return (validated_transactions, all_issues).
    """
    all_issues = []
    
    for txn in transactions:
        txn_issues = validate_transaction(txn)
        
        if txn_issues:
            has_error = any(i["severity"] == "ERROR" for i in txn_issues)
            txn["validation_status"] = "FAILED" if has_error else "WARNING"
            txn["review_required"] = True
        else:
            if txn["validation_status"] == "PENDING":
                txn["validation_status"] = "PASSED"
        
        for issue in txn_issues:
            issue["transaction_id"] = txn["transaction_id"]
            issue["job_id"] = txn["job_id"]
            issue["issue_id"] = f"ISS-{uuid.uuid4().hex[:12].upper()}"
            issue["resolution_status"] = "OPEN"
            all_issues.append(issue)
    
    return transactions, all_issues
