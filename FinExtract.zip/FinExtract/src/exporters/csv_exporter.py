"""CSV export for FinExtract."""
import csv
import io
import logging
from datetime import datetime
from typing import Dict, List, Any

logger = logging.getLogger("finextract.csv_exporter")


def export_to_csv(transactions: List[Dict]) -> bytes:
    """
    Export transactions to UTF-8 CSV (with BOM for Excel compatibility).
    Returns bytes.
    """
    output = io.StringIO()
    
    fieldnames = [
        "transaction_id", "transaction_date", "raw_date", "description",
        "raw_description", "debit", "credit", "balance", "currency",
        "category", "predicted_category", "classification_method",
        "ml_confidence", "rule_id", "review_required", "validation_status",
        "extraction_method", "extraction_confidence", "source_page",
        "job_id", "account_id",
    ]
    
    writer = csv.DictWriter(
        output,
        fieldnames=fieldnames,
        extrasaction="ignore",
        lineterminator="\n",
    )
    writer.writeheader()
    
    for txn in transactions:
        row = {}
        for field in fieldnames:
            val = txn.get(field)
            if isinstance(val, datetime):
                val = val.strftime("%Y-%m-%d")
            elif isinstance(val, float):
                val = f"{val:.2f}" if val is not None else ""
            elif val is None:
                val = ""
            row[field] = str(val)
        writer.writerow(row)
    
    # Return with UTF-8 BOM for Excel compatibility
    return ("\ufeff" + output.getvalue()).encode("utf-8")


export_transactions_csv = export_to_csv


def export_summary_csv(
    job_info: Dict[str, Any],
    account_info: Dict[str, Any],
    transactions: List[Dict],
    reconciliation: Dict[str, Any]
) -> bytes:
    """Export executive audit summary to standard CSV."""
    output = io.StringIO()
    writer = csv.writer(output, lineterminator="\n")
    
    writer.writerow(["FinExtract Statement Audit Summary", ""])
    writer.writerow(["Generated At", datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")])
    writer.writerow(["Job ID", job_info.get("job_id", "")])
    writer.writerow(["Filename", job_info.get("filename", "")])
    writer.writerow(["Bank Name", account_info.get("bank_name", "Unknown")])
    writer.writerow(["Account Holder", account_info.get("account_holder", "")])
    writer.writerow(["Account Number", account_info.get("account_number_masked", "")])
    writer.writerow(["Currency", account_info.get("currency", "INR")])
    writer.writerow([])
    
    total_debits = sum(float(t.get("debit") or 0.0) for t in transactions)
    total_credits = sum(float(t.get("credit") or 0.0) for t in transactions)
    net_flow = total_credits - total_debits
    
    writer.writerow(["Metric", "Value"])
    writer.writerow(["Total Transactions", len(transactions)])
    writer.writerow(["Total Inflow (Credits)", f"{total_credits:.2f}"])
    writer.writerow(["Total Outflow (Debits)", f"{total_debits:.2f}"])
    writer.writerow(["Net Cash Flow", f"{net_flow:.2f}"])
    writer.writerow(["Reconciliation Status", reconciliation.get("status", "UNCHECKED")])
    writer.writerow(["Matched Continuity Checks", f"{reconciliation.get('matched', 0)} / {reconciliation.get('total_checked', 0)}"])
    
    return ("\ufeff" + output.getvalue()).encode("utf-8")


def export_validation_csv(validation_issues: List[Dict]) -> bytes:
    """Export all validation alerts, errors and warnings to CSV."""
    output = io.StringIO()
    fieldnames = [
        "issue_id", "job_id", "transaction_id", "issue_type",
        "severity", "description", "expected_value", "actual_value"
    ]
    
    writer = csv.DictWriter(output, fieldnames=fieldnames, extrasaction="ignore", lineterminator="\n")
    writer.writeheader()
    
    for issue in validation_issues:
        writer.writerow({k: str(issue.get(k, "")) for k in fieldnames})
        
    return ("\ufeff" + output.getvalue()).encode("utf-8")
