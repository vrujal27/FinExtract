"""Excel export using OpenPyXL for FinExtract."""
import io
import logging
from datetime import datetime
from typing import Dict, List, Optional, Any

import openpyxl
from openpyxl.styles import (
    Alignment, Border, Fill, Font, PatternFill, Side
)
from openpyxl.utils import get_column_letter

logger = logging.getLogger("finextract.excel_exporter")

# Styles
HEADER_FILL = PatternFill(start_color="1E3A5F", end_color="1E3A5F", fill_type="solid")
HEADER_FONT = Font(color="FFFFFF", bold=True, size=11)
ALT_ROW_FILL = PatternFill(start_color="F0F4F8", end_color="F0F4F8", fill_type="solid")
TITLE_FONT = Font(bold=True, size=14, color="1E3A5F")


def _style_header_row(ws, row_num: int, num_cols: int):
    """Apply header styling to a row."""
    for col in range(1, num_cols + 1):
        cell = ws.cell(row=row_num, column=col)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)


def _auto_column_width(ws, min_width=10, max_width=50):
    """Auto-size columns."""
    for col in ws.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            try:
                if cell.value:
                    max_len = max(max_len, len(str(cell.value)))
            except Exception:
                pass
        adjusted = min(max(max_len + 2, min_width), max_width)
        ws.column_dimensions[col_letter].width = adjusted


def export_to_excel(
    transactions: Any = None,
    account_info: Dict = None,
    validation_issues: List[Dict] = None,
    job_info: Dict = None,
    reconciliation: Dict = None,
    *args,
    **kwargs
) -> bytes:
    """
    Export data to Excel with multiple sheets.
    Returns the Excel file as bytes.
    Handles variable argument orders defensively.
    """
    # Defensive inversion check: if called positionally as export_to_excel(job_info, transactions, ...)
    if isinstance(transactions, dict) and isinstance(account_info, list):
        actual_job_info = transactions
        actual_txns = account_info
        actual_acct = validation_issues if isinstance(validation_issues, dict) else {}
        actual_val = job_info if isinstance(job_info, list) else []
        actual_recon = reconciliation if isinstance(reconciliation, dict) else {}
        transactions, account_info, validation_issues, job_info, reconciliation = (
            actual_txns, actual_acct, actual_val, actual_job_info, actual_recon
        )

    txns_list = transactions if isinstance(transactions, list) else []
    acct_dict = account_info if isinstance(account_info, dict) else {}
    val_list = validation_issues if isinstance(validation_issues, list) else []
    job_dict = job_info if isinstance(job_info, dict) else {}

    wb = openpyxl.Workbook()
    
    # Sheet 1: Transactions
    ws_txn = wb.active
    ws_txn.title = "Transactions"
    _write_transactions_sheet(ws_txn, txns_list)
    
    # Sheet 2: Account Summary
    ws_acct = wb.create_sheet("Account Summary")
    _write_account_summary_sheet(ws_acct, acct_dict, txns_list)
    
    # Sheet 3: Category Summary
    ws_cat = wb.create_sheet("Category Summary")
    _write_category_summary_sheet(ws_cat, txns_list)
    
    # Sheet 4: Validation Report
    ws_val = wb.create_sheet("Validation Report")
    _write_validation_sheet(ws_val, val_list)
    
    # Sheet 5: Processing Metadata
    ws_meta = wb.create_sheet("Processing Metadata")
    _write_metadata_sheet(ws_meta, job_dict)
    
    # Save to bytes
    buffer = io.BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return buffer.read()


def _write_transactions_sheet(ws, transactions: List[Dict]):
    """Write transactions to the main sheet."""
    ws.append(["FinExtract – Transaction Export"])
    ws["A1"].font = TITLE_FONT
    ws.append([f"Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}"])
    ws.append([])
    
    headers = [
        "Transaction ID", "Date", "Description", "Debit (INR)", "Credit (INR)",
        "Balance (INR)", "Category", "Predicted Category", "Classification Method",
        "ML Confidence", "Review Status", "Validation Status", "Source Page",
        "Extraction Method"
    ]
    ws.append(headers)
    _style_header_row(ws, 4, len(headers))
    ws.freeze_panes = "A5"
    ws.auto_filter.ref = f"A4:{get_column_letter(len(headers))}4"
    
    for i, txn in enumerate(transactions):
        date_val = txn.get("transaction_date")
        if isinstance(date_val, datetime):
            date_str = date_val.strftime("%Y-%m-%d")
        elif date_val:
            date_str = str(date_val)
        else:
            date_str = txn.get("raw_date", "")
        
        debit = txn.get("debit")
        credit = txn.get("credit")
        balance = txn.get("balance")
        ml_conf = txn.get("ml_confidence")
        
        row = [
            txn.get("transaction_id", ""),
            date_str,
            txn.get("description", ""),
            round(float(debit), 2) if debit is not None else "",
            round(float(credit), 2) if credit is not None else "",
            round(float(balance), 2) if balance is not None else "",
            txn.get("category", "Unclassified"),
            txn.get("predicted_category", ""),
            txn.get("classification_method", ""),
            round(float(ml_conf), 4) if ml_conf is not None else "",
            "Yes" if txn.get("review_required") else "No",
            txn.get("validation_status", ""),
            txn.get("source_page", ""),
            txn.get("extraction_method", ""),
        ]
        ws.append(row)
        
        # Alternate row coloring
        if i % 2 == 1:
            for col in range(1, len(headers) + 1):
                ws.cell(row=i + 5, column=col).fill = ALT_ROW_FILL
        
        # Format numeric cells
        row_num = i + 5
        for col_idx, col_name in enumerate(headers, 1):
            cell = ws.cell(row=row_num, column=col_idx)
            if col_name in ("Debit (INR)", "Credit (INR)", "Balance (INR)"):
                cell.number_format = '#,##0.00'
                cell.alignment = Alignment(horizontal="right")
            elif col_name == "ML Confidence":
                cell.number_format = '0.00%'
            elif col_name == "Date":
                cell.alignment = Alignment(horizontal="center")
    
    _auto_column_width(ws)


def _write_account_summary_sheet(ws, account_info: Dict, transactions: List[Dict]):
    """Write account summary sheet."""
    ws.append(["Account Summary"])
    ws["A1"].font = TITLE_FONT
    ws.append([])
    
    total_debit = sum(float(t.get("debit") or 0) for t in transactions)
    total_credit = sum(float(t.get("credit") or 0) for t in transactions)
    
    rows = [
        ["Bank", account_info.get("bank_name", "")],
        ["Account Holder", account_info.get("account_holder", "")],
        ["Account Number (Masked)", account_info.get("account_number_masked", "")],
        ["IFSC Code", account_info.get("ifsc", "")],
        ["Statement Period Start", str(account_info.get("statement_start_date", ""))],
        ["Statement Period End", str(account_info.get("statement_end_date", ""))],
        ["Opening Balance", account_info.get("opening_balance", "")],
        ["Closing Balance", account_info.get("closing_balance", "")],
        ["Total Debit", round(total_debit, 2)],
        ["Total Credit", round(total_credit, 2)],
        ["Transaction Count", len(transactions)],
    ]
    
    for row in rows:
        ws.append(row)
    
    for col in ws.columns:
        ws.column_dimensions[get_column_letter(col[0].column)].width = 30


def _write_category_summary_sheet(ws, transactions: List[Dict]):
    """Write category summary."""
    ws.append(["Category Summary"])
    ws["A1"].font = TITLE_FONT
    ws.append([])
    
    headers = ["Category", "Transaction Count", "Total Debit (INR)", "Total Credit (INR)", "Net Amount (INR)"]
    ws.append(headers)
    _style_header_row(ws, 3, len(headers))
    
    # Aggregate by category
    cat_data: Dict[str, Dict] = {}
    for txn in transactions:
        cat = txn.get("category", "Unclassified")
        if cat not in cat_data:
            cat_data[cat] = {"count": 0, "debit": 0.0, "credit": 0.0}
        cat_data[cat]["count"] += 1
        cat_data[cat]["debit"] += float(txn.get("debit") or 0)
        cat_data[cat]["credit"] += float(txn.get("credit") or 0)
    
    for cat, data in sorted(cat_data.items()):
        net = data["credit"] - data["debit"]
        ws.append([cat, data["count"], round(data["debit"], 2), round(data["credit"], 2), round(net, 2)])
    
    _auto_column_width(ws)


def _write_validation_sheet(ws, issues: List[Dict]):
    """Write validation issues."""
    ws.append(["Validation Report"])
    ws["A1"].font = TITLE_FONT
    ws.append([])
    
    headers = ["Transaction ID", "Issue Type", "Description", "Severity", "Expected Value", "Actual Value", "Status"]
    ws.append(headers)
    _style_header_row(ws, 3, len(headers))
    
    for issue in issues:
        ws.append([
            issue.get("transaction_id", ""),
            issue.get("issue_type", issue.get("type", "")),
            issue.get("description", ""),
            issue.get("severity", ""),
            str(issue.get("expected_value", issue.get("expected", ""))),
            str(issue.get("actual_value", issue.get("actual", ""))),
            issue.get("resolution_status", "OPEN"),
        ])
    
    _auto_column_width(ws)


def _write_metadata_sheet(ws, job_info: Dict):
    """Write processing metadata."""
    ws.append(["Processing Metadata"])
    ws["A1"].font = TITLE_FONT
    ws.append([])
    
    rows = [
        ["Job ID", job_info.get("job_id", "")],
        ["Filename", job_info.get("filename", "")],
        ["Bank", job_info.get("bank_name", "")],
        ["PDF Type", job_info.get("pdf_type", "")],
        ["Total Pages", job_info.get("page_count", "")],
        ["Text Pages", job_info.get("text_page_count", "")],
        ["OCR Pages", job_info.get("scanned_page_count", "")],
        ["Extraction Methods", str(job_info.get("extraction_methods", []))],
        ["Processing Date", str(job_info.get("created_at", datetime.utcnow()))],
        ["Processing Status", job_info.get("processing_status", "")],
        ["Processing Duration (s)", job_info.get("processing_duration", "")],
    ]
    
    for row in rows:
        ws.append(row)
    
    ws.column_dimensions["A"].width = 25
    ws.column_dimensions["B"].width = 50
