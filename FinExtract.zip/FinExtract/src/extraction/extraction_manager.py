"""Orchestrates PDF extraction using text and OCR methods."""
import logging
from typing import Dict, List, Optional

import fitz

from src.config import OCR_CONFIDENCE_THRESHOLD
from src.extraction.pdf_detector import detect_pdf_type
from src.extraction.text_extractor import extract_text_pdf
from src.extraction.ocr_extractor import ocr_pdf, TESSERACT_AVAILABLE
from src.utils.file_validator import validate_pdf_file
from src.utils.security import safe_temp_file

logger = logging.getLogger("finextract.extraction_manager")


def extract_pdf(file_bytes: bytes, filename: str, progress_callback=None) -> Dict:
    """
    Main entry point: validate, detect, and extract text from a PDF.

    The function:
    1. Validates the file (size, magic bytes, page count).
    2. Detects per-page type (text vs scanned).
    3. Extracts text pages with PyMuPDF + pdfplumber.
    4. OCRs scanned pages with Tesseract (if available).
    5. Merges results into a unified page list sorted by page number.

    Args:
        file_bytes: Raw bytes of the uploaded PDF.
        filename:   Original filename (used for validation and logging).

    Returns:
        {
            "success": bool,
            "error": str | None,
            "detection": {
                "pdf_type": "text" | "scanned" | "mixed",
                "total_pages": int,
                "text_pages": int,
                "scanned_pages": int,
                "requires_ocr": bool,
                "page_details": [...],
            },
            "pages": [
                {
                    "page_number": int,       # 1-based
                    "text": str,
                    "words": list,
                    "method": "text" | "ocr" | "none",
                    "confidence": float,      # 100.0 for text pages, 0-100 for OCR
                    "low_confidence": bool,
                    "error": str | None,
                    "pdfplumber": dict | None,
                }
            ],
            "full_text": str,
            "warnings": [str],
        }
    """
    result: Dict = {
        "success": False,
        "error": None,
        "detection": {},
        "pages": [],
        "full_text": "",
        "warnings": [],
    }

    # --- Step 1: Validate ---
    is_valid, error_msg = validate_pdf_file(file_bytes, filename)
    if not is_valid:
        result["error"] = error_msg
        return result

    # --- Step 2: Detect PDF type ---
    detection = detect_pdf_type(file_bytes)
    result["detection"] = detection

    if detection.get("pdf_type") == "unknown":
        result["error"] = detection.get("error", "Could not determine PDF type.")
        return result

    if detection.get("requires_ocr") and not TESSERACT_AVAILABLE:
        result["warnings"].append(
            "This PDF contains scanned pages but Tesseract OCR is not available. "
            "Scanned pages will be skipped. Install Tesseract for full extraction."
        )

    page_details = detection.get("page_details", [])
    text_page_indices = [p["page_number"] - 1 for p in page_details if p["page_type"] == "text"]
    scanned_page_indices = [p["page_number"] - 1 for p in page_details if p["page_type"] == "scanned"]

    # Accumulate all pages keyed by 1-based page number
    all_pages: Dict[int, Dict] = {}

    # --- Step 3: Extract text pages ---
    if text_page_indices:
        if progress_callback:
            progress_callback(20, f"Reading {len(text_page_indices)} digital page(s)...")
        logger.info(
            f"Extracting {len(text_page_indices)} text page(s) from '{filename}' via PyMuPDF."
        )
        text_result = extract_text_pdf(file_bytes, text_page_indices)

        # Build a lookup for pdfplumber supplementary data
        pb_lookup: Dict[int, Dict] = {
            pb["page_number"]: pb
            for pb in text_result.get("pdfplumber_pages", [])
        }

        for page_data in text_result.get("pages", []):
            pnum = page_data["page_number"]
            all_pages[pnum] = {
                "page_number": pnum,
                "text": page_data["text"],
                "words": page_data.get("words", []),
                "method": "text",
                "confidence": 100.0,
                "low_confidence": False,
                "error": None,
                "pdfplumber": pb_lookup.get(pnum),
            }

    # --- Step 4: OCR scanned pages ---
    if scanned_page_indices:
        if progress_callback:
            progress_callback(35, f"Reading {len(scanned_page_indices)} scanned page(s)...")
        logger.info(
            f"OCR processing {len(scanned_page_indices)} scanned page(s) from '{filename}'."
        )
        ocr_cb = None
        if progress_callback:
            ocr_cb = lambda d, t, msg: progress_callback(35 + int(25 * d / max(t, 1)), msg)
        ocr_result = ocr_pdf(file_bytes, scanned_page_indices, progress_callback=ocr_cb)

        for page_data in ocr_result.get("pages", []):
            pnum = page_data["page_number"]
            is_low_conf = page_data.get("low_confidence", False)
            conf = page_data.get("confidence", 0.0)
            err = page_data.get("error")

            if err:
                result["warnings"].append(f"Page {pnum}: {err}")
            elif is_low_conf:
                result["warnings"].append(
                    f"Page {pnum}: Low OCR confidence ({conf:.0f}%). "
                    "Transactions from this page may need manual review."
                )

            all_pages[pnum] = {
                "page_number": pnum,
                "text": page_data.get("text", ""),
                "words": page_data.get("words", []),
                "method": page_data.get("method", "ocr"),
                "confidence": conf,
                "low_confidence": is_low_conf,
                "error": err,
                "pdfplumber": None,
            }

    # --- Step 5: Sort and assemble ---
    sorted_pages = [all_pages[k] for k in sorted(all_pages.keys())]
    result["pages"] = sorted_pages
    result["full_text"] = "\n".join(p["text"] for p in sorted_pages if p["text"])
    result["success"] = True

    logger.info(
        f"Extraction complete for '{filename}': "
        f"{len(sorted_pages)} pages, "
        f"{len(result['warnings'])} warning(s)."
    )

    return result
