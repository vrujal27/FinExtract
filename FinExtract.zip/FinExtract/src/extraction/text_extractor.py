"""Text extraction from PDF pages using PyMuPDF and pdfplumber."""
import io
import logging
import re
from typing import Dict, List, Optional, Tuple

import fitz  # PyMuPDF
import pdfplumber

logger = logging.getLogger("finextract.text_extractor")

# Synonym table for column header normalization
COLUMN_SYNONYMS = {
    "date": [
        "date", "transaction date", "txn date", "value date",
        "posting date", "trans date", "tran date",
    ],
    "description": [
        "description", "particulars", "narration", "details",
        "transaction details", "remarks", "narrative", "txn description",
    ],
    "debit": [
        "debit", "withdrawal", "withdrawals", "dr", "debit amount",
        "amount debited", "paid out",
    ],
    "credit": [
        "credit", "deposit", "deposits", "cr", "credit amount",
        "amount credited", "paid in",
    ],
    "balance": [
        "balance", "running balance", "closing balance",
        "available balance", "bal", "book balance",
    ],
    "amount": ["amount", "transaction amount", "net amount"],
    "indicator": ["dr/cr", "type", "indicator", "cr/dr", "d/c", "c/d"],
    "reference": [
        "reference", "ref no", "reference no", "chq no",
        "cheque no", "utr", "transaction id",
    ],
}


def normalize_header(header: str) -> str:
    """Normalize a column header to a standard key."""
    if not header:
        return ""
    h = header.lower().strip()
    for key, synonyms in COLUMN_SYNONYMS.items():
        for syn in synonyms:
            if h == syn or h.startswith(syn):
                return key
    return h


def extract_text_from_page(page: fitz.Page) -> Tuple[str, List[Dict]]:
    """Extract text and word positions from a PyMuPDF page."""
    text = page.get_text("text") or ""
    # Get word positions for layout analysis: (x0, y0, x1, y1, word, block_no, line_no, word_no)
    words = page.get_text("words") or []
    word_dicts = [
        {
            "x0": w[0],
            "y0": w[1],
            "x1": w[2],
            "y1": w[3],
            "text": w[4],
            "block": w[5],
            "line": w[6],
        }
        for w in words
    ]
    return text, word_dicts


def extract_text_pdf(file_bytes: bytes, page_numbers: List[int] = None) -> Dict:
    """
    Extract text from a text-based PDF.

    Args:
        file_bytes: Raw PDF bytes.
        page_numbers: Optional list of 0-based page numbers to extract. None = all.

    Returns:
        {
            "pages": [{"page_number": 1, "text": "...", "words": [...], "method": "pymupdf"}],
            "full_text": "...",
            "extraction_method": "pymupdf",
            "pdfplumber_pages": [...],
        }
    """
    result: Dict = {
        "pages": [],
        "full_text": "",
        "extraction_method": "pymupdf",
        "pdfplumber_pages": [],
    }

    try:
        doc = fitz.open(stream=file_bytes, filetype="pdf")
        all_text: List[str] = []

        pages_to_extract = page_numbers if page_numbers is not None else list(range(len(doc)))

        for page_num in pages_to_extract:
            if page_num >= len(doc):
                continue
            page = doc[page_num]
            text, words = extract_text_from_page(page)
            page_info = {
                "page_number": page_num + 1,
                "text": text,
                "words": words,
                "method": "pymupdf",
            }
            result["pages"].append(page_info)
            all_text.append(text)

        doc.close()
        result["full_text"] = "\n".join(all_text)

        # Try pdfplumber for table extraction
        try:
            result["pdfplumber_pages"] = _extract_with_pdfplumber(file_bytes, pages_to_extract)
        except Exception as e:
            logger.debug(f"pdfplumber extraction failed: {e}")
            result["pdfplumber_pages"] = []

    except Exception as e:
        logger.error(f"Text extraction failed: {e}")
        result["error"] = str(e)

    return result


def _extract_with_pdfplumber(file_bytes: bytes, page_numbers) -> List[Dict]:
    """Extract tables using pdfplumber efficiently."""
    pages_data: List[Dict] = []
    consecutive_empty = 0

    with pdfplumber.open(io.BytesIO(file_bytes)) as pdf:
        for idx, page_num in enumerate(page_numbers):
            if page_num >= len(pdf.pages):
                continue

            # If document is large (>30 pages) and first 6 pages had no multi-column tables,
            # this is a plain-text/vertical-stream layout — skip heavy table parsing
            if len(page_numbers) > 30 and idx >= 6 and consecutive_empty >= 6:
                pages_data.append(
                    {
                        "page_number": page_num + 1,
                        "text": "",
                        "tables": [],
                        "words": [],
                    }
                )
                continue

            page = pdf.pages[page_num]

            # Extract tables only
            tables: List = []
            try:
                raw_tables = page.extract_tables()
                if raw_tables:
                    # Keep only tables with multiple columns
                    valid_tables = [
                        t for t in raw_tables
                        if t and any(len(row) > 1 for row in t if row)
                    ]
                    if valid_tables:
                        tables = valid_tables
                        consecutive_empty = 0
                    else:
                        consecutive_empty += 1
                else:
                    consecutive_empty += 1
            except Exception:
                consecutive_empty += 1

            pages_data.append(
                {
                    "page_number": page_num + 1,
                    "text": "",
                    "tables": tables,
                    "words": [],
                }
            )

    return pages_data
