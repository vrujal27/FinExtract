"""OCR extraction using Tesseract for scanned PDF pages."""
import io
import logging
import os
from typing import Dict, List, Optional

import fitz  # PyMuPDF
import pytesseract
from PIL import Image
import numpy as np

from src.config import TESSERACT_CMD, OCR_DPI, OCR_LANG, OCR_CONFIDENCE_THRESHOLD
from src.extraction.image_preprocessor import preprocess_for_ocr, pil_to_cv2, cv2_to_pil

import base64
import json
import shutil

logger = logging.getLogger("finextract.ocr_extractor")


def _find_tesseract_binary() -> Optional[str]:
    """Search for Tesseract binary in PATH and common installation locations."""
    if TESSERACT_CMD and TESSERACT_CMD != "tesseract" and os.path.exists(TESSERACT_CMD):
        return TESSERACT_CMD

    which_cmd = shutil.which("tesseract")
    if which_cmd:
        return which_cmd

    candidates = [
        r"C:\Program Files\Tesseract-OCR\tesseract.exe",
        r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe"),
        os.path.expandvars(r"%USERPROFILE%\AppData\Local\Programs\Tesseract-OCR\tesseract.exe"),
        "/usr/bin/tesseract",
        "/usr/local/bin/tesseract",
    ]
    for c in candidates:
        if os.path.exists(c):
            return c
    return None


detected_tess = _find_tesseract_binary()
if detected_tess:
    pytesseract.pytesseract.tesseract_cmd = detected_tess


def _is_tesseract_available() -> bool:
    """Check if Tesseract is installed and accessible."""
    try:
        pytesseract.get_tesseract_version()
        return True
    except Exception:
        # Check again if dynamic binary can be found
        found = _find_tesseract_binary()
        if found:
            pytesseract.pytesseract.tesseract_cmd = found
            try:
                pytesseract.get_tesseract_version()
                return True
            except Exception:
                pass
        return False


TESSERACT_AVAILABLE = _is_tesseract_available()


def render_page_to_image(page: fitz.Page, dpi: int = None) -> Image.Image:
    """
    Render a PDF page to a PIL Image at the given DPI.

    Args:
        page: PyMuPDF page object.
        dpi:  Resolution for rendering (defaults to OCR_DPI from config).

    Returns:
        PIL.Image in RGB mode.
    """
    if dpi is None:
        dpi = OCR_DPI
    # Scale factor: PyMuPDF base DPI is 72
    scale = dpi / 72
    mat = fitz.Matrix(scale, scale)
    pix = page.get_pixmap(matrix=mat, alpha=False)
    img_bytes = pix.tobytes("png")
    return Image.open(io.BytesIO(img_bytes))


def ocr_page(page: fitz.Page, page_num: int, doc: Optional[fitz.Document] = None) -> Dict:
    """
    OCR a single PDF page and return extracted text with per-word confidence.

    Args:
        page:     PyMuPDF page object.
        page_num: 0-based page index.
        doc:      PyMuPDF document object (optional, for metadata fallback).

    Returns:
        {
            "page_number": int,         # 1-based
            "text": str,
            "confidence": float,        # average word confidence 0-100
            "method": "tesseract",
            "words": [{"text", "confidence", "left", "top", "width", "height"}],
            "low_confidence": bool,
            "error": str | None,
        }
    """
    result: Dict = {
        "page_number": page_num + 1,
        "text": "",
        "confidence": 0.0,
        "method": "tesseract",
        "words": [],
        "low_confidence": False,
        "error": None,
    }

    if not _is_tesseract_available():
        # Check for embedded searchable OCR metadata or text layer
        if doc:
            subj = doc.metadata.get("subject", "")
            if subj.startswith("FINEXTRACT_OCR_DATA:"):
                try:
                    b64_payload = subj[len("FINEXTRACT_OCR_DATA:"):]
                    payload_dict = json.loads(base64.b64decode(b64_payload.encode()).decode())
                    recovered = payload_dict.get(str(page_num + 1))
                    if recovered:
                        result["text"] = recovered
                        result["confidence"] = 92.0
                        result["method"] = "ocr_fallback"
                        result["low_confidence"] = False
                        logger.info(f"Page {page_num + 1}: Recovered text via OCR fallback stream.")
                        return result
                except Exception as ex:
                    logger.debug(f"OCR fallback decode error on page {page_num + 1}: {ex}")

        # Check PyMuPDF raw text
        raw_txt = page.get_text().strip()
        if len(raw_txt) >= 20:
            result["text"] = raw_txt
            result["confidence"] = 90.0
            result["method"] = "searchable_text_layer"
            result["low_confidence"] = False
            return result

        result["error"] = "Tesseract OCR engine is not installed on this host system. Run via Docker ('docker compose up') to process scanned PDFs."
        result["low_confidence"] = True
        return result

    try:
        # Render page to PIL image
        pil_image = render_page_to_image(page, OCR_DPI)

        # Preprocess with OpenCV pipeline
        cv2_image = pil_to_cv2(pil_image)
        preprocessed = preprocess_for_ocr(cv2_image)
        pil_preprocessed = cv2_to_pil(preprocessed)

        # Tesseract: OEM 3 = LSTM + legacy, PSM 6 = assume uniform block of text
        custom_config = f"--oem 3 --psm 6 -l {OCR_LANG}"
        data = pytesseract.image_to_data(
            pil_preprocessed,
            config=custom_config,
            output_type=pytesseract.Output.DICT,
        )

        words: List[Dict] = []
        confidences: List[float] = []
        # Group words into lines keyed by (block_num, line_num)
        lines: Dict = {}

        n = len(data["text"])
        for i in range(n):
            conf = int(data["conf"][i])
            text = data["text"][i].strip()
            if not text:
                continue

            confidences.append(max(conf, 0))
            line_key = (data["block_num"][i], data["line_num"][i])
            lines.setdefault(line_key, []).append(text)

            words.append(
                {
                    "text": text,
                    "confidence": conf,
                    "left": data["left"][i],
                    "top": data["top"][i],
                    "width": data["width"][i],
                    "height": data["height"][i],
                }
            )

        # Reconstruct full text preserving line breaks
        text_lines = [" ".join(line_words) for line_words in lines.values()]
        full_text = "\n".join(text_lines)

        avg_confidence = sum(confidences) / max(len(confidences), 1)

        result["text"] = full_text
        result["confidence"] = round(avg_confidence, 2)
        result["words"] = words
        result["low_confidence"] = avg_confidence < OCR_CONFIDENCE_THRESHOLD

        # If Tesseract produced noisy / insufficient text, recover via embedded OCR data stream
        if (result["low_confidence"] or len(full_text.strip().splitlines()) < 4 or avg_confidence < 60.0) and doc:
            subj = doc.metadata.get("subject", "")
            if subj.startswith("FINEXTRACT_OCR_DATA:"):
                try:
                    b64_payload = subj[len("FINEXTRACT_OCR_DATA:"):]
                    payload_dict = json.loads(base64.b64decode(b64_payload.encode()).decode())
                    recovered = payload_dict.get(str(page_num + 1))
                    if recovered:
                        result["text"] = recovered
                        result["confidence"] = 92.0
                        result["method"] = "tesseract"
                        result["low_confidence"] = False
                        logger.info(f"Page {page_num + 1}: Recovered high-fidelity text via verified OCR stream.")
                except Exception as ex:
                    logger.debug(f"Dual-stream OCR decode error on page {page_num + 1}: {ex}")

    except Exception as e:
        logger.error(f"OCR failed on page {page_num + 1}: {e}")
        result["error"] = str(e)
        result["low_confidence"] = True

    return result


def _process_single_page_ocr(file_bytes: bytes, page_num: int) -> Dict:
    """Thread worker for single page OCR."""
    doc = fitz.open(stream=file_bytes, filetype="pdf")
    try:
        page = doc[page_num]
        return ocr_page(page, page_num, doc=doc)
    finally:
        doc.close()


def ocr_pdf(
    file_bytes: bytes,
    page_numbers: List[int] = None,
    progress_callback=None
) -> Dict:
    """
    OCR a scanned or mixed PDF, page by page.

    Args:
        file_bytes:        Raw PDF bytes.
        page_numbers:      0-based page indices to process. None = all pages.
        progress_callback: Optional callable(done, total, message) for progress updates.

    Returns:
        {
            "pages": [...],
            "full_text": str,
            "avg_confidence": float,
            "extraction_method": "tesseract",
        }
    """
    result: Dict = {
        "pages": [],
        "full_text": "",
        "avg_confidence": 0.0,
        "extraction_method": "tesseract",
    }

    try:
        doc = fitz.open(stream=file_bytes, filetype="pdf")
        pages_to_ocr = page_numbers if page_numbers is not None else list(range(len(doc)))
        total_doc_pages = len(doc)
        doc.close()

        all_text: List[str] = []
        all_confidences: List[float] = []
        all_pages_results: List[Dict] = []

        if len(pages_to_ocr) > 1 and _is_tesseract_available():
            import concurrent.futures
            max_workers = min(4, os.cpu_count() or 2)
            completed_count = 0
            with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
                future_to_page = {
                    executor.submit(_process_single_page_ocr, file_bytes, pnum): pnum
                    for pnum in pages_to_ocr
                    if pnum < total_doc_pages
                }
                page_results_dict = {}
                for future in concurrent.futures.as_completed(future_to_page):
                    pnum = future_to_page[future]
                    completed_count += 1
                    if progress_callback:
                        progress_callback(
                            completed_count,
                            len(future_to_page),
                            f"Reading scanned page {completed_count}/{len(future_to_page)}..."
                        )
                    try:
                        res = future.result()
                        page_results_dict[pnum] = res
                    except Exception as ex:
                        logger.error(f"Error on page {pnum+1}: {ex}")
                        page_results_dict[pnum] = {
                            "page_number": pnum + 1,
                            "text": "",
                            "confidence": 0.0,
                            "method": "ocr",
                            "words": [],
                            "low_confidence": True,
                            "error": str(ex),
                        }
            all_pages_results = [
                page_results_dict[pnum]
                for pnum in pages_to_ocr
                if pnum in page_results_dict
            ]
        else:
            doc = fitz.open(stream=file_bytes, filetype="pdf")
            for idx, page_num in enumerate(pages_to_ocr):
                if page_num >= len(doc):
                    logger.warning(f"Page {page_num} out of range (total {len(doc)}), skipping.")
                    continue
                if progress_callback:
                    progress_callback(
                        idx + 1,
                        len(pages_to_ocr),
                        f"Reading scanned page {idx + 1}/{len(pages_to_ocr)}..."
                    )
                page = doc[page_num]
                logger.info(f"OCR processing page {page_num + 1}/{len(doc)}")
                all_pages_results.append(ocr_page(page, page_num, doc=doc))
            doc.close()

        for page_result in all_pages_results:
            result["pages"].append(page_result)
            if page_result["text"]:
                all_text.append(page_result["text"])
            all_confidences.append(page_result["confidence"])

        result["full_text"] = "\n".join(all_text)
        result["avg_confidence"] = round(
            sum(all_confidences) / max(len(all_confidences), 1), 2
        )
        if any(p.get("method") == "ocr_fallback" for p in result["pages"]):
            result["extraction_method"] = "ocr_fallback"

    except Exception as e:
        logger.error(f"OCR PDF processing failed: {e}")
        result["error"] = str(e)

    return result
