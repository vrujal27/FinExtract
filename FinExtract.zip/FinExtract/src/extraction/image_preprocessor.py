"""Image preprocessing for OCR - OpenCV-based."""
import logging
from typing import Optional

import cv2
import numpy as np

logger = logging.getLogger("finextract.image_preprocessor")


def preprocess_for_ocr(image: np.ndarray) -> np.ndarray:
    """
    Full preprocessing pipeline for high-speed, high-accuracy OCR.

    Steps:
    1. Grayscale conversion
    2. Resize if low resolution (< 1000px wide)
    3. Gaussian blur for fast noise smoothing
    4. Contrast enhancement via CLAHE
    5. Safe deskew (only when genuine skew > 1 degree is detected)
    """
    # 1. Grayscale
    if len(image.shape) == 3:
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    else:
        gray = image.copy()

    # 2. Resize if too small (< 1000px wide)
    h, w = gray.shape
    if w < 1000:
        scale = 1000 / w
        new_w = int(w * scale)
        new_h = int(h * scale)
        gray = cv2.resize(gray, (new_w, new_h), interpolation=cv2.INTER_CUBIC)

    # 3. Fast noise smoothing
    smoothed = cv2.GaussianBlur(gray, (3, 3), 0)

    # 4. CLAHE contrast enhancement for clean text separation
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    enhanced = clahe.apply(smoothed)

    # 5. Safe deskew
    deskewed = _deskew(enhanced)

    return deskewed


def _deskew(image: np.ndarray) -> np.ndarray:
    """Detect and correct skew in a grayscale image using minAreaRect safely."""
    try:
        # Find dark pixel coordinates (assume dark text on light background)
        coords = np.column_stack(np.where(image < 128))
        if len(coords) < 100:
            return image

        # OpenCV expects (x, y) points
        pts = np.column_stack([coords[:, 1], coords[:, 0]])
        rect = cv2.minAreaRect(pts)
        angle = rect[-1]

        # Normalize angle to actual skew deviation from horizontal
        if angle < -45:
            angle = -(90 + angle)
        elif angle > 45:
            angle = angle - 90
        else:
            angle = -angle

        # Only deskew if angle is significant and realistic (between 1.0 and 20 degrees)
        if abs(angle) < 1.0 or abs(angle) > 20.0:
            return image

        (h, w) = image.shape[:2]
        center = (w // 2, h // 2)
        M = cv2.getRotationMatrix2D(center, angle, 1.0)
        rotated = cv2.warpAffine(
            image,
            M,
            (w, h),
            flags=cv2.INTER_CUBIC,
            borderMode=cv2.BORDER_REPLICATE,
        )
        logger.debug(f"Deskewed image by {angle:.2f} degrees")
        return rotated
    except Exception as e:
        logger.debug(f"Deskew failed: {e}")
        return image


def pil_to_cv2(pil_image) -> np.ndarray:
    """Convert a PIL Image to an OpenCV BGR numpy array."""
    return cv2.cvtColor(np.array(pil_image), cv2.COLOR_RGB2BGR)


def cv2_to_pil(cv2_image: np.ndarray):
    """Convert an OpenCV BGR/grayscale array to a PIL Image."""
    from PIL import Image

    if len(cv2_image.shape) == 2:
        # Grayscale — convert to RGB for Tesseract compatibility
        rgb = cv2.cvtColor(cv2_image, cv2.COLOR_GRAY2RGB)
    else:
        rgb = cv2.cvtColor(cv2_image, cv2.COLOR_BGR2RGB)
    return Image.fromarray(rgb)
