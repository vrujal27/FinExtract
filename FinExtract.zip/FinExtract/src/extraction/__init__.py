"""Extraction package for FinExtract.

Public API
----------
extract_pdf          -- Main entry point: validate + detect + extract a PDF.
detect_pdf_type      -- Page-level type detection (text / scanned / mixed).
extract_text_pdf     -- PyMuPDF + pdfplumber text extraction for text PDFs.
ocr_pdf              -- Tesseract OCR for scanned PDF pages.
preprocess_for_ocr   -- OpenCV image preprocessing pipeline.
normalize_header     -- Normalise column header strings to canonical keys.
"""

from src.extraction.extraction_manager import extract_pdf
from src.extraction.pdf_detector import detect_pdf_type
from src.extraction.text_extractor import extract_text_pdf, normalize_header
from src.extraction.ocr_extractor import ocr_pdf, TESSERACT_AVAILABLE
from src.extraction.image_preprocessor import preprocess_for_ocr

__all__ = [
    "extract_pdf",
    "detect_pdf_type",
    "extract_text_pdf",
    "normalize_header",
    "ocr_pdf",
    "TESSERACT_AVAILABLE",
    "preprocess_for_ocr",
]
