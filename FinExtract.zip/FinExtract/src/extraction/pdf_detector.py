"""PDF type detection engine - determines if PDF is text, scanned, or mixed."""
import logging
import re
from typing import Dict, List

import fitz  # PyMuPDF

from src.config import (
    MIN_TEXT_CHARS_FOR_TEXT_PAGE,
    MIN_ALPHANUM_RATIO,
    IMAGE_COVERAGE_THRESHOLD,
)

logger = logging.getLogger("finextract.pdf_detector")

DATE_PATTERN = re.compile(r'\d{1,2}[-/]\d{1,2}[-/]\d{2,4}|\d{1,2}[-\s][A-Za-z]{3}[-\s]\d{2,4}')
AMOUNT_PATTERN = re.compile(r'\d+[,\d]*\.?\d*')


def _analyze_page(page: fitz.Page) -> Dict:
    """Analyze a single page to determine if it's text or scanned."""
    page_rect = page.rect
    page_area = page_rect.width * page_rect.height

    # Extract text
    text = page.get_text("text") or ""
    text_len = len(text.strip())

    # Calculate alphanumeric ratio
    alphanum_chars = sum(1 for c in text if c.isalnum())
    alphanum_ratio = alphanum_chars / max(text_len, 1)

    # Check for date/amount patterns
    has_dates = bool(DATE_PATTERN.search(text))
    has_amounts = bool(AMOUNT_PATTERN.search(text))

    # Analyze images
    image_list = page.get_images(full=True)
    image_coverage = 0.0
    if image_list and page_area > 0:
        total_image_area = 0
        for img in image_list:
            xref = img[0]
            rects = page.get_image_rects(xref)
            for rect in rects:
                total_image_area += rect.width * rect.height
        image_coverage = min(total_image_area / page_area, 1.0)

    # Determine if page has sufficient text
    has_sufficient_text = (
        text_len >= MIN_TEXT_CHARS_FOR_TEXT_PAGE
        and alphanum_ratio >= MIN_ALPHANUM_RATIO
    )

    # Determine if page is predominantly image-based
    is_scanned = (
        image_coverage >= IMAGE_COVERAGE_THRESHOLD
        and not has_sufficient_text
    )

    # A page with both some text AND large images could be mixed
    # If text exists and is good quality, treat as text page even if images present
    if has_sufficient_text and (has_dates or has_amounts):
        page_type = "text"
    elif is_scanned:
        page_type = "scanned"
    elif text_len > 0:
        page_type = "text" if text_len >= MIN_TEXT_CHARS_FOR_TEXT_PAGE else "scanned"
    else:
        page_type = "scanned"

    return {
        "page_number": page.number + 1,
        "page_type": page_type,
        "text_length": text_len,
        "alphanum_ratio": round(alphanum_ratio, 3),
        "image_coverage": round(image_coverage, 3),
        "has_dates": has_dates,
        "has_amounts": has_amounts,
        "image_count": len(image_list),
    }


def detect_pdf_type(file_bytes: bytes) -> Dict:
    """
    Detect PDF type (text/scanned/mixed) on a page-by-page basis.

    Returns:
        {
            "pdf_type": "text" | "scanned" | "mixed",
            "total_pages": int,
            "text_pages": int,
            "scanned_pages": int,
            "requires_ocr": bool,
            "page_details": [...]
        }
    """
    try:
        doc = fitz.open(stream=file_bytes, filetype="pdf")
        total_pages = len(doc)
        page_details = []
        text_page_count = 0
        scanned_page_count = 0

        for page_num in range(total_pages):
            page = doc[page_num]
            info = _analyze_page(page)
            page_details.append(info)
            if info["page_type"] == "text":
                text_page_count += 1
            else:
                scanned_page_count += 1

        doc.close()

        # Determine overall type
        if scanned_page_count == 0:
            pdf_type = "text"
        elif text_page_count == 0:
            pdf_type = "scanned"
        else:
            pdf_type = "mixed"

        return {
            "pdf_type": pdf_type,
            "total_pages": total_pages,
            "text_pages": text_page_count,
            "scanned_pages": scanned_page_count,
            "requires_ocr": scanned_page_count > 0,
            "page_details": page_details,
        }
    except Exception as e:
        logger.error(f"PDF detection failed: {e}")
        return {
            "pdf_type": "unknown",
            "total_pages": 0,
            "text_pages": 0,
            "scanned_pages": 0,
            "requires_ocr": False,
            "page_details": [],
            "error": str(e),
        }
