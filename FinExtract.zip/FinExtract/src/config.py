"""Central configuration for FinExtract."""
import os
from pathlib import Path

BASE_DIR = Path(__file__).parent.parent

# MongoDB
MONGODB_URI = os.getenv("MONGODB_URI", "mongodb://localhost:27017/finextract")
MONGO_DATABASE = os.getenv("MONGO_DATABASE", "finextract")
TEST_MONGODB_URI = os.getenv("TEST_MONGODB_URI", "mongodb://localhost:27017/finextract_test")
MONGO_CONNECT_RETRIES = int(os.getenv("MONGO_CONNECT_RETRIES", "10"))
MONGO_CONNECT_DELAY = float(os.getenv("MONGO_CONNECT_DELAY", "3.0"))

# File limits
MAX_UPLOAD_MB = max(int(os.getenv("MAX_UPLOAD_MB", "50")), 50)
MAX_UPLOAD_BYTES = MAX_UPLOAD_MB * 1024 * 1024
MAX_PAGES = max(int(os.getenv("MAX_PAGES", "500")), 500)

# PDF detection thresholds
MIN_TEXT_CHARS_FOR_TEXT_PAGE = int(os.getenv("MIN_TEXT_CHARS", "50"))
MIN_ALPHANUM_RATIO = float(os.getenv("MIN_ALPHANUM_RATIO", "0.3"))
IMAGE_COVERAGE_THRESHOLD = float(os.getenv("IMAGE_COVERAGE_THRESHOLD", "0.6"))
OCR_CONFIDENCE_THRESHOLD = int(os.getenv("OCR_CONFIDENCE_THRESHOLD", "60"))

# OCR
TESSERACT_CMD = os.getenv("TESSERACT_CMD", "tesseract")
OCR_DPI = int(os.getenv("OCR_DPI", "150"))
OCR_LANG = os.getenv("OCR_LANG", "eng")

# Classification thresholds
ML_HIGH_CONFIDENCE = float(os.getenv("ML_HIGH_CONFIDENCE", "0.85"))
ML_REVIEW_THRESHOLD = float(os.getenv("ML_REVIEW_THRESHOLD", "0.60"))

# Validation
BALANCE_TOLERANCE = float(os.getenv("BALANCE_TOLERANCE", "0.01"))

# Paths
MODELS_DIR = BASE_DIR / "models"
DATA_DIR = BASE_DIR / "data"
SAMPLES_DIR = BASE_DIR / "samples"
RULES_FILE = BASE_DIR / "src" / "classification" / "rules.json"
CLASSIFIER_PATH = MODELS_DIR / "transaction_classifier.joblib"
CLASSIFIER_META_PATH = MODELS_DIR / "transaction_classifier_meta.json"
TRAINING_DATA_PATH = DATA_DIR / "training_transactions.csv"

# Currency
DEFAULT_CURRENCY = "INR"

# Categories
CATEGORIES = [
    "Salary", "Income", "Food & Dining", "Groceries", "Shopping",
    "Transportation", "Fuel", "Utilities", "Rent", "Healthcare",
    "Education", "Entertainment", "Travel", "ATM/Cash Withdrawal",
    "Bank Charges", "Loan/EMI", "Investment", "Insurance",
    "Transfers", "Unclassified"
]
