"""Rule-based transaction classification engine."""
import json
import logging
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from src.config import RULES_FILE
from src.utils.helpers import normalize_description

logger = logging.getLogger("finextract.rule_engine")


class RuleEngine:
    """Applies configurable rules to classify transactions."""

    def __init__(self, rules_file: str = None):
        self.rules_file = rules_file or str(RULES_FILE)
        self.rules = []
        self._load_rules()

    def _load_rules(self):
        """Load rules from JSON file."""
        try:
            with open(self.rules_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            self.rules = [r for r in data.get("rules", []) if r.get("enabled", True)]
            # Sort by priority (higher = first)
            self.rules.sort(key=lambda r: r.get("priority", 0), reverse=True)
            logger.info(f"Loaded {len(self.rules)} classification rules.")
        except Exception as e:
            logger.error(f"Failed to load rules from {self.rules_file}: {e}")
            self.rules = []

    def _matches(self, rule: Dict, normalized_desc: str) -> bool:
        """Check if a rule matches a description."""
        pattern = rule.get("pattern", "")
        strategy = rule.get("strategy", "contains")

        if strategy == "exact":
            return normalized_desc == pattern.upper()
        elif strategy == "contains":
            return pattern.upper() in normalized_desc
        elif strategy == "regex":
            try:
                return bool(re.search(pattern, normalized_desc, re.IGNORECASE))
            except re.error:
                return False
        elif strategy == "word_boundary":
            try:
                return bool(re.search(r'\b' + re.escape(pattern) + r'\b', normalized_desc, re.IGNORECASE))
            except re.error:
                return False
        return False

    def classify(
        self, description: str, is_credit: bool = None
    ) -> Tuple[Optional[str], Optional[str], Optional[str]]:
        """
        Classify a transaction description.
        
        Args:
            description: Transaction description.
            is_credit: True if credit, False if debit, None if unknown.
        
        Returns:
            (category, rule_id, explanation) or (None, None, None) if no match.
        """
        normalized = normalize_description(description)
        if not normalized:
            return None, None, None

        for rule in self.rules:
            # Check credit/debit constraints
            credit_only = rule.get("credit_only", False)
            debit_only = rule.get("debit_only", False)
            if credit_only and is_credit is False:
                continue
            if debit_only and is_credit is True:
                continue

            if self._matches(rule, normalized):
                return (
                    rule.get("category"),
                    rule.get("rule_id"),
                    rule.get("explanation", "")
                )

        return None, None, None

    def get_all_rules(self) -> List[Dict]:
        """Return all loaded rules."""
        return self.rules


# Singleton
_rule_engine = None

def get_rule_engine() -> RuleEngine:
    global _rule_engine
    if _rule_engine is None:
        _rule_engine = RuleEngine()
    return _rule_engine
