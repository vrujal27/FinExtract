"""Classification module for FinExtract."""
from src.classification.rule_engine import get_rule_engine
from src.classification.ml_classifier import get_model, predict, load_model
