"""Transaction categories for FinExtract."""

CATEGORIES = [
    "Salary",
    "Income",
    "Food & Dining",
    "Groceries",
    "Shopping",
    "Transportation",
    "Fuel",
    "Utilities",
    "Rent",
    "Healthcare",
    "Education",
    "Entertainment",
    "Travel",
    "ATM/Cash Withdrawal",
    "Bank Charges",
    "Loan/EMI",
    "Investment",
    "Insurance",
    "Transfers",
    "Unclassified",
]

INCOME_CATEGORIES = {"Salary", "Income"}
EXPENSE_CATEGORIES = {
    "Food & Dining", "Groceries", "Shopping", "Transportation", "Fuel",
    "Utilities", "Rent", "Healthcare", "Education", "Entertainment",
    "Travel", "ATM/Cash Withdrawal", "Bank Charges", "Loan/EMI",
    "Investment", "Insurance"
}
TRANSFER_CATEGORIES = {"Transfers"}
