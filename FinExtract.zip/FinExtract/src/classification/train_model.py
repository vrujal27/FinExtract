"""Model training script for FinExtract ML classifier."""
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, Tuple

import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, f1_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline

from src.config import (
    CATEGORIES, CLASSIFIER_PATH, CLASSIFIER_META_PATH, TRAINING_DATA_PATH
)
from src.utils.helpers import normalize_description

logger = logging.getLogger("finextract.train_model")


def load_training_data(csv_path: str = None) -> pd.DataFrame:
    """Load training data from CSV."""
    path = csv_path or str(TRAINING_DATA_PATH)
    try:
        df = pd.read_csv(path)
        logger.info(f"Loaded {len(df)} training samples from {path}")
        return df
    except Exception as e:
        logger.error(f"Failed to load training data: {e}")
        return pd.DataFrame()


def train_classifier(csv_path: str = None) -> Tuple[Pipeline, Dict]:
    """
    Train the TF-IDF + Logistic Regression classifier.
    
    Returns:
        (trained_pipeline, metrics_dict)
    """
    df = load_training_data(csv_path)
    if df.empty:
        raise ValueError("No training data available.")
    
    if "description" not in df.columns or "category" not in df.columns:
        raise ValueError("Training data must have 'description' and 'category' columns.")
    
    # Clean and filter
    df = df.dropna(subset=["description", "category"])
    df["description_normalized"] = df["description"].apply(normalize_description)
    df = df[df["description_normalized"].str.len() > 0]
    
    # Filter to known categories
    df = df[df["category"].isin(CATEGORIES)]
    
    # Check class distribution
    class_counts = df["category"].value_counts()
    logger.info(f"Class distribution:\n{class_counts}")
    
    # Remove classes with too few examples (< 2 needed for stratified split)
    min_samples = 2
    valid_classes = class_counts[class_counts >= min_samples].index
    removed = set(df["category"].unique()) - set(valid_classes)
    if removed:
        logger.warning(f"Dropping classes with < {min_samples} samples: {removed}")
    df = df[df["category"].isin(valid_classes)]
    
    if len(df) < 10:
        raise ValueError(f"Too few samples after filtering: {len(df)}")
    
    X = df["description_normalized"].values
    y = df["category"].values
    
    # Stratified split
    try:
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )
    except ValueError:
        logger.warning("Stratified split failed, using random split.")
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42
        )
    
    # Build pipeline - try both word and char n-grams
    pipeline = Pipeline([
        ("tfidf", TfidfVectorizer(
            analyzer="char_wb",
            ngram_range=(2, 4),
            max_features=50000,
            sublinear_tf=True,
            min_df=1,
        )),
        ("clf", LogisticRegression(
            max_iter=1000,
            C=5.0,
            class_weight="balanced",
            random_state=42,
            solver="lbfgs",
        )),
    ])
    
    pipeline.fit(X_train, y_train)
    
    # Evaluate
    y_pred = pipeline.predict(X_test)
    report = classification_report(y_test, y_pred, output_dict=True, zero_division=0)
    cm = confusion_matrix(y_test, y_pred).tolist()
    
    metrics = {
        "trained_at": datetime.utcnow().isoformat(),
        "train_samples": len(X_train),
        "test_samples": len(X_test),
        "total_samples": len(df),
        "classes": list(pipeline.classes_),
        "data_source": "synthetic",
        "sklearn_version": sklearn.__version__,
        "accuracy": report.get("accuracy", 0.0),
        "macro_f1": report.get("macro avg", {}).get("f1-score", 0.0),
        "classification_report": report,
        "confusion_matrix": cm,
        "note": "TRAINED ON SYNTHETIC DATA. Real-world accuracy may differ significantly.",
    }
    
    logger.info(f"Model trained. Accuracy: {metrics['accuracy']:.3f}, Macro F1: {metrics['macro_f1']:.3f}")
    
    # Save model
    CLASSIFIER_PATH.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(pipeline, CLASSIFIER_PATH)
    
    with open(CLASSIFIER_META_PATH, "w") as f:
        json.dump(metrics, f, indent=2, default=str)
    
    logger.info(f"Model saved to {CLASSIFIER_PATH}")
    return pipeline, metrics
