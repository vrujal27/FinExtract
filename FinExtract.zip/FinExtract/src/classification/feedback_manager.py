"""Manages user feedback and category corrections."""
import logging
import uuid
from datetime import datetime
from typing import Dict, Optional

from src.database.collections import (
    update_transaction_category, insert_correction, get_corrections
)

logger = logging.getLogger("finextract.feedback_manager")


def apply_correction(
    transaction_id: str,
    job_id: str,
    previous_category: str,
    corrected_category: str,
    classification_method: str = "MANUAL",
) -> bool:
    """Apply a category correction from user feedback."""
    try:
        # Update transaction
        success = update_transaction_category(transaction_id, corrected_category, "MANUAL")
        if not success:
            logger.warning(f"Transaction not found for correction: {transaction_id}")
            return False
        
        # Store correction record
        correction = {
            "correction_id": f"COR-{uuid.uuid4().hex[:12].upper()}",
            "transaction_id": transaction_id,
            "job_id": job_id,
            "previous_category": previous_category,
            "corrected_category": corrected_category,
            "timestamp": datetime.utcnow(),
            "classification_method": classification_method,
        }
        insert_correction(correction)
        logger.info(f"Correction applied: {transaction_id} -> {corrected_category}")
        return True
    except Exception as e:
        logger.error(f"Failed to apply correction: {e}")
        return False
