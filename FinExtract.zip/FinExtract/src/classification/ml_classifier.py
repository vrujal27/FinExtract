"""ML-based transaction classification using TF-IDF + Logistic Regression."""
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import joblib
import numpy as np
from sklearn.pipeline import Pipeline

from src.config import CLASSIFIER_PATH, CLASSIFIER_META_PATH, CATEGORIES
from src.utils.helpers import normalize_description

logger = logging.getLogger("finextract.ml_classifier")

_pipeline: Optional[Pipeline] = None
_meta: Optional[Dict] = None


def load_model() -> Tuple[Optional[Pipeline], Optional[Dict]]:
    """Load the trained classifier pipeline and metadata."""
    global _pipeline, _meta
    
    if not CLASSIFIER_PATH.exists():
        logger.warning(f"Model file not found: {CLASSIFIER_PATH}")
        return None, None
    
    try:
        _pipeline = joblib.load(CLASSIFIER_PATH)
        
        if CLASSIFIER_META_PATH.exists():
            with open(CLASSIFIER_META_PATH, "r") as f:
                _meta = json.load(f)
        else:
            _meta = {}
        
        logger.info(f"ML model loaded from {CLASSIFIER_PATH}")
        return _pipeline, _meta
    except Exception as e:
        logger.error(f"Failed to load model: {e}")
        _pipeline = None
        _meta = None
        return None, None


def get_model() -> Optional[Pipeline]:
    """Get the loaded model (load if not loaded)."""
    global _pipeline
    if _pipeline is None:
        load_model()
    return _pipeline


def predict(description: str) -> Tuple[str, float]:
    """
    Predict category for a transaction description.
    
    Returns:
        (predicted_category, confidence)
    """
    model = get_model()
    if model is None:
        return "Unclassified", 0.0
    
    try:
        normalized = normalize_description(description)
        if not normalized:
            return "Unclassified", 0.0
        
        probabilities = model.predict_proba([normalized])[0]
        predicted_index = np.argmax(probabilities)
        predicted_category = model.classes_[predicted_index]
        confidence = float(probabilities[predicted_index])
        
        return predicted_category, confidence
    except Exception as e:
        logger.error(f"ML prediction failed: {e}")
        return "Unclassified", 0.0


def predict_batch(descriptions: List[str]) -> List[Tuple[str, float]]:
    """Predict categories for multiple descriptions."""
    model = get_model()
    if model is None:
        return [("Unclassified", 0.0)] * len(descriptions)
    
    try:
        normalized = [normalize_description(d) for d in descriptions]
        probabilities = model.predict_proba(normalized)
        results = []
        for probs in probabilities:
            idx = np.argmax(probs)
            results.append((model.classes_[idx], float(probs[idx])))
        return results
    except Exception as e:
        logger.error(f"Batch ML prediction failed: {e}")
        return [("Unclassified", 0.0)] * len(descriptions)
