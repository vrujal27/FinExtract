"""Hybrid classification engine combining rules and ML."""
import logging
from typing import Dict, Optional

from src.config import ML_HIGH_CONFIDENCE, ML_REVIEW_THRESHOLD
from src.classification.rule_engine import get_rule_engine
from src.classification.ml_classifier import predict as ml_predict, get_model

logger = logging.getLogger("finextract.hybrid_classifier")


def classify_transaction(description: str, is_credit: bool = None) -> Dict:
    """
    Hybrid classification: rules first, then ML.
    
    Returns:
        {
            "category": str,
            "predicted_category": str,
            "classification_method": str,
            "ml_confidence": float or None,
            "rule_id": str or None,
            "rule_match_strength": str or None,
            "review_required": bool,
            "explanation": str,
        }
    """
    result = {
        "category": "Unclassified",
        "predicted_category": "Unclassified",
        "classification_method": "UNCLASSIFIED",
        "ml_confidence": None,
        "rule_id": None,
        "rule_match_strength": None,
        "review_required": True,
        "explanation": "No classification applied.",
    }
    
    if not description or not description.strip():
        return result
    
    # Step 1: Try rule engine
    rule_engine = get_rule_engine()
    category, rule_id, explanation = rule_engine.classify(description, is_credit)
    
    if category and rule_id:
        result["category"] = category
        result["predicted_category"] = category
        result["classification_method"] = "RULE_BASED"
        result["rule_id"] = rule_id
        result["rule_match_strength"] = "HIGH"
        result["review_required"] = False
        result["explanation"] = f"Matched rule {rule_id}: {explanation}"
        return result
    
    # Step 2: Try ML classifier
    model = get_model()
    if model is not None:
        ml_category, ml_confidence = ml_predict(description)
        result["ml_confidence"] = ml_confidence
        result["predicted_category"] = ml_category
        
        if ml_confidence >= ML_HIGH_CONFIDENCE:
            result["category"] = ml_category
            result["classification_method"] = "MACHINE_LEARNING"
            result["review_required"] = False
            result["explanation"] = f"ML prediction: {ml_category} (confidence: {ml_confidence:.1%})"
        elif ml_confidence >= ML_REVIEW_THRESHOLD:
            result["category"] = ml_category
            result["classification_method"] = "MACHINE_LEARNING"
            result["review_required"] = True
            result["explanation"] = f"ML prediction (review recommended): {ml_category} (confidence: {ml_confidence:.1%})"
        else:
            result["category"] = "Unclassified"
            result["classification_method"] = "MACHINE_LEARNING"
            result["review_required"] = True
            result["explanation"] = f"Low ML confidence ({ml_confidence:.1%}). Manual review needed."
    else:
        result["explanation"] = "No ML model available. Rules-only mode."
        result["classification_method"] = "RULES_ONLY_NO_MATCH"
    
    return result


def classify_transactions_batch(transactions: list) -> list:
    """Classify a list of transaction dicts in-place."""
    for txn in transactions:
        description = txn.get("description", "")
        is_credit = None
        if txn.get("credit") is not None and txn.get("debit") is None:
            is_credit = True
        elif txn.get("debit") is not None and txn.get("credit") is None:
            is_credit = False
        
        classification = classify_transaction(description, is_credit)
        txn.update(classification)
    return transactions
