#!/usr/bin/env python3
"""
Generate synthetic training dataset for FinExtract ML classification.
IMPORTANT: Synthetic data only. Not real financial records.
"""
import csv
import random
import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

DATA_DIR = Path(__file__).parent.parent / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)

TRAINING_TEMPLATES = {
    "Salary": [
        "SALARY CREDIT FROM {company}",
        "MONTHLY SALARY {company} FOR {month}",
        "SALARY TRANSFER {company}",
        "PAYROLL CREDIT {company}",
        "NET SALARY {month} {company}",
        "SALARY ADVANCE PARTIAL {company}",
        "PAYROLL {company} CORP SALARY",
        "WAGES CREDIT {company} STAFF",
        "SALARY {month} DIRECT DEPOSIT {company}",
        "SALARY DISBURSEMENT {company}",
    ],
    "Income": [
        "INTEREST CREDIT SAVINGS ACCOUNT",
        "FD INTEREST CREDIT QUARTERLY",
        "DIVIDEND CREDIT {company}",
        "FREELANCE PAYMENT {company}",
        "CONSULTING FEE RECEIVED",
        "CONTRACT PAYMENT FROM {company}",
        "PROFESSIONAL FEE CREDIT",
        "BONUS CREDIT {company}",
        "CASHBACK CREDIT REWARD",
        "REFUND CREDIT AMAZON INDIA",
        "INTEREST CREDIT FD MATURITY",
        "RD MATURITY CREDIT TO ACCOUNT",
        "SAVINGS INTEREST CREDITED BANK",
        "DIVIDEND PAYOUT {company}",
    ],
    "Food & Dining": [
        "SWIGGY ORDER",
        "ZOMATO FOOD ORDER",
        "DOMINOS PIZZA OUTLET",
        "KFC RESTAURANT DINING",
        "MCDONALDS FOOD OUTLET",
        "STARBUCKS COFFEE CAFE",
        "PIZZA HUT ONLINE ORDER",
        "RESTAURANT PAYMENT DINING",
        "CAFE COFFEE DAY BEVERAGES",
        "BURGER KING OUTLET",
        "HOTEL RESTAURANT BILL",
        "DINING OUT PAYMENT",
        "SWIGGY INSTAMART SNACKS",
        "ZOMATO PRO SUBSCRIPTION",
        "BARBEQUE NATION DINNER",
        "SUBWAY SANDWICHES",
        "HALDIRAMS SWEETS AND RESTAURANT",
        "FOOD COURT MALL DINING",
        "SWIGGY FOOD DELIVERY MUMBAI",
        "ZOMATO TECHNOLOGIES MEAL",
    ],
    "Groceries": [
        "BIGBASKET GROCERY ORDER",
        "BLINKIT DELIVERY GROCERIES",
        "GROFERS ORDER SUPERMARKET",
        "DMART SUPERMARKET RETAIL",
        "RELIANCE FRESH VEGETABLES",
        "MORE MEGASTORE GROCERY",
        "NATURE BASKET ORGANIC",
        "BIGBASKET BBDAILY DAILY MILK",
        "BLINKIT QUICK COMMERCE ESSENTIALS",
        "DMART HYPERMARKET STORE",
        "RELIANCE SMART BAZAAR",
        "LULU HYPERMARKET GROCERY",
        "SPENCER RETAIL STORE",
        "STAR BAZAAR GROCERY PURCHASE",
        "JIOMART ONLINE GROCERY",
    ],
    "Shopping": [
        "AMAZON RETAIL INDIA PURCHASE",
        "FLIPKART INTERNET SHOPPING",
        "MYNTRA FASHION APPAREL",
        "AJIO FASHION TRENDS",
        "MEESHO ONLINE SHOPPING",
        "NYKAA BEAUTY AND COSMETICS",
        "SNAPDEAL ECOMMERCE",
        "CROMA ELECTRONICS STORE",
        "VIJAY SALES APPLIANCES",
        "AMAZON MARKETPLACE INDIA",
        "FLIPKART FESTIVE SALE",
        "TATACLIQ ONLINE STORE",
        "SHOPPERS STOP RETAIL",
        "WESTSIDE CLOTHING PURCHASE",
        "H AND M APPAREL STORE",
        "IKEA FURNITURE AND HOME",
        "PEPPERFRY HOME DECOR",
        "URBAN LADDER FURNITURE",
    ],
    "Transportation": [
        "UBER INDIA TRIP CHARGE",
        "OLA CABS RIDE PAYMENT",
        "RAPIDO BIKE TAXI COMMUTE",
        "INDRIVE CITY CAB",
        "METRO CARD RECHARGE COUNTER",
        "BUS TICKET MSRTC BOOKING",
        "AUTO RICKSHAW FARE",
        "UBER TRIP AIRPORT DROP",
        "OLA MONEY RIDE FARE",
        "CITY TAXI FARE COMMUTE",
    ],
    "Fuel": [
        "PETROL PUMP PAYMENT",
        "INDIAN OIL FUEL STATION",
        "HINDUSTAN PETROLEUM FUELS",
        "BHARAT PETROLEUM PUMP",
        "HP PETROL STATION REFUEL",
        "IOCL FUEL OUTLET",
        "DIESEL FILLING STATION",
        "CNG GAS STATION FILLING",
        "SHELL PETROL STATION",
        "BPCL PETROL PUMP EXPRESSWAY",
    ],
    "Utilities": [
        "ELECTRICITY BILL BESCOM BANGALORE",
        "TATA POWER ELECTRICITY BILL",
        "BSES RAJDHANI POWER BILL",
        "WATER BILL BWSSB SUPPLY",
        "GAS BILL PNG INDRAPRASTHA",
        "MAHANAGAR GAS BILL PAYMENT",
        "AIRTEL MOBILE BILL POSTPAID",
        "VODAFONE IDEA RECHARGE",
        "BSNL BROADBAND BILL",
        "JIOFIBER FIBER INTERNET BILL",
        "TATA PLAY DTH SUBSCRIPTION",
        "DISH TV RECHARGE DTH",
        "ACT FIBERNET INTERNET BILL",
        "MSEDCL MAHARASHTRA POWER BILL",
    ],
    "Rent": [
        "HOUSE RENT PAYMENT TO LANDLORD",
        "RENTAL PAYMENT FOR {month}",
        "LANDLORD APARTMENT RENT",
        "MONTHLY FLAT RENT TRANSFER",
        "FLAT RENT TO OWNER",
        "RESIDENTIAL APARTMENT LEASE",
        "PG ACCOMMODATION RENT",
        "HOSTEL RENT AND MESS FEE",
    ],
    "Healthcare": [
        "APOLLO PHARMACY MEDICINES",
        "NETMEDS PHARMACY ORDER",
        "1MG HEALTHCARE PHARMACY",
        "APOLLO HOSPITAL OPD BILL",
        "FORTIS HEALTHCARE TREATMENT",
        "MAX HOSPITAL CONSULTATION",
        "MEDICAL STORE PRESCRIPTION",
        "DOCTOR CLINIC CONSULTATION FEE",
        "MANIPAL HOSPITAL HEALTH CHECK",
        "MEDPLUS MEDICAL STORE",
        "DIAGNOSTIC PATHOLOGY LAB TEST",
    ],
    "Education": [
        "BYJU LEARNING APP SUBSCRIPTION",
        "VEDANTU TUITION CLASS",
        "UNACADEMY SUBSCRIPTION",
        "UDEMY ONLINE COURSE PURCHASE",
        "COURSERA LEARNING PROGRAM",
        "SCHOOL QUARTERLY TUITION FEE",
        "COLLEGE SEMESTER TUITION",
        "UNIVERSITY ADMISSION FEE",
        "EXAM REGISTRATION FEE",
        "ACADEMIC COACHING INSTITUTE FEE",
    ],
    "Entertainment": [
        "NETFLIX STREAMING SUBSCRIPTION",
        "AMAZON PRIME VIDEO ANNUAL",
        "DISNEY PLUS HOTSTAR VIP",
        "SPOTIFY PREMIUM MUSIC",
        "YOUTUBE PREMIUM SUBSCRIPTION",
        "APPLE MUSIC MONTHLY PLAN",
        "JIOSAAVN PRO SUBSCRIPTION",
        "PVR CINEMAS MOVIE TICKETS",
        "INOX LEISURE MULTIPLEX",
        "BOOKMYSHOW CINEMA BOOKING",
        "THEATRE CONCERT EVENT TICKET",
    ],
    "Travel": [
        "IRCTC TRAIN TICKET BOOKING",
        "INDIAN RAILWAYS RESERVATION",
        "INDIGO AIRLINES FLIGHT",
        "AIR INDIA DOMESTIC TICKET",
        "SPICEJET AIRWAYS FLIGHT",
        "MAKEMYTRIP HOTEL BOOKING",
        "GOIBIBO FLIGHT TICKETS",
        "YATRA TRAVEL RESERVATION",
        "CLEARTRIP FLIGHT BOOKING",
        "BOOKING COM RESORT STAY",
        "REDBUS INTERCITY BUS TICKET",
    ],
    "ATM/Cash Withdrawal": [
        "ATM CASH WITHDRAWAL HDFC",
        "ATM WITHDRAWAL ICICI BANK",
        "ATM WDL SBI CASH DISPENSER",
        "ATM CASH WITHDRAWAL AXIS",
        "CASH WITHDRAWAL ATM NATIVE",
        "SELF CASH WDL BRANCH ATM",
    ],
    "Bank Charges": [
        "BANK SERVICE CHARGES QUARTERLY",
        "SMS ALERT CHARGES DEBIT",
        "ANNUAL MAINTENANCE CHARGE DEBIT CARD",
        "PROCESSING FEE LOAN DEDUCTION",
        "LATE PAYMENT PENALTY CHARGE",
        "CHEQUE RETURN CHARGES UNPAID",
        "MINIMUM BALANCE NON MAINTENANCE CHARGE",
        "ATM OVERUSE TRANSACTION CHARGE",
    ],
    "Loan/EMI": [
        "HOUSING LOAN MONTHLY EMI",
        "CAR LOAN AUTO DEBIT EMI",
        "PERSONAL LOAN INSTALLMENT",
        "HDFC BANK LOAN REPAYMENT",
        "ICICI BANK HOME LOAN EMI",
        "SBI AUTO LOAN EMI PAYMENT",
        "AXIS BANK PERSONAL LOAN EMI",
        "BAJAJ FINANCE CONSUMER EMI",
    ],
    "Investment": [
        "MUTUAL FUND MONTHLY SIP",
        "ZERODHA BROKING EQUITY FUNDS",
        "GROWW MUTUAL FUND INVESTMENT",
        "UPSTOX SECURITIES TRADING",
        "KUVERA WEALTH MF PURCHASE",
        "NATIONAL STOCK EXCHANGE SHARE PURCHASE",
        "HDFC MUTUAL FUND SYSTEMATIC PLAN",
        "SBI EQUITY HYBRID FUND SIP",
    ],
    "Insurance": [
        "LIC LIFE INSURANCE PREMIUM",
        "HDFC LIFE INSURANCE POLICY",
        "SBI LIFE INSURANCE ANNUAL PREMIUM",
        "MAX LIFE INSURANCE PAYMENT",
        "TATA AIG GENERAL INSURANCE",
        "BAJAJ ALLIANZ HEALTH POLICY",
        "STAR HEALTH INSURANCE PREMIUM",
        "MOTOR VEHICLE INSURANCE RENEWAL",
    ],
    "Transfers": [
        "NEFT TRANSFER TO OWN SAVINGS",
        "SELF TRANSFER LINKED ACCOUNT",
        "INTERNAL FUND TRANSFER SECONDARY A/C",
        "IMPS TO FAMILY MEMBER",
        "TRANSFER TO JOINT SAVINGS ACCOUNT",
        "SWEEP TO FIXED DEPOSIT ACCOUNT",
    ],
    "Unclassified": [
        "NEFT PAYMENT REFERENCE MISC",
        "IMPS SETTLEMENT TRANSACTION",
        "UPI PAYMENT TO UNKNOWN ENTITY",
        "RTGS SETTLEMENT GENERAL",
        "MISCELLANEOUS CLEARING DEBIT",
        "GENERAL STORE PURCHASE UNKNOWN",
        "CLEARING SYSTEM SETTLEMENT",
    ],
}

COMPANIES = [
    "ACME CORP", "TECHSOLUTIONS LTD", "GLOBAL SYSTEMS", "INFOSYS LTD",
    "TATA CONSULTANCY", "WIPRO ENTERPRISES", "HCL TECHNOLOGIES",
    "COGNIZANT TECH", "DELOITTE CONSULTING", "ACCENTURE SERVICES"
]

MONTHS = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"]


def generate_training_data(samples_per_class: int = 80) -> list:
    """Generate diverse synthetic transactions for training."""
    data = []
    prefixes = ["", "UPI-", "NEFT-", "IMPS-", "POS/", "E-COM/"]

    for category, templates in TRAINING_TEMPLATES.items():
        generated = set()
        attempts = 0
        while len(generated) < samples_per_class and attempts < samples_per_class * 10:
            attempts += 1
            template = random.choice(templates)
            company = random.choice(COMPANIES)
            month = random.choice(MONTHS)
            amount = str(random.randint(100, 75000))

            text = template.format(company=company, month=month, amount=amount)

            # Randomly add prefix or noise
            prefix = random.choice(prefixes)
            ref_num = f"{random.randint(10000000, 99999999)}" if random.random() > 0.6 else ""
            desc = f"{prefix}{text} {ref_num}".strip()

            if desc not in generated:
                generated.add(desc)
                data.append({"description": desc, "category": category})

    random.shuffle(data)
    return data


def main():
    print("Generating synthetic training data...")
    dataset = generate_training_data(samples_per_class=100)
    output_path = DATA_DIR / "training_transactions.csv"

    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["description", "category"])
        writer.writeheader()
        writer.writerows(dataset)

    print(f"Generated {len(dataset)} synthetic training records at {output_path}")


if __name__ == "__main__":
    main()

