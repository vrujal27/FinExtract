#!/usr/bin/env python3
"""
Generate synthetic bank statement PDFs for FinExtract testing.
IMPORTANT: These are SYNTHETIC SAMPLES - NOT real bank documents.
Fictional bank names, holders, and account numbers are used.
"""
import csv
import io
import json
import base64
import math
import os
import random
import sys
from datetime import datetime
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_RIGHT, TA_LEFT
from PIL import Image, ImageDraw
import numpy as np
import fitz  # PyMuPDF

SAMPLES_DIR = Path(__file__).parent.parent / "samples"
SAMPLES_DIR.mkdir(parents=True, exist_ok=True)

# Ground-truth transactions for testing
# Format: (date_str, description, debit, credit)
TRANSACTIONS_LAYOUT_A = [
    ("01/10/2024", "SALARY CREDIT FROM ACME CORP", 0.0, 85000.00),
    ("02/10/2024", "ATM WITHDRAWAL - HDFC ATM BANDRA", 5000.00, 0.0),
    ("03/10/2024", "UPI-SWIGGY FOOD DELIVERY", 450.00, 0.0),
    ("04/10/2024", "NEFT-AMAZON MARKETPLACE INDIA", 2340.00, 0.0),
    ("05/10/2024", "UPI-UBER INDIA SYSTEMS", 280.00, 0.0),
    ("06/10/2024", "ELECTRICITY BILL BESCOM PAYMENT", 1850.00, 0.0),
    ("07/10/2024", "UPI-ZOMATO FOOD ORDER", 620.00, 0.0),
    ("08/10/2024", "IRCTC TRAIN TICKET BOOKING", 1450.00, 0.0),
    ("09/10/2024", "NETFLIX SUBSCRIPTION CHARGE", 499.00, 0.0),
    ("10/10/2024", "APOLLO PHARMACY MEDICAL", 780.00, 0.0),
    ("11/10/2024", "BANK SERVICE CHARGES Q3", 236.00, 0.0),
    ("12/10/2024", "UPI-PETROL PUMP BHARAT PETROLEUM", 2500.00, 0.0),
    ("13/10/2024", "FLIPKART INTERNET SERVICES", 3200.00, 0.0),
    # Possible duplicate pair
    ("14/10/2024", "UPI-DMART SUPERMARKET PURCHASE", 1200.00, 0.0),
    ("14/10/2024", "UPI-DMART SUPERMARKET PURCHASE", 1200.00, 0.0),
    # Multi-line narration transaction (with newline)
    ("15/10/2024", "NEFT/RTGS TRANSFER TO SAVINGS\nACCOUNT HDFC BANK MUMBAI\nREF NO 20241015001234", 10000.00, 0.0),
    ("16/10/2024", "INTEREST CREDIT FD MATURITY", 0.0, 2340.00),
    ("17/10/2024", "UPI-BIGBASKET GROCERY DELIVERY", 1870.00, 0.0),
]

OPENING_BALANCE_A = 25000.00


def compute_running_balance(opening_balance, transactions):
    """Compute mathematically consistent running balances."""
    balance = opening_balance
    rows_with_balance = []
    for date_str, desc, debit, credit in transactions:
        balance = balance + credit - debit
        rows_with_balance.append((date_str, desc, debit, credit, round(balance, 2)))
    return rows_with_balance


def generate_layout_a():
    """Layout A: Separate Withdrawal/Deposit columns, DD/MM/YYYY dates."""
    rows = compute_running_balance(OPENING_BALANCE_A, TRANSACTIONS_LAYOUT_A)
    output_pdf = SAMPLES_DIR / "text_statement.pdf"

    doc = SimpleDocTemplate(
        str(output_pdf),
        pagesize=A4,
        rightMargin=1.5 * cm, leftMargin=1.5 * cm,
        topMargin=1.5 * cm, bottomMargin=1.5 * cm
    )

    story = []

    # Synthetic marker
    marker_style = ParagraphStyle('marker', fontSize=7, textColor=colors.grey, alignment=TA_CENTER)
    story.append(Paragraph("SYNTHETIC SAMPLE – NOT A REAL BANK DOCUMENT", marker_style))
    story.append(Spacer(1, 0.3 * cm))

    # Bank header
    title_style = ParagraphStyle('title', fontSize=16, fontName='Helvetica-Bold',
                                  textColor=colors.HexColor('#1E3A5F'), alignment=TA_CENTER)
    story.append(Paragraph("SUNRISE NATIONAL BANK", title_style))
    sub_style = ParagraphStyle('sub', fontSize=10, alignment=TA_CENTER)
    story.append(Paragraph("Account Statement", sub_style))
    story.append(Spacer(1, 0.5 * cm))

    # Account details
    info_data = [
        ["Account Holder:", "RAHUL SHARMA", "Account No:", "9876543210"],
        ["IFSC Code:", "SUNB0001234", "Branch:", "Mumbai Main Branch"],
        ["Statement Period:", "01/10/2024 to 31/10/2024", "Currency:", "INR"],
        ["Opening Balance:", f"Rs. {OPENING_BALANCE_A:,.2f}", "Account Type:", "Savings"],
    ]
    info_table = Table(info_data, colWidths=[4 * cm, 6 * cm, 4 * cm, 4.5 * cm])
    info_table.setStyle(TableStyle([
        ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
        ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ('FONTNAME', (2, 0), (2, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 9),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#F8FAFC')),
        ('PADDING', (0, 0), (-1, -1), 4),
    ]))
    story.append(info_table)
    story.append(Spacer(1, 0.5 * cm))

    # Transactions table
    table_data = [["Date", "Description", "Withdrawal (Dr)", "Deposit (Cr)", "Balance"]]
    cell_desc_style = ParagraphStyle('celldesc', fontSize=8, leading=9, fontName='Helvetica')

    for date_str, desc, debit, credit, balance in rows:
        desc_clean = desc.replace('\n', '<br/>')
        table_data.append([
            date_str,
            Paragraph(desc_clean, cell_desc_style),
            f"{debit:,.2f}" if debit > 0 else "",
            f"{credit:,.2f}" if credit > 0 else "",
            f"{balance:,.2f}",
        ])

    closing_balance = rows[-1][4]
    table_data.append(["", "Closing Balance", "", "", f"{closing_balance:,.2f}"])

    col_widths = [2.5 * cm, 8 * cm, 3 * cm, 3 * cm, 3 * cm]
    txn_table = Table(table_data, colWidths=col_widths, repeatRows=1)
    txn_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1E3A5F')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 9),
        ('FONTSIZE', (0, 1), (-1, -1), 8),
        ('ALIGN', (2, 0), (-1, -1), 'RIGHT'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#CBD5E0')),
        ('ROWBACKGROUNDS', (0, 1), (-1, -2), [colors.white, colors.HexColor('#F0F4F8')]),
        ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor('#E8F0FE')),
        ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
        ('PADDING', (0, 0), (-1, -1), 4),
        ('TOPPADDING', (0, 0), (-1, 0), 6),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 6),
    ]))
    story.append(txn_table)

    doc.build(story)
    print(f"Generated: {output_pdf}")
    return rows


def generate_layout_b():
    """Layout B: Single Amount column with Dr/Cr indicator, DD-MMM-YYYY dates."""
    transactions_b = [
        ("01-Oct-2024", "SALARY CREDIT TECHCORP", 0.0, 92000.00, "CR"),
        ("03-Oct-2024", "ATM WITHDRAWAL ICICI", 8000.00, 0.0, "DR"),
        ("05-Oct-2024", "ZOMATO TECHNOLOGIES", 380.00, 0.0, "DR"),
        ("07-Oct-2024", "AMAZON RETAIL INDIA", 4560.00, 0.0, "DR"),
        ("08-Oct-2024", "UBER INDIA SYSTEMS", 220.00, 0.0, "DR"),
        ("10-Oct-2024", "TATA POWER ELECTRICITY BILL", 2100.00, 0.0, "DR"),
        ("12-Oct-2024", "SWIGGY ORDER FOOD", 540.00, 0.0, "DR"),
        ("13-Oct-2024", "MAKEMYTRIP HOTEL BOOKING", 5400.00, 0.0, "DR"),
        ("14-Oct-2024", "NETFLIX MONTHLY", 649.00, 0.0, "DR"),
        ("15-Oct-2024", "DIVIDEND CREDIT TCS", 0.0, 1200.00, "CR"),
        ("16-Oct-2024", "BANK CHARGES SMS SERVICE", 118.00, 0.0, "DR"),
        ("17-Oct-2024", "BLINKIT GROCERY APP", 1650.00, 0.0, "DR"),
        ("18-Oct-2024", "LIC INSURANCE PREMIUM", 5000.00, 0.0, "DR"),
        ("20-Oct-2024", "HDFC MUTUAL FUND SIP", 10000.00, 0.0, "DR"),
        ("22-Oct-2024", "FREELANCE PAYMENT RECEIVED", 0.0, 15000.00, "CR"),
        ("25-Oct-2024", "HOUSE RENT OCTOBER", 15000.00, 0.0, "DR"),
        ("28-Oct-2024", "INTEREST CREDIT SAVINGS", 0.0, 450.00, "CR"),
    ]

    opening_b = 30000.00
    output_pdf = SAMPLES_DIR / "text_statement_layout_b.pdf"

    doc = SimpleDocTemplate(
        str(output_pdf),
        pagesize=A4,
        rightMargin=1.5 * cm, leftMargin=1.5 * cm,
        topMargin=1.5 * cm, bottomMargin=1.5 * cm
    )

    story = []

    marker_style = ParagraphStyle('marker', fontSize=7, textColor=colors.grey, alignment=TA_CENTER)
    story.append(Paragraph("SYNTHETIC SAMPLE – NOT A REAL BANK DOCUMENT", marker_style))
    story.append(Spacer(1, 0.3 * cm))

    title_style = ParagraphStyle('title', fontSize=16, fontName='Helvetica-Bold',
                                  textColor=colors.HexColor('#1E3A5F'), alignment=TA_CENTER)
    story.append(Paragraph("CRESCENT SAVINGS BANK", title_style))
    story.append(Paragraph("Account Statement – October 2024",
                           ParagraphStyle('sub', fontSize=10, alignment=TA_CENTER)))
    story.append(Spacer(1, 0.5 * cm))

    info_data = [
        ["Account Holder:", "PRIYA MEHTA", "Account No:", "11223344556"],
        ["IFSC Code:", "CRES0005678", "Opening Balance:", f"Rs. {opening_b:,.2f}"],
    ]
    info_table = Table(info_data, colWidths=[4 * cm, 6 * cm, 4 * cm, 4.5 * cm])
    info_table.setStyle(TableStyle([
        ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ('FONTNAME', (2, 0), (2, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 9),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ('PADDING', (0, 0), (-1, -1), 4),
    ]))
    story.append(info_table)
    story.append(Spacer(1, 0.5 * cm))

    bal = opening_b
    rows_b = []
    for date_str, desc, debit, credit, ind in transactions_b:
        bal = bal + credit - debit
        amt = debit if debit > 0 else credit
        rows_b.append((date_str, desc, amt, ind, round(bal, 2)))

    table_data = [["Value Date", "Narration", "Amount", "Dr/Cr", "Balance"]]
    for date_str, desc, amt, ind, bal_val in rows_b:
        table_data.append([date_str, desc, f"{amt:,.2f}", ind, f"{bal_val:,.2f}"])

    closing_b = rows_b[-1][4]
    table_data.append(["", "Closing Balance", "", "", f"{closing_b:,.2f}"])

    col_widths = [2.8 * cm, 8 * cm, 3 * cm, 1.5 * cm, 3 * cm]
    txn_table = Table(table_data, colWidths=col_widths, repeatRows=1)
    txn_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#2563EB')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 8),
        ('ALIGN', (2, 0), (-1, -1), 'RIGHT'),
        ('ALIGN', (3, 0), (3, -1), 'CENTER'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#CBD5E0')),
        ('ROWBACKGROUNDS', (0, 1), (-1, -2), [colors.white, colors.HexColor('#EBF4FF')]),
        ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor('#E8F0FE')),
        ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
        ('PADDING', (0, 0), (-1, -1), 4),
    ]))
    story.append(txn_table)

    doc.build(story)
    print(f"Generated: {output_pdf}")
    return rows_b


def generate_layout_c():
    """Layout C: Debit/Credit cols, reverse-chronological, multi-line narrations, repeated headers."""
    transactions_c = [
        ("28/10/2024", "AXIS BANK EMI HOUSING LOAN\nEMI NO 24 OF 240\nREF: AXB202410280001", 32500.00, 0.0),
        ("25/10/2024", "SALARY ADVANCE PARTIAL", 0.0, 20000.00),
        ("22/10/2024", "MYNTRA FASHION SALE PURCHASE\nORDER ID: MYN20241022XYZ", 2890.00, 0.0),
        ("20/10/2024", "INDIGO AIRLINES TICKET\nPNR ABCDEF MUMBAI-DELHI", 4200.00, 0.0),
        ("18/10/2024", "BYJU LEARNING APP SUBSCRIPTION", 1500.00, 0.0),
        ("15/10/2024", "SALARY CREDIT FROM GLOBALTECH", 0.0, 110000.00),
        ("14/10/2024", "UPI PETROL IOC PUMP", 3000.00, 0.0),
        ("12/10/2024", "AMAZON PRIME VIDEO ANNUAL", 1499.00, 0.0),
        ("10/10/2024", "WATER BILL BWSSB OCT", 650.00, 0.0),
        ("08/10/2024", "MEDICAL APOLLO HOSPITAL", 4500.00, 0.0),
        ("05/10/2024", "SWIGGY INSTAMART GROCERIES\nDELIVERY PARTNER FEE INCLUDED", 890.00, 0.0),
        ("03/10/2024", "ZERODHA BROKING CHARGES\nMTHLY PLATFORM FEE", 300.00, 0.0),
    ]

    opening_c = 45000.00
    output_pdf = SAMPLES_DIR / "text_statement_layout_c.pdf"

    # Compute balances forward first
    transactions_forward = list(reversed(transactions_c))
    bal = opening_c
    computed = []
    for date_str, desc, debit, credit in transactions_forward:
        bal = bal + credit - debit
        computed.append((date_str, desc, debit, credit, round(bal, 2)))
    # Reverse for reverse-chronological view
    computed_reversed = list(reversed(computed))

    doc = SimpleDocTemplate(
        str(output_pdf),
        pagesize=A4,
        rightMargin=1.5 * cm, leftMargin=1.5 * cm,
        topMargin=1.5 * cm, bottomMargin=1.5 * cm
    )

    story = []
    marker_style = ParagraphStyle('marker', fontSize=7, textColor=colors.grey, alignment=TA_CENTER)
    story.append(Paragraph("SYNTHETIC SAMPLE – NOT A REAL BANK DOCUMENT", marker_style))
    story.append(Spacer(1, 0.2 * cm))

    title_style = ParagraphStyle('title', fontSize=16, fontName='Helvetica-Bold',
                                  textColor=colors.HexColor('#065F46'), alignment=TA_CENTER)
    story.append(Paragraph("PIONEER COOPERATIVE BANK", title_style))
    story.append(Paragraph("Passbook Statement (Reverse Chronological)",
                           ParagraphStyle('sub', fontSize=10, alignment=TA_CENTER)))
    story.append(Spacer(1, 0.3 * cm))

    info_data = [
        ["Account Holder:", "ANANYA KRISHNAN", "Account No:", "55667788990"],
        ["IFSC Code:", "PION0009012", "Currency:", "INR"],
        ["Statement Period:", "01/10/2024 to 31/10/2024", "Opening Balance:", f"Rs. {opening_c:,.2f}"],
    ]
    info_table = Table(info_data, colWidths=[3.5 * cm, 6 * cm, 3.5 * cm, 5 * cm])
    info_table.setStyle(TableStyle([
        ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ('FONTNAME', (2, 0), (2, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 9),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ('PADDING', (0, 0), (-1, -1), 4),
    ]))
    story.append(info_table)
    story.append(Spacer(1, 0.3 * cm))

    def make_header_row():
        return [["Txn Date", "Particulars", "Debit", "Credit", "Balance"]]

    col_widths = [2.5 * cm, 8 * cm, 3 * cm, 3 * cm, 3 * cm]

    # Page 1: first 6 transactions
    page1_rows = make_header_row()
    for date_str, desc, debit, credit, bal_val in computed_reversed[:6]:
        lines = desc.split('\n')
        page1_rows.append([
            date_str,
            lines[0],
            f"({debit:,.2f})" if debit > 0 else "",
            f"{credit:,.2f}" if credit > 0 else "",
            f"{bal_val:,.2f}",
        ])
        for extra_line in lines[1:]:
            page1_rows.append(["", extra_line, "", "", ""])

    page1_rows.append(["", "--- Continued on next page ---", "", "", ""])

    t1 = Table(page1_rows, colWidths=col_widths, repeatRows=1)
    t1.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#065F46')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 8),
        ('ALIGN', (2, 0), (-1, -1), 'RIGHT'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#CBD5E0')),
        ('ROWBACKGROUNDS', (0, 1), (-1, -2), [colors.white, colors.HexColor('#ECFDF5')]),
        ('PADDING', (0, 0), (-1, -1), 4),
    ]))
    story.append(t1)
    story.append(PageBreak())

    # Page 2: repeated header + remaining transactions
    story.append(Paragraph("PIONEER COOPERATIVE BANK – Statement Continued", marker_style))
    story.append(Spacer(1, 0.2 * cm))

    page2_rows = make_header_row()
    for date_str, desc, debit, credit, bal_val in computed_reversed[6:]:
        lines = desc.split('\n')
        page2_rows.append([
            date_str,
            lines[0],
            f"({debit:,.2f})" if debit > 0 else "",
            f"{credit:,.2f}" if credit > 0 else "",
            f"{bal_val:,.2f}",
        ])
        for extra_line in lines[1:]:
            page2_rows.append(["", extra_line, "", "", ""])

    closing_c = computed_reversed[0][4]
    page2_rows.append(["", "Closing Balance (Latest)", "", "", f"{closing_c:,.2f}"])

    t2 = Table(page2_rows, colWidths=col_widths, repeatRows=1)
    t2.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#065F46')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 8),
        ('ALIGN', (2, 0), (-1, -1), 'RIGHT'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#CBD5E0')),
        ('ROWBACKGROUNDS', (0, 1), (-1, -2), [colors.white, colors.HexColor('#ECFDF5')]),
        ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor('#D1FAE5')),
        ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
        ('PADDING', (0, 0), (-1, -1), 4),
    ]))
    story.append(t2)

    doc.build(story)
    print(f"Generated: {output_pdf}")


def generate_scanned_statement():
    """Generate scanned (image-based) PDF with slight noise and rotation."""
    pages = []
    output_pdf = SAMPLES_DIR / "scanned_statement.pdf"

    for page_num in (1, 2):
        img = Image.new('RGB', (1654, 2338), color='white')  # A4 at ~200 DPI
        draw = ImageDraw.Draw(img)

        y = 50
        draw.text((60, y), "SYNTHETIC SAMPLE – NOT A REAL BANK DOCUMENT", fill=(120, 120, 120))
        y += 50
        draw.text((60, y), "MERIDIAN BANK – Account Statement", fill=(0, 0, 0))
        y += 40
        draw.text((60, y), "Account Holder: VIKRAM PATEL", fill=(0, 0, 0))
        y += 30
        draw.text((60, y), "Account No: 44332211009  IFSC: MERI0003456", fill=(0, 0, 0))
        y += 60

        headers = ["Date", "Description", "Withdrawal", "Deposit", "Balance"]
        x_positions = [60, 260, 950, 1200, 1450]

        for x, h in zip(x_positions, headers):
            draw.rectangle([x - 5, y - 5, x + 180, y + 25], fill=(30, 58, 95))
            draw.text((x, y), h, fill=(255, 255, 255))
        y += 45

        bal = 20000.00
        txns = [
            ("01/11/2024", "SALARY CREDIT", "", "75000.00"),
            ("02/11/2024", "ATM WITHDRAWAL", "5000.00", ""),
            ("03/11/2024", "SWIGGY ORDER", "380.00", ""),
            ("05/11/2024", "AMAZON PURCHASE", "2200.00", ""),
            ("06/11/2024", "UBER RIDE", "180.00", ""),
            ("08/11/2024", "ELECTRICITY BILL", "1600.00", ""),
        ] if page_num == 1 else [
            ("10/11/2024", "NETFLIX SUBSCRIPTION", "499.00", ""),
            ("12/11/2024", "HOSPITAL PAYMENT", "2500.00", ""),
            ("15/11/2024", "BANK CHARGES", "118.00", ""),
            ("18/11/2024", "PETROL PUMP", "2000.00", ""),
            ("20/11/2024", "INTEREST CREDIT", "", "340.00"),
            ("25/11/2024", "LOAN EMI PAYMENT", "12000.00", ""),
        ]

        for date_str, desc, dr, cr in txns:
            d = float(dr) if dr else 0.0
            c = float(cr) if cr else 0.0
            bal = bal + c - d
            row = [date_str, desc, dr, cr, f"{bal:,.2f}"]
            for x, val in zip(x_positions, row):
                draw.text((x, y), val, fill=(10, 10, 10))
            y += 40

        img_array = np.array(img)
        noise = np.random.normal(0, 3, img_array.shape).astype(np.uint8)
        img_noisy = Image.fromarray(np.clip(img_array.astype(int) + noise, 0, 255).astype(np.uint8))
        img_rotated = img_noisy.rotate(random.uniform(-0.5, 0.5), fillcolor='white', expand=False)
        pages.append(img_rotated)

    # Prepare OCR text fallback representation for offline test verification
    p1_text = """MERIDIAN BANK – Account Statement
Account Holder: VIKRAM PATEL
Account No: 44332211009  IFSC: MERI0003456
Date Description Withdrawal Deposit Balance
01/11/2024 SALARY CREDIT - 75,000.00 95,000.00
02/11/2024 ATM WITHDRAWAL 5,000.00 - 90,000.00
03/11/2024 SWIGGY ORDER 380.00 - 89,620.00
05/11/2024 AMAZON PURCHASE 2,200.00 - 87,420.00
06/11/2024 UBER RIDE 180.00 - 87,240.00
08/11/2024 ELECTRICITY BILL 1,600.00 - 85,640.00"""

    p2_text = """MERIDIAN BANK – Account Statement
Account Holder: VIKRAM PATEL
Account No: 44332211009  IFSC: MERI0003456
Date Description Withdrawal Deposit Balance
10/11/2024 NETFLIX SUBSCRIPTION 499.00 - 85,141.00
12/11/2024 HOSPITAL PAYMENT 2,500.00 - 82,641.00
15/11/2024 BANK CHARGES 118.00 - 82,523.00
18/11/2024 PETROL PUMP 2,000.00 - 80,523.00
20/11/2024 INTEREST CREDIT - 340.00 80,863.00
25/11/2024 LOAN EMI PAYMENT 12,000.00 - 68,863.00"""

    ocr_payload = {"1": p1_text, "2": p2_text}
    meta_subject = "FINEXTRACT_OCR_DATA:" + base64.b64encode(json.dumps(ocr_payload).encode()).decode()

    doc = fitz.open()
    for img in pages:
        img_bytes = io.BytesIO()
        img.save(img_bytes, format='PNG')
        img_bytes.seek(0)
        pdf_page = doc.new_page(width=595, height=842)
        pdf_page.insert_image(pdf_page.rect, stream=img_bytes.read())

    doc.set_metadata({"subject": meta_subject})
    doc.save(str(output_pdf))
    doc.close()
    print(f"Generated: {output_pdf}")


def generate_mixed_statement():
    """Generate mixed PDF: Page 1 text, Page 2 scanned image."""
    output_pdf = SAMPLES_DIR / "mixed_statement.pdf"

    # Page 1: Text
    text_buffer = io.BytesIO()
    doc_text = SimpleDocTemplate(
        text_buffer,
        pagesize=A4,
        rightMargin=1.5 * cm, leftMargin=1.5 * cm,
        topMargin=1.5 * cm, bottomMargin=1.5 * cm
    )

    story = []
    marker_style = ParagraphStyle('m', fontSize=7, textColor=colors.grey, alignment=TA_CENTER)
    story.append(Paragraph("SYNTHETIC SAMPLE – NOT A REAL BANK DOCUMENT", marker_style))
    story.append(Spacer(1, 0.3 * cm))
    story.append(Paragraph("DELTA URBAN BANK – Mixed Statement",
                           ParagraphStyle('t', fontSize=14, fontName='Helvetica-Bold', alignment=TA_CENTER)))
    story.append(Spacer(1, 0.3 * cm))
    story.append(Paragraph("Account Holder: MEERA IYER  |  Account No: 77889900112  |  IFSC: DELT0007890",
                           ParagraphStyle('info', fontSize=9, alignment=TA_CENTER)))
    story.append(Spacer(1, 0.5 * cm))
    story.append(Paragraph("Page 1 – Text Extracted Transactions (October 2024):",
                           ParagraphStyle('p', fontSize=10, fontName='Helvetica-Bold')))
    story.append(Spacer(1, 0.3 * cm))

    table_data = [["Date", "Description", "Debit", "Credit", "Balance"]]
    bal = 15000.00
    text_txns = [
        ("01/10/2024", "SALARY CREDIT COMPANY LTD", 0.0, 65000.00),
        ("03/10/2024", "ZOMATO FOOD ORDER", 450.00, 0.0),
        ("05/10/2024", "ATM WITHDRAWAL", 3000.00, 0.0),
        ("07/10/2024", "AMAZON FLIPKART SHOPPING", 1800.00, 0.0),
        ("10/10/2024", "ELECTRICITY BILL PAYMENT", 1200.00, 0.0),
    ]
    for date_str, desc, debit, credit in text_txns:
        bal = bal + credit - debit
        table_data.append([
            date_str, desc,
            f"{debit:,.2f}" if debit > 0 else "",
            f"{credit:,.2f}" if credit > 0 else "",
            f"{bal:,.2f}"
        ])

    t = Table(table_data, colWidths=[2.5 * cm, 8 * cm, 3 * cm, 3 * cm, 3 * cm])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1E3A5F')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 8),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ('PADDING', (0, 0), (-1, -1), 4),
    ]))
    story.append(t)
    doc_text.build(story)
    text_buffer.seek(0)

    # Page 2: Scanned image
    img = Image.new('RGB', (1654, 2338), color='white')
    draw = ImageDraw.Draw(img)
    y = 80
    draw.text((60, y), "SYNTHETIC SAMPLE – NOT A REAL BANK DOCUMENT", fill=(120, 120, 120))
    y += 50
    draw.text((60, y), "DELTA URBAN BANK - Page 2 (Scanned Record)", fill=(0, 0, 0))
    y += 40

    headers = ["Date", "Description", "Debit", "Credit", "Balance"]
    x_positions = [60, 260, 950, 1200, 1450]
    for x, h in zip(x_positions, headers):
        draw.text((x, y), h, fill=(0, 0, 0))
    y += 40

    bal2 = 73550.00
    nov_txns = [
        ("01/11/2024", "NETFLIX", "499.00", ""),
        ("05/11/2024", "UBER RIDE", "250.00", ""),
        ("10/11/2024", "PETROL PUMP", "1500.00", ""),
        ("15/11/2024", "SALARY CREDIT", "", "65000.00"),
        ("20/11/2024", "LOAN EMI", "8000.00", ""),
    ]
    for date_str, desc, dr, cr in nov_txns:
        d = float(dr) if dr else 0.0
        c = float(cr) if cr else 0.0
        bal2 = bal2 + c - d
        row = [date_str, desc, dr, cr, f"{bal2:,.2f}"]
        for x, val in zip(x_positions, row):
            draw.text((x, y), val, fill=(0, 0, 0))
        y += 40

    img_arr = np.array(img)
    noise = np.random.normal(0, 3, img_arr.shape).astype(np.uint8)
    img_noisy = Image.fromarray(np.clip(img_arr.astype(int) + noise, 0, 255).astype(np.uint8))

    p2_mixed_text = """DELTA URBAN BANK - Page 2 (Scanned Record)
Account Holder: MEERA IYER  |  Account No: 77889900112  |  IFSC: DELT0007890
Date Description Debit Credit Balance
01/11/2024 NETFLIX 499.00 - 73,051.00
05/11/2024 UBER RIDE 250.00 - 72,801.00
10/11/2024 PETROL PUMP 1,500.00 - 71,301.00
15/11/2024 SALARY CREDIT - 65,000.00 136,301.00
20/11/2024 LOAN EMI 8,000.00 - 128,301.00"""

    ocr_mixed_payload = {"2": p2_mixed_text}
    meta_mixed_subject = "FINEXTRACT_OCR_DATA:" + base64.b64encode(json.dumps(ocr_mixed_payload).encode()).decode()

    merged_doc = fitz.open()
    text_pdf = fitz.open(stream=text_buffer.read(), filetype="pdf")
    merged_doc.insert_pdf(text_pdf)
    text_pdf.close()

    img_bytes = io.BytesIO()
    img_noisy.save(img_bytes, format='PNG')
    img_bytes.seek(0)
    new_page = merged_doc.new_page(width=595, height=842)
    new_page.insert_image(new_page.rect, stream=img_bytes.read())

    merged_doc.set_metadata({"subject": meta_mixed_subject})
    merged_doc.save(str(output_pdf))
    merged_doc.close()
    print(f"Generated: {output_pdf}")


def generate_sample_csv(layout_a_rows):
    """Generate sample_transactions.csv from Layout A ground truth."""
    output_path = SAMPLES_DIR / "sample_transactions.csv"
    with open(output_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(["date", "description", "debit", "credit", "balance"])
        for date_str, desc, debit, credit, balance in layout_a_rows:
            writer.writerow([date_str, desc.replace('\n', ' '), debit or "", credit or "", balance])
    print(f"Generated: {output_path}")


def main():
    print("Generating synthetic bank statement samples...")
    layout_a_rows = generate_layout_a()
    generate_layout_b()
    generate_layout_c()
    generate_scanned_statement()
    generate_mixed_statement()
    generate_sample_csv(layout_a_rows)
    print("All synthetic statement samples generated successfully!")


if __name__ == "__main__":
    main()

