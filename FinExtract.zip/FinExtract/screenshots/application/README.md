# Application Screenshots Checklist

Because automated headless browser capture is not enabled in this CLI environment, capture the following 8 screenshots from the running Streamlit web application (`http://localhost:8501`) to complete visual documentation:

| Filename | Page | Description |
|---|---|---|
| `01_dashboard.png` | **📊 Dashboard** | Executive view showing KPIs, Category pie chart, and Debit vs Credit bar chart with processed statement data. |
| `02_upload_statement.png` | **📤 Upload Statement** | Upload interface showing drag-and-drop zone and extraction progress summary for `text_statement.pdf`. |
| `03_transactions_table.png` | **📋 Transactions** | Interactive table with search filters, amount columns, category badges, and edit category form. |
| `04_classification_centre.png` | **🎯 Classification Centre** | Explanation view showing matched rule IDs (e.g. `R001`), ML confidence scores, and rule engine table. |
| `05_validation_centre.png` | **✅ Validation Centre** | Balance reconciliation status (`PASSED`), duplicate candidate highlights, and validation alerts table. |
| `06_analytics.png` | **📈 Analytics** | Spending matrix, top spending merchants bar chart, and cash flow trend with inter-account transfers excluded. |
| `07_export_centre.png` | **💾 Export Centre** | Download buttons for multi-sheet `.xlsx` workbook and Windows-compatible `.csv` file. |
| `08_processing_history.png` | **📜 Processing History** | Processing jobs audit log showing job IDs, file hashes, execution durations, and cascading delete controls. |

### Capture Instructions:
1. Run `streamlit run app.py`
2. Process `samples/text_statement.pdf`
3. Navigate through each page in your web browser and take a full-window screenshot saving to the filenames above.

