@echo off
setlocal
title FinExtract (Local Python Mode)
cd /d "%~dp0"

echo ====================================================================
echo           FINEXTRACT - LOCAL PYTHON MODE (WITHOUT DOCKER)          
echo ====================================================================
echo.

where python >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Python is not installed or not in PATH.
    pause
    exit /b 1
)

echo Starting FinExtract with Streamlit...
echo The web application will open in your default browser.
echo.
python -m streamlit run app.py --server.port=8501 --server.maxUploadSize=25

pause

