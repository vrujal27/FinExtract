@echo off
cd /d "%~dp0"
call STOP_FINEXTRACT.bat

