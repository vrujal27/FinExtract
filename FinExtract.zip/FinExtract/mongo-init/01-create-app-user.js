// MongoDB init script - creates the application user
// Runs on first container creation only

var appUsername = process.env.MONGO_APP_USERNAME || 'finextract_user';
var appPassword = process.env.MONGO_APP_PASSWORD || 'change_this_password';
var appDatabase = process.env.MONGO_DATABASE || 'finextract';
var testDatabase = appDatabase + '_test';

// Switch to the app database
db = db.getSiblingDB(appDatabase);

// Create the app user with readWrite on app db and test db
db.createUser({
    user: appUsername,
    pwd: appPassword,
    roles: [
        { role: 'readWrite', db: appDatabase },
        { role: 'readWrite', db: testDatabase }
    ]
});

print('Created user: ' + appUsername + ' on databases: ' + appDatabase + ', ' + testDatabase);

// Create initial collections
db.createCollection('processing_jobs');
db.createCollection('accounts');
db.createCollection('transactions');
db.createCollection('user_corrections');
db.createCollection('validation_issues');

print('FinExtract database initialized.');
