"""Test rule-based and ML transaction classification (non-LLM)."""
import pytest
from src.classification.rule_engine import get_rule_engine
from src.classification.hybrid_classifier import classify_transaction
from src.classification.ml_classifier import predict


def test_rule_classification_merchants():
    engine = get_rule_engine()

    cat, rule_id, exp = engine.classify("UPI-SWIGGY BANGALORE ORDER")
    assert cat == "Food & Dining"
    assert rule_id == "R001"

    cat, rule_id, exp = engine.classify("ZOMATO FOOD ORDER GURGAON")
    assert cat == "Food & Dining"
    assert rule_id == "R002"

    cat, rule_id, exp = engine.classify("AMAZON MARKETPLACE INDIA")
    assert cat == "Shopping"

    cat, rule_id, exp = engine.classify("UBER INDIA SYSTEMS RIDE")
    assert cat == "Transportation"

    cat, rule_id, exp = engine.classify("NETFLIX MONTHLY SUBSCRIPTION")
    assert cat == "Entertainment"


def test_upi_alone_not_a_category():
    engine = get_rule_engine()
    # "UPI" by itself is a payment mechanism, not a purpose!
    cat, rule_id, _ = engine.classify("UPI PAYMENT TO MERCHANT")
    # Should NOT be classified as food, grocery, or any specific purpose by rules
    assert cat is None or cat == "Unclassified"


def test_salary_credit_guard():
    engine = get_rule_engine()
    # Salary on credit must match
    cat_credit, _, _ = engine.classify("MONTHLY SALARY CREDIT", is_credit=True)
    assert cat_credit == "Salary"

    # Salary on debit must NOT match
    cat_debit, _, _ = engine.classify("SALARY ADVANCE RECOVERY", is_credit=False)
    assert cat_debit != "Salary"


def test_hybrid_flow():
    # Deterministic merchant matches rules first
    res1 = classify_transaction("UPI-SWIGGY ORDER")
    assert res1["category"] == "Food & Dining"
    assert res1["classification_method"] == "RULE_BASED"
    assert not res1["review_required"]

    # Unknown merchant routes to ML or unclassified
    res2 = classify_transaction("UNKNOWN MERCHANT RANDOM TRANSACTION")
    assert res2["classification_method"] in ("MACHINE_LEARNING", "UNCLASSIFIED")


def test_ml_prediction():
    cat, conf = predict("SALARY CREDIT FROM TECH CORP")
    assert cat == "Salary"
    assert conf > 0.5

