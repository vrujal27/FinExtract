"""Tests package for FinExtract."""
