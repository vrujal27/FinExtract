"""Golden numbers tests for FinExtract sample statements."""
import pytest
from pathlib import Path
from src.processing.transaction_processor import process_statement
from src.extraction.ocr_extractor import TESSERACT_AVAILABLE

SAMPLES_DIR = Path(__file__).parent.parent / "samples"


def test_golden_text_statement():
    pdf_bytes = (SAMPLES_DIR / "text_statement.pdf").read_bytes()
    res = process_statement(pdf_bytes, "text_statement.pdf")
    assert res["success"] is True
    assert len(res["transactions"]) == 18
    assert res["detection"].get("pdf_type") == "text"
    assert res["reconciliation"].get("status") == "PASSED"
    assert res["reconciliation"].get("matched") == 18

    # Verify totals
    debits = sum(t.get("debit") or 0.0 for t in res["transactions"])
    credits = sum(t.get("credit") or 0.0 for t in res["transactions"])
    assert debits > 0
    assert credits > 0


def test_golden_text_statement_layout_b():
    pdf_bytes = (SAMPLES_DIR / "text_statement_layout_b.pdf").read_bytes()
    res = process_statement(pdf_bytes, "text_statement_layout_b.pdf")
    assert res["success"] is True
    assert len(res["transactions"]) == 17
    assert res["detection"].get("pdf_type") == "text"
    assert res["reconciliation"].get("status") == "PASSED"
    assert res["reconciliation"].get("matched") == 17


def test_golden_text_statement_layout_c():
    pdf_bytes = (SAMPLES_DIR / "text_statement_layout_c.pdf").read_bytes()
    res = process_statement(pdf_bytes, "text_statement_layout_c.pdf")
    assert res["success"] is True
    assert len(res["transactions"]) == 12
    assert res["detection"].get("pdf_type") == "text"
    assert res["reconciliation"].get("status") == "PASSED"
    assert res["reconciliation"].get("matched") == 12


@pytest.mark.skipif(not TESSERACT_AVAILABLE, reason="Tesseract OCR not installed on host")
def test_golden_scanned_statement():
    pdf_bytes = (SAMPLES_DIR / "scanned_statement.pdf").read_bytes()
    res = process_statement(pdf_bytes, "scanned_statement.pdf")
    assert res["success"] is True
    assert len(res["transactions"]) == 12
    assert res["detection"].get("pdf_type") == "scanned"
    assert res["reconciliation"].get("status") == "PASSED"


@pytest.mark.skipif(not TESSERACT_AVAILABLE, reason="Tesseract OCR not installed on host")
def test_golden_mixed_statement():
    pdf_bytes = (SAMPLES_DIR / "mixed_statement.pdf").read_bytes()
    res = process_statement(pdf_bytes, "mixed_statement.pdf")
    assert res["success"] is True
    assert len(res["transactions"]) == 10
    assert res["detection"].get("pdf_type") == "mixed"
    assert res["reconciliation"].get("status") == "PASSED"

