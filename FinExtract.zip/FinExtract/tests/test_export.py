"""Test Excel and CSV exporters."""
import io
import openpyxl
from src.exporters.excel_exporter import export_to_excel
from src.exporters.csv_exporter import export_to_csv


def test_excel_export_sheets(mock_transaction):
    txns = [mock_transaction]
    account_info = {"bank_name": "Sunrise Bank", "account_holder": "Rahul Sharma", "opening_balance": 25000.0}
    validation_issues = [{"issue_id": "I1", "transaction_id": "TXN-TEST-00001", "description": "Test warning", "severity": "WARNING"}]
    job_info = {"job_id": "JOB-001", "filename": "statement.pdf", "pdf_type": "text"}

    excel_bytes = export_to_excel(txns, account_info, validation_issues, job_info)
    assert len(excel_bytes) > 0

    wb = openpyxl.load_workbook(io.BytesIO(excel_bytes))
    sheet_names = wb.sheetnames
    assert "Transactions" in sheet_names
    assert "Account Summary" in sheet_names
    assert "Category Summary" in sheet_names
    assert "Validation Report" in sheet_names
    assert "Processing Metadata" in sheet_names


def test_csv_export(mock_transaction):
    txns = [mock_transaction]
    csv_bytes = export_to_csv(txns)
    assert len(csv_bytes) > 0
    # Must have UTF-8 BOM
    assert csv_bytes.startswith(b'\xef\xbb\xbf')

    csv_text = csv_bytes.decode("utf-8-sig")
    assert "transaction_id" in csv_text
    assert "TXN-TEST-00001" in csv_text
    assert "UPI-SWIGGY BANGALORE ORDER" in csv_text

