"""Test MongoDB operations on isolated test database."""
import os
import pytest
from src.config import TEST_MONGODB_URI
from pymongo import MongoClient


@pytest.fixture
def test_db():
    try:
        client = MongoClient(TEST_MONGODB_URI, serverSelectionTimeoutMS=1500)
        client.admin.command("ping")
        db = client.get_default_database()
        if db is None or db.name == "admin":
            db = client["finextract_test"]
        yield db
        # Cleanup test collections
        db.processing_jobs.delete_many({})
        db.transactions.delete_many({})
        db.user_corrections.delete_many({})
        db.validation_issues.delete_many({})
    except Exception as e:
        pytest.skip(f"MongoDB not available for integration tests: {e}")


def test_database_job_insert_and_query(test_db):
    test_db.processing_jobs.insert_one({
        "job_id": "TEST-JOB-999",
        "filename": "sample.pdf",
        "processing_status": "COMPLETED"
    })
    found = test_db.processing_jobs.find_one({"job_id": "TEST-JOB-999"})
    assert found is not None
    assert found["filename"] == "sample.pdf"


def test_database_category_update(test_db):
    test_db.transactions.insert_one({
        "transaction_id": "TXN-999",
        "category": "Unclassified",
        "review_required": True
    })
    test_db.transactions.update_one(
        {"transaction_id": "TXN-999"},
        {"$set": {"category": "Food & Dining", "review_required": False}}
    )
    updated = test_db.transactions.find_one({"transaction_id": "TXN-999"})
    assert updated["category"] == "Food & Dining"
    assert updated["review_required"] is False

