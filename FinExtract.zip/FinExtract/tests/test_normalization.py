"""Test transaction normalization utilities."""
from decimal import Decimal
from src.utils.helpers import (
    parse_decimal, parse_date, infer_day_first, mask_account_number, normalize_description
)
from src.processing.normalizer import normalize_transaction


def test_parse_decimal_indian_format():
    assert parse_decimal("1,00,000.00") == Decimal("100000.00")
    assert parse_decimal("Rs. 25,450.50") == Decimal("25450.50")
    assert parse_decimal("₹ 1,500.00") == Decimal("1500.00")
    assert parse_decimal("(5,000.00)") == Decimal("-5000.00")
    assert parse_decimal("1,200.00 DR") == Decimal("-1200.00")
    assert parse_decimal("3,400.00 CR") == Decimal("3400.00")


def test_account_masking():
    assert mask_account_number("9876543210") == "XXXXXX3210"
    assert mask_account_number("1234") == "1234"
    assert mask_account_number("") == ""


def test_date_parsing_and_inference():
    dates = ["01/10/2024", "15/10/2024", "28/10/2024"]
    day_first = infer_day_first(dates)
    assert day_first is True

    d = parse_date("01/10/2024", day_first=True)
    assert d.day == 1
    assert d.month == 10
    assert d.year == 2024


def test_normalize_description():
    desc = "UPI/1234567890/SWIGGY FOOD DELIVERY"
    norm = normalize_description(desc)
    assert "SWIGGY" in norm
    assert "1234567890" not in norm


def test_normalize_transaction_object(mock_transaction):
    res = normalize_transaction(mock_transaction, "JOB-001", "ACC-001", 0)
    assert res["transaction_id"] == "TXN-JOB-001-00000"
    assert res["debit"] == 450.00
    assert res["credit"] is None
    assert res["currency"] == "INR"
    assert res["fingerprint"] != ""

