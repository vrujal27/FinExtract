"""Comprehensive smoke tests for all 9 pages of the FinExtract console."""
import os
import pytest
from streamlit.testing.v1 import AppTest

# Fast DB timeout for testing
os.environ["MONGO_CONNECT_RETRIES"] = "1"
os.environ["MONGO_CONNECT_DELAY"] = "0"

NAV_PAGES = [
    "Dashboard",
    "Upload Statement",
    "Transactions",
    "Classification Centre",
    "Validation Centre",
    "Analytics",
    "Export Centre",
    "Processing History",
    "How It Works"
]


@pytest.mark.parametrize("page_name", NAV_PAGES)
def test_all_pages_render_without_exception(page_name):
    """Assert every page renders cleanly via AppTest without throwing unhandled exceptions."""
    at = AppTest.from_file("app.py", default_timeout=60)
    at.session_state["nav"] = page_name
    at.run()
    assert not at.exception, f"Page '{page_name}' threw an exception: {at.exception}"


@pytest.mark.parametrize("page_name", NAV_PAGES)
def test_all_pages_render_with_mock_job_data(page_name):
    """Assert every page renders cleanly when statements and transactions exist in session state."""
    at = AppTest.from_file("app.py", default_timeout=60)
    job_id = "JOB-TEST-1234"
    dummy_job = {
        "job_id": job_id,
        "filename": "test_statement.pdf",
        "file_hash": "dummyhash123",
        "bank_name": "HDFC Bank",
        "account_id": "ACC-TEST-1",
        "pdf_type": "text",
        "page_count": 2,
        "transaction_count": 2,
        "processing_duration": 1.25,
        "warnings": [],
        "detection": {"pdf_type": "text", "total_pages": 2, "page_details": [{"page_number": 1, "page_type": "text"}, {"page_number": 2, "page_type": "text"}]},
        "stats": {"bank_name": "HDFC Bank", "parser": "hdfc", "rule_based": 1, "ml_classified": 1, "review_required": 1},
        "account_info": {"bank_name": "HDFC Bank", "account_holder": "Rahul Sharma", "account_number_masked": "XXXXXX1234", "ifsc": "HDFC0001234", "opening_balance": 10000.0, "closing_balance": 14500.0},
        "reconciliation": {"status": "PASSED", "matched": 2, "total_checked": 2, "issues": []},
        "validation_issues": [],
        "transactions": [
            {
                "transaction_id": "TXN-1",
                "transaction_date": "2025-01-10",
                "raw_date": "10/01/2025",
                "description": "SALARY CREDIT - TECH CORP",
                "debit": 0.0,
                "credit": 5000.0,
                "balance": 15000.0,
                "category": "Salary",
                "classification_method": "RULE_BASED",
                "rule_id": "RULE_SALARY",
                "ml_confidence": 1.0,
                "review_required": False,
                "extraction_method": "text",
                "source_page": 1,
                "account_id": "ACC-TEST-1",
                "job_id": job_id,
            },
            {
                "transaction_id": "TXN-2",
                "transaction_date": "2025-01-12",
                "raw_date": "12/01/2025",
                "description": "SWIGGY BANGALORE",
                "debit": 500.0,
                "credit": 0.0,
                "balance": 14500.0,
                "category": "Food & Dining",
                "classification_method": "MACHINE_LEARNING",
                "ml_confidence": 0.55,
                "review_required": True,
                "extraction_method": "text",
                "source_page": 1,
                "account_id": "ACC-TEST-1",
                "job_id": job_id,
            }
        ]
    }
    at.session_state["processed_jobs"] = {job_id: dummy_job}
    at.session_state["active_job_id"] = job_id
    at.session_state["nav"] = page_name
    at.run()
    assert not at.exception, f"Page '{page_name}' with data threw an exception: {at.exception}"

