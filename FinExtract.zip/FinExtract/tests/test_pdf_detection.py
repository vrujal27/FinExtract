"""Test PDF detection engine: text, scanned, mixed, invalid, empty."""
import pytest
from src.extraction.pdf_detector import detect_pdf_type
from src.utils.file_validator import validate_pdf_file


def test_detect_text_statement(text_statement_path):
    with open(text_statement_path, "rb") as f:
        data = f.read()
    res = detect_pdf_type(data)
    assert res["pdf_type"] == "text"
    assert res["total_pages"] >= 1
    assert res["text_pages"] >= 1
    assert res["scanned_pages"] == 0
    assert not res["requires_ocr"]


def test_detect_scanned_statement(scanned_statement_path):
    with open(scanned_statement_path, "rb") as f:
        data = f.read()
    res = detect_pdf_type(data)
    assert res["pdf_type"] in ("scanned", "mixed")
    assert res["scanned_pages"] >= 1
    assert res["requires_ocr"] is True


def test_detect_mixed_statement(mixed_statement_path):
    with open(mixed_statement_path, "rb") as f:
        data = f.read()
    res = detect_pdf_type(data)
    assert res["pdf_type"] == "mixed"
    assert res["text_pages"] >= 1
    assert res["scanned_pages"] >= 1
    assert res["requires_ocr"] is True


def test_file_validation_empty():
    valid, err = validate_pdf_file(b"", "empty.pdf")
    assert not valid
    assert "empty" in err.lower()


def test_file_validation_corrupt():
    valid, err = validate_pdf_file(b"This is not a real PDF document", "corrupt.pdf")
    assert not valid
    assert "valid pdf" in err.lower() or "bad magic" in err.lower()


def test_file_validation_extension():
    valid, err = validate_pdf_file(b"%PDF-1.4...", "statement.txt")
    assert not valid
    assert ".pdf extension" in err.lower()

