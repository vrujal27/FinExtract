"""Test bank detection and parser adapters across Layouts A, B, and C."""
import pytest
from src.parsers.bank_detector import detect_bank
from src.parsers.generic_parser import GenericParser
from src.extraction.extraction_manager import extract_pdf


def test_bank_detection_snippets():
    from src.parsers.hdfc_parser import HDFCParser
    from src.parsers.icici_parser import ICICIParser
    from src.parsers.sbi_parser import SBIParser
    from src.parsers.axis_parser import AxisParser

    hdfc = HDFCParser()
    assert hdfc.detect("HDFC BANK LIMITED - Statement of Account")
    assert hdfc.detect("Branch IFSC: HDFC0001234")

    icici = ICICIParser()
    assert icici.detect("ICICI BANK Passbook Statement")
    assert icici.detect("Branch Code ICIC0005678")

    sbi = SBIParser()
    assert sbi.detect("STATE BANK OF INDIA e-Statement")
    assert sbi.detect("IFSC: SBIN0001234")

    axis = AxisParser()
    assert axis.detect("AXIS BANK Account Statement")
    assert axis.detect("IFSC: UTIB0009876")


def test_parse_layout_a(text_statement_path):
    with open(text_statement_path, "rb") as f:
        data = f.read()
    ext = extract_pdf(data, "text_statement.pdf")
    parser = detect_bank(ext["full_text"])
    res = parser.parse(ext["pages"])

    assert len(res["transactions"]) >= 10
    account = res["account_info"]
    assert "9876543210" in account["account_number_masked"] or "3210" in account["account_number_masked"]

    # Verify extracted transaction columns
    t0 = res["transactions"][0]
    assert t0["raw_date"] != ""
    assert t0["description"] != ""
    assert t0["debit"] is not None or t0["credit"] is not None


def test_parse_layout_b(layout_b_path):
    with open(layout_b_path, "rb") as f:
        data = f.read()
    ext = extract_pdf(data, "text_statement_layout_b.pdf")
    parser = detect_bank(ext["full_text"])
    res = parser.parse(ext["pages"])

    assert len(res["transactions"]) >= 10
    # Layout B has Dr/Cr indicators
    assert any(t.get("credit") is not None for t in res["transactions"])
    assert any(t.get("debit") is not None for t in res["transactions"])


def test_parse_layout_c(layout_c_path):
    with open(layout_c_path, "rb") as f:
        data = f.read()
    ext = extract_pdf(data, "text_statement_layout_c.pdf")
    parser = detect_bank(ext["full_text"])
    res = parser.parse(ext["pages"])

    assert len(res["transactions"]) >= 10
    # Layout C has multi-line narrations
    long_desc = [t for t in res["transactions"] if len(t.get("description", "")) > 30]
    assert len(long_desc) > 0

