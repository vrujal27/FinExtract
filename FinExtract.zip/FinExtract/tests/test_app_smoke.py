"""Smoke test for the Streamlit application."""
import os
import pytest
from streamlit.testing.v1 import AppTest

# Configure fast fallback during test
os.environ["MONGO_CONNECT_RETRIES"] = "1"
os.environ["MONGO_CONNECT_DELAY"] = "0"


def test_app_smoke():
    """Verify app.py loads all components and handles offline DB gracefully without crashing."""
    at = AppTest.from_file("app.py", default_timeout=60)
    at.run()
    assert not at.exception
    # Verify titles or radio widgets are rendered
    assert len(at.radio) > 0
