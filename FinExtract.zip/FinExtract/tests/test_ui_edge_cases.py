"""Edge case tests for FinExtract UI components and formatters."""
import pytest
import pandas as pd
from src.ui.formatters import fmt_inr, fmt_date, fmt_pct, to_float, clean_html
from src.ui.insights import generate_insights
from src.ui.state import get_scoped_dataframe


def test_formatters_edge_cases():
    # Large numbers and Indian numbering system
    assert "₹" in fmt_inr(1234567.89)
    assert "12,34,567.89" in fmt_inr(1234567.89)
    assert "-₹" in fmt_inr(-5000.50)
    assert fmt_inr(None) == "—"

    # Compact INR
    assert fmt_inr(1500000, compact=True) == "₹15.00 L"
    assert fmt_inr(25000000, compact=True) == "₹2.50 Cr"
    assert fmt_inr(5000, compact=True) == "₹5.0 K"

    # Percentage
    assert fmt_pct(0.8523) == "85.2%"
    assert fmt_pct(None) == "—"

    # Float conversion
    assert to_float("1,234.56") == 1234.56
    assert to_float("-500.00") == -500.00
    assert to_float(None, default=0.0) == 0.0

    # HTML and LaTeX escaping
    raw_str = "<script>alert('xss')</script> $500 & 'special'"
    cleaned = clean_html(raw_str)
    assert "<script>" not in cleaned
    assert "&#36;" in cleaned
    assert "&amp;" in cleaned


def test_insights_edge_cases():
    # Empty DataFrame
    empty_df = pd.DataFrame(columns=["transaction_id", "debit", "credit", "category", "transaction_date"])
    insights = generate_insights(empty_df)
    assert isinstance(insights, list)
    assert len(insights) == 0

    # Single transaction
    single_df = pd.DataFrame([{
        "transaction_id": "TX1",
        "transaction_date": pd.Timestamp("2025-01-01"),
        "description": "Amazon India",
        "category": "Shopping",
        "debit": 4999.0,
        "credit": 0.0,
        "balance": 45000.0,
        "is_expense": True,
        "review_required": False,
        "extraction_method": "text",
        "ml_confidence": 0.95
    }])
    single_insights = generate_insights(single_df)
    assert isinstance(single_insights, list)
    assert any(i["title"] == "Largest Single Outflow" for i in single_insights)

    # Unicode & Special Characters
    unicode_df = pd.DataFrame([{
        "transaction_id": "TX2",
        "transaction_date": pd.Timestamp("2025-01-02"),
        "description": "किराना स्टोर / Groceries @ Market #42 & Co.",
        "category": "Groceries",
        "debit": 1250.0,
        "credit": 0.0,
        "balance": 43750.0,
        "is_expense": True,
        "review_required": False,
        "extraction_method": "text",
        "ml_confidence": 0.92
    }])
    uni_insights = generate_insights(unicode_df)
    assert isinstance(uni_insights, list)
