"""Test financial validation, balance reconciliation, and deduplication."""
from datetime import datetime
from src.processing.validator import validate_transaction, validate_transactions
from src.processing.balance_reconciliation import reconcile_balances
from src.processing.deduplicator import detect_duplicates


def test_balance_reconciliation_matched():
    txns = [
        {"transaction_id": "T1", "transaction_date": datetime(2024, 10, 1), "debit": None, "credit": 5000.0, "balance": 25000.0},
        {"transaction_id": "T2", "transaction_date": datetime(2024, 10, 2), "debit": 2000.0, "credit": None, "balance": 23000.0},
        {"transaction_id": "T3", "transaction_date": datetime(2024, 10, 3), "debit": 3000.0, "credit": None, "balance": 20000.0},
    ]
    # Starting from opening balance 20,000:
    # 20000 + 5000 = 25000 (T1)
    # 25000 - 2000 = 23000 (T2)
    # 23000 - 3000 = 20000 (T3)
    res = reconcile_balances(txns, opening_balance=20000.0)
    assert res["status"] == "PASSED"
    assert res["matched"] == 3
    assert res["mismatched"] == 0


def test_balance_reconciliation_mismatched():
    txns = [
        {"transaction_id": "T1", "transaction_date": datetime(2024, 10, 1), "debit": None, "credit": 5000.0, "balance": 25000.0},
        {"transaction_id": "T2", "transaction_date": datetime(2024, 10, 2), "debit": 2000.0, "credit": None, "balance": 20000.0},  # should be 23000
    ]
    res = reconcile_balances(txns, opening_balance=20000.0)
    assert res["status"] in ("FAILED", "WARNING")
    assert res["mismatched"] >= 1


def test_duplicate_detection():
    txns = [
        {"transaction_id": "T1", "fingerprint": "abc123hash"},
        {"transaction_id": "T2", "fingerprint": "xyz456hash"},
        {"transaction_id": "T3", "fingerprint": "abc123hash"},  # Duplicate of T1
    ]
    checked, issues = detect_duplicates(txns)
    assert checked[0]["possible_duplicate"] is True
    assert checked[2]["possible_duplicate"] is True
    assert checked[1]["possible_duplicate"] is False
    assert len(issues) == 1


def test_validate_transaction_anomalies():
    # Both debit and credit
    txn_bad = {
        "transaction_id": "T1", "transaction_date": datetime(2024, 10, 1),
        "description": "TEST", "debit": 100.0, "credit": 200.0,
        "extraction_confidence": 100.0
    }
    issues = validate_transaction(txn_bad)
    assert any(i["issue_type"] == "BOTH_DEBIT_CREDIT" for i in issues)

    # Missing amount
    txn_missing = {
        "transaction_id": "T2", "transaction_date": datetime(2024, 10, 1),
        "description": "TEST", "debit": None, "credit": None,
        "extraction_confidence": 100.0
    }
    issues2 = validate_transaction(txn_missing)
    assert any(i["issue_type"] == "MISSING_AMOUNT" for i in issues2)

