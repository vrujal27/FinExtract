"""Test text and OCR extraction managers."""
import pytest
from src.extraction.extraction_manager import extract_pdf
from src.extraction.text_extractor import extract_text_pdf, normalize_header


def test_header_normalization():
    assert normalize_header("Transaction Date") == "date"
    assert normalize_header("Withdrawal (Dr)") == "debit"
    assert normalize_header("Deposit (Cr)") == "credit"
    assert normalize_header("Closing Balance") == "balance"
    assert normalize_header("Particulars") == "description"


def test_extract_text_pdf(text_statement_path):
    with open(text_statement_path, "rb") as f:
        data = f.read()
    res = extract_text_pdf(data)
    assert len(res["pages"]) >= 1
    assert "SUNRISE NATIONAL BANK" in res["full_text"]
    assert "SALARY CREDIT" in res["full_text"]


def test_extraction_manager_end_to_end(text_statement_path):
    with open(text_statement_path, "rb") as f:
        data = f.read()
    res = extract_pdf(data, "text_statement.pdf")
    assert res["success"] is True
    assert len(res["pages"]) >= 1
    assert res["detection"]["pdf_type"] == "text"

