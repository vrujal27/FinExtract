"""Pytest fixtures for FinExtract."""
import os
import sys
from pathlib import Path
import pytest

# Ensure project root is on sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.config import SAMPLES_DIR


@pytest.fixture(scope="session")
def sample_dir():
    return SAMPLES_DIR


@pytest.fixture(scope="session")
def text_statement_path(sample_dir):
    p = sample_dir / "text_statement.pdf"
    if not p.exists():
        pytest.skip("text_statement.pdf not found")
    return p


@pytest.fixture(scope="session")
def layout_b_path(sample_dir):
    p = sample_dir / "text_statement_layout_b.pdf"
    if not p.exists():
        pytest.skip("text_statement_layout_b.pdf not found")
    return p


@pytest.fixture(scope="session")
def layout_c_path(sample_dir):
    p = sample_dir / "text_statement_layout_c.pdf"
    if not p.exists():
        pytest.skip("text_statement_layout_c.pdf not found")
    return p


@pytest.fixture(scope="session")
def scanned_statement_path(sample_dir):
    p = sample_dir / "scanned_statement.pdf"
    if not p.exists():
        pytest.skip("scanned_statement.pdf not found")
    return p


@pytest.fixture(scope="session")
def mixed_statement_path(sample_dir):
    p = sample_dir / "mixed_statement.pdf"
    if not p.exists():
        pytest.skip("mixed_statement.pdf not found")
    return p


@pytest.fixture
def mock_transaction():
    return {
        "transaction_id": "TXN-TEST-00001",
        "job_id": "JOB-TEST-001",
        "account_id": "ACC-TEST-001",
        "row_index": 0,
        "transaction_date": None,
        "raw_date": "01/10/2024",
        "description": "UPI-SWIGGY BANGALORE ORDER",
        "raw_description": "UPI-SWIGGY BANGALORE ORDER",
        "debit": 450.00,
        "credit": None,
        "balance": 24550.00,
        "currency": "INR",
        "category": "Unclassified",
        "classification_method": "",
        "review_required": True,
        "validation_status": "PENDING",
        "extraction_method": "text",
        "extraction_confidence": 100.0,
        "source_page": 1,
        "fingerprint": "mock_fp_123"
    }

