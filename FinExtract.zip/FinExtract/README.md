# FinExtract: Intelligent Bank Statement Processing & Classification Platform

> **Befree AI & Automation Assessment Deliverable**  
> **Production-grade, non-LLM bank statement ingestion, parsing, normalization, hybrid classification, mathematical reconciliation, and financial analytics platform.**

---

## 1. Title & Product Overview
**FinExtract** is an enterprise-grade financial data processing system engineered to automatically convert unstructured bank statement PDFs (digital text-based, scanned images, and mixed formats) into normalized, categorized, mathematically reconciled, and exportable financial data.

## 2. Product Description
Modern financial institutions and accounting operations receive bank statements in disparate layouts, fonts, encodings, and visual formats. FinExtract eliminates tedious manual data entry by orchestrating a high-throughput processing pipeline:
- Automatic page-wise PDF type detection (text vs. scanned vs. mixed).
- Dual extraction engines (PyMuPDF vector text extraction + OpenCV preprocessed Tesseract OCR).
- Multi-layout parsing handling separate Debit/Credit columns, Dr/Cr indicator rows, and reverse-chronological multi-line statements.
- Deterministic heuristic rules combined with character n-gram TF-IDF and Logistic Regression machine learning.
- Strict non-LLM architecture ensuring zero latency, zero third-party API dependencies, full data privacy, and zero hallucination risk.
- Mathematical running balance reconciliation, duplicate flagging, and interactive manual review.
- Multi-sheet Excel (`.xlsx`) and Windows-compatible CSV (`utf-8-sig`) reporting.

---

## 3. Problem Statement
Accounting firms, loan underwriters, and audit teams waste thousands of manual hours reconciling bank statements due to:
1. **Unpredictable Layouts:** Varying headers, column positions, Dr/Cr notations, and multi-line payment descriptions.
2. **Scanned & Degraded Scans:** Skewed, noisy, low-resolution PDFs lacking digital text streams.
3. **Data Loss & Hallucinations:** Generative AI / LLM classifiers are non-deterministic, leak confidential financial data, and hallucinate transaction amounts.
4. **Validation Failures:** Silent errors in debit/credit classification break balance continuity.

---

## 4. Objectives
- **Automate Extraction:** Extract account metadata and transactions from multi-page PDFs with 100% mathematical auditability.
- **Support Realistic Variations:** Handle Layout A (separate columns), Layout B (single amount with Dr/Cr), and Layout C (multi-line reverse-chronological).
- **Ensure Privacy & Compliance:** Strictly non-LLM classification using local scikit-learn models and regex/keyword rule tables.
- **Validate Continuity:** Automatically reconcile $\text{Balance}_{t} = \text{Balance}_{t-1} + \text{Credit}_t - \text{Debit}_t$.
- **Seamless Export:** Generate Excel and CSV reports reflecting user adjustments.

---

## 5. Assessment Requirements Coverage Matrix

| Assessment Requirement | Implementation Module | Verification Status |
|---|---|---|
| **1. Accept bank statements in PDF format** | `src/utils/file_validator.py` | ✅ Verified (`tests/test_pdf_detection.py`) |
| **2. Process text-based PDFs** | `src/extraction/text_extractor.py` | ✅ Verified (`tests/test_extraction.py`) |
| **3. Process image-based/scanned PDFs** | `src/extraction/ocr_extractor.py` | ✅ Verified (`tests/test_pdf_detection.py`) |
| **4. Automatically detect PDF type** | `src/extraction/pdf_detector.py` | ✅ Verified (`tests/test_pdf_detection.py`) |
| **5. Support multiple bank statement formats** | `src/parsers/generic_parser.py` (Layouts A, B, C) | ✅ Verified (`tests/test_parser.py`) |
| **6. Extract account holder & account info** | `src/parsers/base_parser.py`, `generic_parser.py` | ✅ Verified (`tests/test_parser.py`) |
| **7. Extract transaction dates** | `src/parsers/generic_parser.py`, `src/utils/helpers.py` | ✅ Verified (`tests/test_normalization.py`) |
| **8. Extract transaction descriptions** | `src/parsers/generic_parser.py`, `data_cleaner.py` | ✅ Verified (`tests/test_normalization.py`) |
| **9. Extract debit amounts** | `src/parsers/generic_parser.py`, `src/utils/helpers.py` | ✅ Verified (`tests/test_normalization.py`) |
| **10. Extract credit amounts** | `src/parsers/generic_parser.py`, `src/utils/helpers.py` | ✅ Verified (`tests/test_normalization.py`) |
| **11. Extract running balances** | `src/parsers/generic_parser.py` | ✅ Verified (`tests/test_parser.py`) |
| **12. Classify transactions using heuristic rules** | `src/classification/rule_engine.py`, `rules.json` | ✅ Verified (`tests/test_classification.py`) |
| **13. Classify transactions using traditional ML** | `src/classification/ml_classifier.py` | ✅ Verified (`tests/test_classification.py`) |
| **14. Strictly avoid LLM-based classification** | `requirements.txt`, codebase grep | ✅ Verified (Zero LLM libraries) |
| **15. Export extracted data to Excel (.xlsx)** | `src/exporters/excel_exporter.py` | ✅ Verified (`tests/test_export.py`) |
| **16. Export extracted data to CSV (.csv)** | `src/exporters/csv_exporter.py` | ✅ Verified (`tests/test_export.py`) |
| **17. Edge cases, validation, duplicates** | `src/processing/validator.py`, `deduplicator.py` | ✅ Verified (`tests/test_validation.py`) |

---

## 6. Key Features
- **Dynamic PDF Detection:** Page-by-page text-density and image-area scoring.
- **OpenCV Image Enhancement:** Automated deskewing, noise reduction, and Otsu/adaptive thresholding before OCR.
- **Layout Agnostic Generic Parser:** Column-header synonym mapper handling Layout A, Layout B, and Layout C.
- **Multi-Bank Adapters:** Modular adapter framework with detection verified for HDFC, ICICI, SBI, and Axis Bank.
- **Non-LLM Hybrid Classification:** High-priority regex/contains rule matching with fallthrough to TF-IDF Logistic Regression.
- **Financial Balance Continuity:** Bi-directional chronological verification with configurable INR 0.01 tolerance.
- **Duplicate Detection:** SHA-256 fingerprinting accounting for multiple identical transactions on the same day.
- **Human-in-the-Loop Corrections:** Instant category corrections saved to MongoDB and reflected across analytics and exports.

---

## 7. Technology Stack
- **Frontend / UI:** Streamlit 1.55, Plotly Express & Graph Objects, Custom SaaS CSS.
- **Core Backend:** Python 3.11+, PyMuPDF (`fitz`), `pdfplumber`.
- **Computer Vision & OCR:** OpenCV (`opencv-python-headless`), Pillow, Tesseract OCR via `pytesseract`.
- **Machine Learning (Strictly Non-LLM):** Scikit-learn (TF-IDF Vectorizer + Multinomial Logistic Regression), NumPy, Pandas, Joblib.
- **Database:** MongoDB Community Server 8.0 via `pymongo` with Decimal128 support.
- **Exporters:** OpenPyXL (multi-sheet formatted workbooks), Python standard CSV (`utf-8-sig`).
- **Testing & Quality:** Pytest, Streamlit LocalScriptRunner AppTest.

---

## 8. System Architecture Diagram

```mermaid
flowchart TD
    A["Uploaded Statement (.pdf)"] --> B["File Validator (Size, Magic, Pages)"]
    B --> C["PDF Detection Engine (Page-Wise)"]
    
    C -->|"Text Pages"| D["PyMuPDF / pdfplumber Extraction"]
    C -->|"Scanned Pages"| E["OpenCV Preprocessing + Tesseract OCR"]
    
    D --> F["Raw Extracted Pages & Words"]
    E --> F
    
    F --> G["Bank Detection Engine"]
    G --> H["Statement Parser (Layout A / B / C / Bank Adapter)"]
    
    H --> I["Transaction Normalizer & Cleaner"]
    I --> J["Financial Validation Engine"]
    I --> K["Balance Reconciliation Engine"]
    I --> L["Duplicate Detection Engine"]
    
    I --> M["Hybrid Classification Engine"]
    M -->|"Priority 1"| N["Deterministic Rule Engine (rules.json)"]
    M -->|"Priority 2"| O["Traditional ML (TF-IDF + Logistic Regression)"]
    
    N --> P["Classification Decision & Confidence"]
    O --> P
    
    P --> Q["Interactive Streamlit Review Interface"]
    Q -->|"Human Corrections"| R["MongoDB Database Layer"]
    
    R --> S["Analytics Dashboard"]
    R --> T["Excel (.xlsx) / CSV (.csv) Exporters"]
```

---

## 9. Processing Workflow
1. **Upload & Validate:** Validate PDF magic header (`%PDF`), size limit ($\le 25\text{ MB}$), page count ($\le 100$), and absence of encryption.
2. **Page-by-Page Inspection:** Calculate alphanumeric character ratio and image bounding area per page. Categorize into text, scanned, or mixed.
3. **Extraction & OCR:** Extract native vector text and coordinates using PyMuPDF; apply OpenCV grayscale, deskew, and thresholding to scanned pages for Tesseract OCR.
4. **Header Alignment & Row Stitching:** Match column headers against configured financial synonyms (`date`, `description`, `debit`, `credit`, `balance`, `amount`, `indicator`). Rebuild multi-line transaction narratives.
5. **Data Normalization:** Parse Indian numeric amounts (`1,00,000.00`, `Dr/Cr`, parentheses), mask account numbers (`XXXXXX1234`), and normalize dates.
6. **Integrity Validation:** Run balance reconciliation $\text{Prev} + \text{Credit} - \text{Debit} = \text{Current}$, flag incomplete rows, detect possible duplicates.
7. **Hybrid Classification:**
   - Evaluates high-precision rules (e.g., `SWIGGY` $\to$ Food & Dining; `SALARY` with credit guard $\to$ Salary).
   - Unmatched rows route to the TF-IDF character-ngram Logistic Regression model.
   - Predictions with score $< 0.85$ are flagged for human review.
8. **Storage & Visualization:** Persist structured jobs, accounts, and transactions in MongoDB; render in Streamlit; generate multi-sheet Excel and CSV downloads.

---

## 10. PDF Detection Methodology
Each page is independently inspected:
- **Text Length ($L$):** Character count after whitespace trimming.
- **Alphanumeric Ratio ($R$):** $\frac{\text{Alphanumeric Characters}}{\text{Total Characters}}$.
- **Image Area Share ($S$):** $\frac{\sum \text{Area}(\text{Images})}{\text{Page Area}}$.
- **Classification Rules:**
  - If $L \ge 50$ and $R \ge 0.30$ with detected date/amount patterns $\to$ **Text Page**.
  - If $S \ge 0.60$ and $L < 50 \to$ **Scanned Page**.
  - Entire document marked as **Text** (all text), **Scanned** (all scanned), or **Mixed** (combination).

---

## 11. Text Extraction Strategy
- PyMuPDF (`fitz`) provides character stream extraction and coordinate bounding boxes.
- `pdfplumber` performs table cell detection for bordered grid layouts.
- Header synonym mapper matches variants:
  - Debit: `Withdrawal`, `Debit`, `Dr`, `Amount Debited`, `Paid Out`.
  - Credit: `Deposit`, `Credit`, `Cr`, `Amount Credited`, `Paid In`.
  - Balance: `Running Balance`, `Closing Balance`, `Balance`, `Bal`.

---

## 12. OCR Processing Pipeline
Scanned and low-density pages route to the OpenCV preprocessor:
1. **Grayscale Conversion:** Eliminate chromatic noise.
2. **Resolution Check:** Bilinear upscaling if page width $< 1000\text{ px}$.
3. **Noise Filtering:** Fast Non-Local Means Denoising (`cv2.fastNlMeansDenoising`).
4. **Deskewing:** Minimum-area bounding rectangle detection to calculate and counteract rotation angle.
5. **Adaptive Thresholding:** Gaussian adaptive binarization to handle non-uniform background shadows.
6. **OCR Execution:** Tesseract OCR with Page Segmentation Mode 6 (`--psm 6`) capturing word-level confidence scores. Words below $60\%$ confidence flag the row for manual review.

---

## 13. Parser Architecture & Layout Variations

### Generic Parser (`src/parsers/generic_parser.py`)
Handles arbitrary statements by reading headers and reconstructing rows:
- **Layout A (`samples/text_statement.pdf`):** Separate Withdrawal/Deposit columns, standard `DD/MM/YYYY` dates, chronological order.
- **Layout B (`samples/text_statement_layout_b.pdf`):** Single Amount column with Dr/Cr direction indicators, `DD-MMM-YYYY` dates.
- **Layout C (`samples/text_statement_layout_c.pdf`):** Negative amounts enclosed in parentheses `(32,500.00)`, reverse-chronological order, multi-line narrations, and repeated headers across page breaks.

### Multi-Bank Adapters (`src/parsers/`)
- `HDFCParser`, `ICICIParser`, `SBIParser`, `AxisParser`.
- **Honest Verification Disclosure:** As mandated in Section 9 of the specification, sample statement PDFs use fictional bank names. Detection of HDFC, ICICI, SBI, and Axis is verified via unit tests on header snippets (bank name and IFSC prefix regex). Full statement parsing for these banks delegates to the verified Generic Parser.

---

## 14. Transaction Normalization Engine
- **Decimal Precision:** Normalized to standard numeric floats and MongoDB `Decimal128` types. Indian numbering (`1,00,000.00`) and commas are parsed cleanly.
- **Date Inferences:** Dates are evaluated across the statement; day-first vs. month-first is inferred globally by checking for day components $> 12$.
- **Account Number Masking:** All account numbers are masked to show only the final 4 digits (e.g., `XXXXXX3210`).
- **Payment Method Isolation:** UPI, NEFT, IMPS, RTGS, and NACH prefixes are isolated and stripped from merchant descriptions so payment mechanisms never alone dictate transaction categories.

---

## 15. Financial Validation Engine
- **Required Fields:** Rejects or flags transactions missing dates, descriptions, or amounts.
- **Anomaly Detection:** Flags rows where both Debit and Credit are populated, negative debits, or low OCR confidence.
- **Balance Continuity:**
  $$\text{Expected Balance}_t = \text{Balance}_{t-1} + \text{Credit}_t - \text{Debit}_t$$
  Reconciliation evaluates both chronological and reverse-chronological statement orders, verifying against a configurable tolerance of $\text{INR } 0.01$.
- **Duplicate Prevention:** Computes a deterministic SHA-256 fingerprint:
  $$\text{hash}(\text{account\_id} \parallel \text{date} \parallel \text{amount} \parallel \text{balance} \parallel \text{description} \parallel \text{row\_index})$$
  Identical rows within the same statement are preserved with distinct occurrence indices, while potential duplicates are flagged for user review.

---

## 16. Rule-Based Classification Engine
Configured in `src/classification/rules.json`:
- **Matching Strategies:** `exact`, `contains`, `regex`, and `word_boundary`.
- **Rule Priorities:** Integer scale ($1-15$). Deterministic merchant rules take precedence over statistical ML.
- **Direction Guards:** `credit_only: true` on salary rules prevents salary advances or refunds from falsely triggering salary categorization.
- **Key Categories:** Salary, Income, Food & Dining, Groceries, Shopping, Transportation, Fuel, Utilities, Rent, Healthcare, Education, Entertainment, Travel, ATM/Cash Withdrawal, Bank Charges, Loan/EMI, Investment, Insurance, Transfers, Unclassified.

---

## 17. Traditional ML Classification Engine
- **Strict Non-LLM Compliance:** Zero calls to OpenAI, Claude, Gemini, or any LLM APIs. Zero external network dependencies.
- **Pipeline Architecture:**
  - `TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 4), max_features=50000, sublinear_tf=True)`
  - `LogisticRegression(C=5.0, class_weight="balanced", max_iter=1000, solver="lbfgs")`
- **Training Corpus:** Generated via `scripts/generate_training_data.py` (2,000 synthetic multi-channel financial transactions).
- **Evaluation:** Evaluated on held-out stratified test splits; persisted via `joblib` in `models/transaction_classifier.joblib`.

---

## 18. Hybrid Classification Logic
1. Normalize raw description (strip reference numbers, UPI prefixes, digits).
2. Query `RuleEngine`. If a rule matches with high priority, assign `RULE_BASED` category.
3. If no rule matches, forward to ML pipeline.
4. If ML probability $\ge 0.85$, assign `MACHINE_LEARNING` category.
5. If ML probability is between $0.60$ and $0.85$, assign category and flag `review_required = True`.
6. If ML probability $< 0.60$, assign `Unclassified` and flag for manual review.

---

## 19. MongoDB Database Architecture

### Collections & Schema Specifications
- **`processing_jobs`:**
  - `job_id` (string, unique index)
  - `filename`, `file_hash` (string, index)
  - `bank_name`, `account_id`, `pdf_type`
  - `page_count`, `text_page_count`, `scanned_page_count`, `transaction_count`
  - `processing_status` (`COMPLETED`, `FAILED`, `PARTIAL`)
  - `processing_duration`, `warnings`, `created_at`, `updated_at`
- **`accounts`:**
  - `account_id` (string, unique index)
  - `bank_name`, `account_holder`, `account_number_masked`, `ifsc`
  - `opening_balance`, `closing_balance`, `currency`
- **`transactions`:**
  - `transaction_id` (string, unique index)
  - `job_id`, `account_id`, `row_index` (compound index)
  - `transaction_date` (datetime, index), `raw_date`
  - `description`, `raw_description`
  - `debit`, `credit`, `balance` (Decimal128 / float)
  - `category`, `predicted_category`, `classification_method`, `ml_confidence`
  - `review_required` (boolean, index), `validation_status`, `fingerprint`
- **`user_corrections`:**
  - `correction_id`, `transaction_id`, `job_id`, `previous_category`, `corrected_category`, `timestamp`
- **`validation_issues`:**
  - `issue_id`, `transaction_id`, `job_id`, `issue_type`, `severity`, `description`

---

## 20. Docker Architecture & Containerization
- **Multi-Container Topology:** Streamlit application (`finextract-app`) and MongoDB 8.0 (`finextract-mongodb`) connected over an internal bridge network (`finextract-network`).
- **Dockerfile:** Based on `python:3.11-slim`, installs Tesseract OCR + English language pack and OpenCV shared libraries, runs as non-privileged user `finextract` (UID 1000).
- **Container Healthcheck:** Queries Streamlit's `/_stcore/health` endpoint via inline Python script (eliminating curl dependency).
- **Database Bootstrapping:** Initialized via `mongo-init/01-create-app-user.js` creating dedicated application user credentials with `readWrite` access to `finextract` and `finextract_test`.
- **Port Isolation:** Production Compose file does not expose MongoDB port to host; local development override (`docker-compose.dev.yml`) maps `127.0.0.1:27017` strictly when required.

---

## 21. Folder Structure

```text
FinExtract/
├── start.bat                          # One-click desktop launcher (launches START_FINEXTRACT.bat)
├── START_FINEXTRACT.bat               # Automated Docker & healthcheck bootstrap script
├── START_LOCAL_NO_DOCKER.bat          # Native Windows fallback launcher without Docker
├── app.py                             # Main Streamlit application shell (thin router)
├── requirements.txt                   # Production pinned dependencies (zero LLM libraries)
├── README.md                          # Comprehensive system documentation
├── TEST_REPORT.md                     # Empirical test execution and verification report
├── Dockerfile                         # Python 3.11 slim container with Tesseract & OpenCV
├── docker-compose.yml                 # Multi-container production deployment definition
├── docker-compose.dev.yml             # Dev override publishing MongoDB on 127.0.0.1:27017
├── .dockerignore                      # Build context exclusion rules
├── .gitignore                         # Version control ignore list
├── .env.example                       # Reference environment variable template
├── .env                               # Local active environment configuration
├── .streamlit/
│   └── config.toml                    # Streamlit visual theme (indigo tokens) and maxUploadSize=50
├── src/
│   ├── config.py                      # Centralized configuration, paths, and thresholds
│   ├── ui/                            # Enterprise FinOps UI presentation layer
│   │   ├── __init__.py
│   │   ├── theme.py                   # Design tokens, color palette, custom CSS injection
│   │   ├── components.py              # KPI cards, badges, scope pill, dialogs, headers
│   │   ├── formatters.py              # Safe INR currency, tabular numerals, percentage
│   │   ├── state.py                   # Centralized scoping, deduplication, active session
│   │   ├── insights.py                # Rule-based deterministic insights engine (Non-LLM)
│   │   ├── charts.py                  # Plotly visualizations (Sankey, Donut, Treemap, etc.)
│   │   └── pages/                     # Modular console views
│   │       ├── dashboard.py           # Executive KPI strip, cash flow, diagnostics
│   │       ├── upload.py              # Drag & drop hero, synthetic samples, live stepper
│   │       ├── transactions.py        # Ledger with filters, audit dossier dialog
│   │       ├── classification.py      # Hierarchy funnel, review queue, model card
│   │       ├── validation.py          # Balance continuity timeline, issues ledger
│   │       ├── analytics.py           # Inflow/outflow trends, counterparty intelligence
│   │       ├── export.py              # Multi-tab Excel, CSV feeds, pre-flight preview
│   │       ├── history.py             # Ingestion registry, manifest diagnostics, purge modal
│   │       └── how_it_works.py        # Architectural pipeline, model card, privacy notes
│   ├── extraction/                    # PDF type detection and extraction
│   │   ├── __init__.py
│   │   ├── pdf_detector.py            # Page-wise text vs scanned analysis
│   │   ├── text_extractor.py          # PyMuPDF and pdfplumber extraction
│   │   ├── ocr_extractor.py           # Tesseract OCR extraction with word confidences
│   │   ├── image_preprocessor.py      # OpenCV grayscale, deskew, and adaptive thresholding
│   │   └── extraction_manager.py      # Extraction workflow coordinator
│   ├── parsers/                       # Bank and layout parsing
│   │   ├── __init__.py
│   │   ├── base_parser.py             # Abstract BaseParser interface
│   │   ├── bank_detector.py           # Modular parser registry and detector
│   │   ├── generic_parser.py          # Universal layout workhorse (Layouts A, B, C)
│   │   ├── hdfc_parser.py             # HDFC Bank adapter
│   │   ├── icici_parser.py            # ICICI Bank adapter
│   │   ├── sbi_parser.py              # State Bank of India adapter
│   │   └── axis_parser.py             # Axis Bank adapter
│   ├── processing/                    # Normalization, validation, reconciliation
│   │   ├── __init__.py
│   │   ├── normalizer.py              # Data normalization and fingerprinting
│   │   ├── data_cleaner.py            # Text and description sanitization
│   │   ├── validator.py               # Financial validation checks
│   │   ├── balance_reconciliation.py  # Balance continuity calculator
│   │   ├── deduplicator.py            # Duplicate candidate detector
│   │   └── transaction_processor.py   # End-to-end processing pipeline orchestrator
│   ├── classification/                # Strict non-LLM classification
│   │   ├── __init__.py
│   │   ├── categories.py              # Financial category definitions
│   │   ├── rules.json                 # Configurable heuristic rule definitions
│   │   ├── rule_engine.py             # Deterministic pattern matching engine
│   │   ├── ml_classifier.py           # TF-IDF + Logistic Regression inference
│   │   ├── train_model.py             # Model training and metrics evaluation
│   │   ├── hybrid_classifier.py       # Hybrid rule + ML decision coordinator
│   │   └── feedback_manager.py        # Human correction and audit storage
│   ├── database/                      # MongoDB database integration
│   │   ├── __init__.py
│   │   ├── db.py                      # PyMongo client singleton with retry & cooldown
│   │   ├── connection.py              # Re-export compatibility module
│   │   ├── collections.py             # Full CRUD operations and aggregations
│   │   └── indexes.py                 # Unique and compound database indexes
│   ├── exporters/                     # Export generators
│   │   ├── __init__.py
│   │   ├── excel_exporter.py          # 5-sheet OpenPyXL formatted workbook generator
│   │   └── csv_exporter.py            # Standard UTF-8 BOM CSV generator
│   ├── analytics/                     # Aggregations and metrics
│   │   ├── __init__.py
│   │   └── analytics_engine.py        # Cash flow, merchant, and trend aggregator
│   └── utils/                         # Utilities and security
│       ├── __init__.py
│       ├── helpers.py                 # Numeric, date, and string formatting
│       ├── file_validator.py          # PDF structural integrity validator
│       ├── logging_config.py          # Standardized logging setup
│       └── security.py                # Safe temporary files and string sanitizers
├── scripts/
│   ├── __init__.py
│   ├── generate_sample_statements.py  # Deterministic generator for all 5 synthetic PDFs
│   └── generate_training_data.py      # Generator for 2,000 synthetic training transactions
├── models/
│   ├── transaction_classifier.joblib  # Trained TF-IDF + Logistic Regression model
│   └── transaction_classifier_meta.json # Model evaluation metrics and metadata
├── data/
│   └── training_transactions.csv      # Synthetic multi-channel training records
├── mongo-init/
│   └── 01-create-app-user.js          # MongoDB authentication initialization script
├── tests/                             # Comprehensive automated test suite (48 tests)
│   ├── __init__.py
│   ├── conftest.py                    # Pytest fixtures and sample paths
│   ├── test_pdf_detection.py          # Text, scanned, mixed, corrupt PDF tests
│   ├── test_extraction.py             # PyMuPDF and header normalization tests
│   ├── test_parser.py                 # Multi-layout (A, B, C) and bank detection tests
│   ├── test_normalization.py          # Currency parsing, account masking, dates tests
│   ├── test_classification.py         # Heuristic rules and ML classification tests
│   ├── test_validation.py             # Balance reconciliation and duplicate tests
│   ├── test_database.py               # Isolated MongoDB operations tests
│   ├── test_export.py                 # Excel 5-sheet and CSV export tests
│   ├── test_ui_golden.py              # Golden verification tests for all 5 statement types
│   ├── test_ui_pages_smoke.py         # AppTest smoke test asserting all 9 pages
│   ├── test_ui_edge_cases.py          # Formatter, insight, and Unicode edge cases
│   └── test_app_smoke.py              # Baseline application launch smoke test
├── samples/                           # Generated synthetic test assets
│   ├── text_statement.pdf             # Layout A synthetic statement
│   ├── text_statement_layout_b.pdf    # Layout B synthetic statement
│   ├── text_statement_layout_c.pdf    # Layout C synthetic statement
│   ├── scanned_statement.pdf          # Image-based scanned statement
│   ├── mixed_statement.pdf            # Mixed digital text + image statement
│   └── sample_transactions.csv        # Ground-truth transaction records
├── assets/
│   └── logo.png                       # Application brand logo
└── screenshots/application/           # Application verification captures
```

---

## 22. Prerequisites
- **Python:** Python 3.11 or higher (Python 3.11–3.14 supported).
- **Tesseract OCR:** Required for image-based/scanned PDF processing.
  - *Windows:* Install via official installer and set `TESSERACT_CMD=C:\Program Files\Tesseract-OCR\tesseract.exe`.
  - *Linux / Docker:* `apt-get install -y tesseract-ocr tesseract-ocr-eng`.
- **Docker & Docker Compose:** Optional for containerized deployment.

---

## 23. Installation

```bash
# 1. Clone repository and navigate to workspace
git clone https://github.com/befree-assessment/FinExtract.git
cd FinExtract

# 2. Create and activate a Python virtual environment
python -m venv venv
# On Windows:
venv\Scripts\activate
# On Linux/macOS:
source venv/bin/activate

# 3. Install production dependencies
pip install -r requirements.txt
```

---

## 24. Environment Variables Configuration
Copy `.env.example` to `.env`:
```bash
# Windows
copy .env.example .env
# Linux / macOS
cp .env.example .env
```

Key environment settings:
```ini
MONGO_ROOT_USERNAME=root
MONGO_ROOT_PASSWORD=change_this_password
MONGO_APP_USERNAME=finextract_user
MONGO_APP_PASSWORD=change_this_password
MONGO_DATABASE=finextract

# Docker network URI
MONGODB_URI=mongodb://finextract_user:change_this_password@mongodb:27017/finextract?authSource=finextract

# Local development URI (uncomment when running Mongo locally)
# MONGODB_URI=mongodb://finextract_user:change_this_password@localhost:27017/finextract?authSource=finextract

MAX_UPLOAD_MB=25
MAX_PAGES=100
```

---

## 25. Running with Docker Compose (Mode A)

### 🚀 1-Click Double-Click Launcher (Windows)
Simply double-click:
- **`START_FINEXTRACT.bat`** (or **`START.bat`**) — Checks Docker status, brings up all containers (`finextract-app` and `finextract-mongodb`), waits for the healthcheck, and automatically opens `http://localhost:8501` in your default browser.
- **`STOP_FINEXTRACT.bat`** (or **`STOP.bat`**) — Safely shuts down all containers.

### Manual Command-Line Execution
```bash
# Build containers and start services in detached mode
docker compose up --build -d

# Open web browser
# Navigate to: http://localhost:8501

# Inspect logs
docker compose logs -f app

# Tear down (retaining database volume data)
docker compose down
```

---

## 26. Running Locally (Mode B)
1. Ensure `.env` is configured. If MongoDB is offline, FinExtract gracefully runs in in-memory session mode.
2. If using local MongoDB via Docker:
   ```bash
   docker compose -f docker-compose.yml -f docker-compose.dev.yml up -d mongodb
   ```
3. Start the Streamlit application:
   ```bash
   streamlit run app.py
   ```
4. Access the web interface at `http://localhost:8501`.

---

## 27. Model Training & Sample Data Generation
```bash
# 1. Generate all synthetic statement PDFs and sample CSVs
python scripts/generate_sample_statements.py

# 2. Generate synthetic training corpus (2,000 transactions)
python scripts/generate_training_data.py

# 3. Train and evaluate the TF-IDF + Logistic Regression model
python -c "from src.classification.train_model import train_classifier; train_classifier()"
```

---

## 28. Testing Instructions
Execute the complete test suite using pytest:
```bash
pytest -v
```
To run specific functional test modules:
```bash
# Test PDF type detection
pytest tests/test_pdf_detection.py -v

# Test Multi-layout parsing (Layouts A, B, C)
pytest tests/test_parser.py -v

# Test Non-LLM Hybrid classification
pytest tests/test_classification.py -v

# Test Financial validation & balance reconciliation
pytest tests/test_validation.py -v

# Test Streamlit application smoke test
pytest tests/test_app_smoke.py -v
```

---

## 29. Excel Export Structure
Generated workbooks (`.xlsx`) contain 5 dedicated sheets:
1. **Transactions:** `Transaction ID`, `Date`, `Description`, `Debit (INR)`, `Credit (INR)`, `Balance (INR)`, `Category`, `Predicted Category`, `Classification Method`, `ML Confidence`, `Review Status`, `Validation Status`, `Source Page`, `Extraction Method`. Formatted with frozen headers, auto-width columns, currency formatting, and alternating row colors.
2. **Account Summary:** Bank details, masked account number, IFSC, statement period, opening balance, closing balance, total debits, total credits.
3. **Category Summary:** Aggregated transaction counts, debit totals, credit totals, and net flow per category.
4. **Validation Report:** Detailed register of all financial discrepancies, severity levels, and expected vs actual values.
5. **Processing Metadata:** System job ID, source filename, PDF classification, extraction methods, duration, and timestamps.

---

## 30. CSV Export Structure
- Output format: RFC 4180 compliant CSV encoded with UTF-8 BOM (`utf-8-sig`) for instant rendering in Microsoft Excel on Windows without character corruption.
- Contains original raw fields alongside normalized dates, decimals, review flags, and human corrections.

---

## 31. Security and Financial Data Privacy
- **Strictly Local AI:** Zero data transmitted to external LLM providers (no OpenAI, Claude, or cloud AI endpoints).
- **Masked PII:** Account numbers masked by default (`XXXXXX3210`).
- **Path Traversal Protection:** Application generates random UUID temporary file paths instead of using user-supplied filenames.
- **Least-Privilege Database Access:** Dedicated application user with scoped permissions. Root credentials are strictly forbidden in runtime containers.
- **Parametrized Ingestion:** MongoDB queries use parametrized operations with regex character escaping to prevent injection attacks.

---

## 32. Demonstration Workflow (Step-by-Step)
1. **Launch FinExtract:** Open `http://localhost:8501`.
2. **Upload Text Statement:** Select `samples/text_statement.pdf`. Click **Start Processing**.
3. **Inspect Detection:** Observe type detected as `TEXT`, 1 page, OCR Not Required, bank detected as `SUNRISE NATIONAL BANK`.
4. **View Transactions:** Navigate to **📋 Transactions**. View extracted rows, formatted debits/credits, and categories.
5. **Upload Scanned Statement:** Select `samples/scanned_statement.pdf`. Observe type detected as `SCANNED`, Tesseract OCR activated.
6. **Classification Audit:** Navigate to **🎯 Classification Centre**. Observe rule matches (e.g. `SWIGGY` $\to$ Food & Dining [R001]) and ML predictions.
7. **Perform Manual Correction:** In **📋 Transactions**, select a transaction and reclassify it. Verify the change updates instantly.
8. **Inspect Validation:** Navigate to **✅ Validation Centre**. Confirm balance continuity matches and flagged duplicates are highlighted.
9. **Analytics Deep-Dive:** Navigate to **📈 Analytics**. Review category spending distributions and top merchants with transfers excluded.
10. **Export Reports:** Navigate to **💾 Export Centre**. Download the multi-sheet `.xlsx` workbook and `.csv` file.

---

## 33. Known Limitations
- **Scanned OCR Accuracy on Extreme Degradation:** Extremely blurry, heavily wrinkled, or handwritten physical scans may yield reduced confidence.
- **Bank-Specific Parsers:** HDFC, ICICI, SBI, and Axis parsers are verified for header detection on synthetic snippets; full statement layouts delegate to the universal Generic Parser.
- **Password-Protected PDFs:** Encrypted PDFs are intentionally rejected with clear error prompts; automated password breaking is not supported.

---

## 34. Future Improvements
- Optical table grid line detection utilizing OpenCV morphological kernels for borderless tables.
- Active feedback semi-supervised retraining trigger directly from the UI.
- Support for password-protected statements with user-provided credential prompts.
- Multi-currency conversion using historical exchange rate tables.

---

## 35. Assumptions
1. All amounts without explicit currency symbols default to `INR` ($\text{₹}$).
2. Dates without explicit month-first confirmation default to Indian standard day-first (`DD/MM/YYYY`).
3. Inter-account transfers between user accounts are categorized under `Transfers` and excluded from income/expense totals to prevent artificial inflation.

