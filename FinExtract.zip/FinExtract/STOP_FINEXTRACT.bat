@echo off
setlocal enabledelayedexpansion
title FinExtract - Stop Services
cd /d "%~dp0"

echo ====================================================================
echo.
echo           FINEXTRACT - STOPPING SERVICES                           
echo.
echo ====================================================================
echo.

echo Stopping FinExtract Docker containers...
docker compose down

echo.
echo [OK] All FinExtract services have been safely stopped.
echo.
pause

