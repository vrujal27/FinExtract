"""FinExtract – Enterprise Bank Statement Operations Console.

Deterministic parsing, exact balance continuity audit, and non-LLM hybrid classification.
"""
import sys
import os
import streamlit as st

# Configure wide layout and page metadata
st.set_page_config(
    page_title="FinExtract – Intelligent Bank Statement Processing",
    page_icon="🏦",
    layout="wide",
    initial_sidebar_state="expanded"
)

from src.ui.theme import inject_theme
from src.ui.state import (
    init_session_state, get_active_job, get_all_jobs, get_all_accounts, get_active_job_id
)
from src.ui.components import clean_html, status_badge
from src.ui.pages.dashboard import render_dashboard
from src.ui.pages.upload import render_upload
from src.ui.pages.transactions import render_transactions
from src.ui.pages.classification import render_classification_centre
from src.ui.pages.validation import render_validation_centre
from src.ui.pages.analytics import render_analytics
from src.ui.pages.export import render_export_centre
from src.ui.pages.history import render_history
from src.ui.pages.how_it_works import render_how_it_works
from src.database.connection import get_db
from src.extraction.ocr_extractor import TESSERACT_AVAILABLE


NAV_OPTIONS = [
    "Dashboard",
    "Upload Statement",
    "Transactions",
    "Classification Centre",
    "Validation Centre",
    "Analytics",
    "Export Centre",
    "Processing History",
    "How It Works"
]

NAV_ICONS = {
    "Dashboard": "📊",
    "Upload Statement": "📤",
    "Transactions": "💳",
    "Classification Centre": "🏷️",
    "Validation Centre": "⚖️",
    "Analytics": "📈",
    "Export Centre": "📥",
    "Processing History": "📜",
    "How It Works": "🏛️"
}


def safe_render(page_fn):
    """Enterprise error boundary wrapper for graceful failure handling."""
    try:
        page_fn()
    except Exception as exc:
        st.markdown(f"""
        <div style="background: #FEF2F2; border-left: 4px solid #EF4444; padding: 16px; border-radius: 8px; margin: 20px 0;">
            <div style="font-weight: 700; color: #991B1B; font-size: 1rem; margin-bottom: 6px;">Runtime Fault Isolated</div>
            <div style="font-size: 0.875rem; color: #7F1D1D; margin-bottom: 8px;">{clean_html(str(exc))}</div>
            <div style="font-size: 0.8rem; color: #64748B;">The operational state has been preserved. Review the stack trace below for technical diagnostics.</div>
        </div>
        """, unsafe_allow_html=True)
        import traceback
        with st.expander("🛠️ View Internal Diagnostic Traceback", expanded=False):
            st.code(traceback.format_exc(), language="python")


def main():
    """Main application lifecycle and layout director."""
    init_session_state()
    inject_theme()

    # ─── Sidebar Navigation & Controls ────────────────────────────────────────
    with st.sidebar:
        st.markdown("""
        <div style="padding: 4px 0 16px 0; border-bottom: 1px solid rgba(255,255,255,0.08); margin-bottom: 16px;">
            <div style="display: flex; align-items: center; gap: 10px;">
                <span style="font-size: 1.8rem;">🏦</span>
                <div>
                    <div style="font-size: 1.25rem; font-weight: 800; color: #FFFFFF; letter-spacing: -0.02em;">FinExtract</div>
                    <div style="font-size: 0.7rem; color: #94A3B8; font-weight: 600; text-transform: uppercase; letter-spacing: 0.06em;">Enterprise FinOps Console</div>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)

        # Navigation Menu
        st.markdown("<div style='font-size: 0.7rem; font-weight: 700; color: #64748B; text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 6px;'>Workspace Navigation</div>", unsafe_allow_html=True)
        
        selected_nav = st.radio(
            "Navigate",
            NAV_OPTIONS,
            index=NAV_OPTIONS.index(st.session_state.get("nav", "Dashboard")) if st.session_state.get("nav") in NAV_OPTIONS else 0,
            format_func=lambda opt: f"{NAV_ICONS.get(opt, '•')}  {opt}",
            label_visibility="collapsed",
            key="nav"
        )

        st.markdown("<div style='height: 12px;'></div>", unsafe_allow_html=True)

        # ─── Global Scope Selector ────────────────────────────────────────────
        st.markdown("<div style='font-size: 0.7rem; font-weight: 700; color: #64748B; text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 6px;'>Audit Data Scope</div>", unsafe_allow_html=True)
        
        scope_choices = ["Current statement", "Selected account", "All statements combined"]
        current_scope_idx = 0
        if st.session_state.selected_scope in scope_choices:
            current_scope_idx = scope_choices.index(st.session_state.selected_scope)
            
        chosen_scope = st.selectbox(
            "Active Scope",
            scope_choices,
            index=current_scope_idx,
            label_visibility="collapsed",
            key="scope_selector_widget"
        )
        st.session_state.selected_scope = chosen_scope

        # Dynamic sub-selectors based on scope
        all_jobs = get_all_jobs()
        all_accounts = get_all_accounts()

        if chosen_scope == "Current statement" and all_jobs:
            job_opts = {j.get("job_id"): f"{j.get('filename', 'Unknown')} ({j.get('job_id', '')[:8]})" for j in all_jobs}
            active_jid = get_active_job_id()
            job_keys = list(job_opts.keys())
            def_idx = job_keys.index(active_jid) if active_jid in job_keys else 0
            
            sel_jid = st.selectbox(
                "Statement File",
                options=job_keys,
                index=def_idx,
                format_func=lambda k: job_opts.get(k, k),
                label_visibility="collapsed",
                key="sub_statement_picker"
            )
            st.session_state.active_job_id = sel_jid

        elif chosen_scope == "Selected account" and all_accounts:
            acct_opts = {a["account_id"]: f"{a['bank_name']} ({a['account_number_masked'] or a['account_id'][:8]})" for a in all_accounts}
            acct_keys = list(acct_opts.keys())
            cur_aid = st.session_state.selected_account_id
            def_a_idx = acct_keys.index(cur_aid) if cur_aid in acct_keys else 0
            
            sel_aid = st.selectbox(
                "Target Account",
                options=acct_keys,
                index=def_a_idx,
                format_func=lambda k: acct_opts.get(k, k),
                label_visibility="collapsed",
                key="sub_account_picker"
            )
            st.session_state.selected_account_id = sel_aid

        st.markdown("<div style='height: 16px;'></div>", unsafe_allow_html=True)

        # ─── System Telemetry & Status Card ───────────────────────────────────
        db, db_connected = get_db()
        db_badge = '<span style="color: #10B981; font-weight: 700;">● Online</span>' if db_connected else '<span style="color: #F59E0B; font-weight: 700;">○ In-Memory</span>'
        ocr_badge = '<span style="color: #10B981; font-weight: 700;">● Tesseract 5</span>' if TESSERACT_AVAILABLE else '<span style="color: #94A3B8; font-weight: 600;">○ Vector Text Only</span>'

        st.markdown(f"""
        <div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; padding: 12px; margin-top: auto;">
            <div style="font-size: 0.7rem; font-weight: 700; color: #94A3B8; text-transform: uppercase; letter-spacing: 0.06em; margin-bottom: 8px;">System Diagnostics</div>
            <div style="display: flex; justify-content: space-between; font-size: 0.78rem; margin-bottom: 4px; color: #CBD5E1;">
                <span>Database:</span>
                <span>{db_badge}</span>
            </div>
            <div style="display: flex; justify-content: space-between; font-size: 0.78rem; margin-bottom: 4px; color: #CBD5E1;">
                <span>Classifier:</span>
                <span style="color: #6366F1; font-weight: 600;">TF-IDF + LogReg</span>
            </div>
            <div style="display: flex; justify-content: space-between; font-size: 0.78rem; margin-bottom: 8px; color: #CBD5E1;">
                <span>OCR Pipeline:</span>
                <span>{ocr_badge}</span>
            </div>
            <div style="border-top: 1px solid rgba(255,255,255,0.08); padding-top: 8px; text-align: center;">
                <span style="font-size: 0.72rem; color: #10B981; font-weight: 600; display: inline-flex; align-items: center; gap: 4px;">
                    🛡️ Zero Cloud AI &bull; 100% On-Premise
                </span>
            </div>
        </div>
        """, unsafe_allow_html=True)

    # ─── Page Router ──────────────────────────────────────────────────────────
    page_map = {
        "Dashboard": render_dashboard,
        "Upload Statement": render_upload,
        "Transactions": render_transactions,
        "Classification Centre": render_classification_centre,
        "Validation Centre": render_validation_centre,
        "Analytics": render_analytics,
        "Export Centre": render_export_centre,
        "Processing History": render_history,
        "How It Works": render_how_it_works,
    }

    render_fn = page_map.get(selected_nav, render_dashboard)
    safe_render(render_fn)


if __name__ == "__main__":
    main()
